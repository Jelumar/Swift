QSB.MarkerNamesToID={}function Reprisal_CreateMapMarker(...)return
B_Reprisal_CreateMapMarker:new(...)end
B_Reprisal_CreateMapMarker={Name="Reprisal_CreateMapMarker",Description={en="Reprisal: Creates an marker on the minimap.",de="Vergeltung: Erzeugt eine Markierung auf der Minikarte."},Parameter={{ParameterType.Default,en="Marker Name",de="Name Markierung"},{ParameterType.Custom,en="Marker Type",de="Typ der Markierung"},{ParameterType.Custom,en="Marker Color",de="Farbe der Markierung"},{ParameterType.ScriptName,en="Position",de="Position"}}}
function B_Reprisal_CreateMapMarker:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_CreateMapMarker:AddParameter(QDnlt,LmcA2auZ)
if(QDnlt==0)then self.MarkerName=LmcA2auZ elseif
(QDnlt==1)then self.MarkerType=LmcA2auZ elseif(QDnlt==2)then self.MarkerColor=LmcA2auZ elseif
(QDnlt==3)then self.TargetName=LmcA2auZ end end
function B_Reprisal_CreateMapMarker:GetCustomData(Q)
if Q==1 then
return{"Signal","Marker","Pulse"}elseif Q==2 then local ZA={}
for _IQQ,XpkjA in pairs(MarkerColor)do table.insert(ZA,_IQQ)end;return ZA end end
function B_Reprisal_CreateMapMarker:CustomFunction(pVRj)local fuZ3z86
if self.MarkerType=="Signal"then
fuZ3z86=API.CreateMinimapSignal(pVRj.ReceivingPlayer,MarkerColor[self.MarkerColor],self.TargetName)elseif self.MarkerType=="Signal"then
fuZ3z86=API.CreateMinimapMarker(pVRj.ReceivingPlayer,MarkerColor[self.MarkerColor],self.TargetName)elseif self.MarkerType=="Signal"then
fuZ3z86=API.CreateMinimapPulse(pVRj.ReceivingPlayer,MarkerColor[self.MarkerColor],self.TargetName)end;QSB.MarkerNamesToID[self.MarkerName]=fuZ3z86 end
function B_Reprisal_CreateMapMarker:Debug(er)
if
self.MarkerName==nil or self.MarkerName==""then
error(er.Identifier..
": "..self.Name..": marker name can not be empty.")return true end
if QSB.MarkerNamesToID[self.MarkerName]then
error(er.Identifier..": "..
self.Name..": marker name '"..self.MarkerName..
"' is already in use.")return true end
if not IsExisting(self.TargetName)then
error(er.Identifier..": "..
self.Name..": target '"..
tostring(self.TargetName).."' is dead. ;(")return true end;return false end
Swift:RegisterBehavior(B_Reprisal_CreateMapMarker)
function Reward_CreateMapMarker(...)return B_Reward_CreateMapMarker:new(...)end
B_Reward_CreateMapMarker=Swift:CopyTable(B_Reprisal_CreateMapMarker)B_Reward_CreateMapMarker.Name="Reward_CreateMapMarker"
B_Reward_CreateMapMarker.Description.en="Reward: Creates an marker on the minimap."
B_Reward_CreateMapMarker.Description.de="Lohn: Erzeugt eine Markierung auf der Minikarte."B_Reward_CreateMapMarker.GetReprisalTable=nil
B_Reward_CreateMapMarker.GetRewardTable=function(DFb100j,XL_)return
{Reward.Custom,{DFb100j,DFb100j.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_CreateMapMarker)function Reprisal_DestroyMapMarker(...)return
B_Reprisal_DestroyMapMarker:new(...)end
B_Reprisal_DestroyMapMarker={Name="Reprisal_DestroyMapMarker",Description={en="Reprisal: Removes an marker from the minimap.",de="Vergeltung: Entfernt eine Markierung von der Minikarte."},Parameter={{ParameterType.Default,en="Marker Name",de="Name Markierung"}}}
function B_Reprisal_DestroyMapMarker:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function B_Reprisal_DestroyMapMarker:AddParameter(WYdR,QKKks_zt)
if(WYdR==0)then self.MarkerName=QKKks_zt end end
function B_Reprisal_DestroyMapMarker:CustomFunction(Are7xU)
local yxjl=QSB.MarkerNamesToID[self.MarkerName]API.DestroyMinimapSignal(yxjl)QSB.MarkerNamesToID[self.MarkerName]=
nil end
function B_Reprisal_DestroyMapMarker:Debug(ZG)
if
self.MarkerName==nil or self.MarkerName==""then
error(ZG.Identifier..
": "..self.Name..": marker name can not be empty.")return true end
if not QSB.MarkerNamesToID[self.MarkerName]then
error(ZG.Identifier..": "..
self.Name..
": marker name '"..self.MarkerName.."' is not registered.")return true end;return false end
Swift:RegisterBehavior(B_Reprisal_DestroyMapMarker)function Reward_DestroyMapMarker(...)
return B_Reward_DestroyMapMarker:new(...)end
B_Reward_DestroyMapMarker=Swift:CopyTable(B_Reprisal_DestroyMapMarker)B_Reward_DestroyMapMarker.Name="Reward_DestroyMapMarker"
B_Reward_DestroyMapMarker.Description.en="Reward: Creates an marker on the minimap."
B_Reward_DestroyMapMarker.Description.de="Lohn: Erzeugt eine Markierung auf der Minikarte."B_Reward_DestroyMapMarker.GetReprisalTable=nil
B_Reward_DestroyMapMarker.GetRewardTable=function(Vu0cCAf,q)return
{Reward.Custom,{Vu0cCAf,Vu0cCAf.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_DestroyMapMarker)