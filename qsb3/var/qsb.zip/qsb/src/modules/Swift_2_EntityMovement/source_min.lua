
ModuleEntityMovement={Properties={Name="ModuleEntityMovement"},Global={PathMovingEntities={}},Local={},Shared={}}
function ModuleEntityMovement.Global:OnGameStart()
QSB.ScriptEvents.EntityArrived=API.RegisterScriptEvent("Event_EntityArrived")
QSB.ScriptEvents.EntityStuck=API.RegisterScriptEvent("Event_EntityStuck")
QSB.ScriptEvents.EntityAtCheckpoint=API.RegisterScriptEvent("Event_EntityAtCheckpoint")
QSB.ScriptEvents.PathFindingFinished=API.RegisterScriptEvent("Event_PathFindingFinished")
QSB.ScriptEvents.PathFindingFailed=API.RegisterScriptEvent("Event_PathFindingFailed")
API.StartHiResJob(function()Pathfinder:Controller()end)end;function ModuleEntityMovement.Global:OnEvent(QDnlt,LmcA2auZ,...)end
function ModuleEntityMovement.Global:FillMovingEntityDataForController(Q,ZA,_IQQ,XpkjA,pVRj)local fuZ3z86=
#self.PathMovingEntities+1
self.PathMovingEntities[fuZ3z86]={Entity=GetID(Q),IgnoreBlocking=
pVRj==true,LookAt=_IQQ,Callback=XpkjA,Index=0}for er=1,#ZA do
table.insert(self.PathMovingEntities[fuZ3z86],ZA[er])end;return fuZ3z86 end
function ModuleEntityMovement.Global:MoveEntityPathController(DFb100j)
local XL_=self.PathMovingEntities[DFb100j]local WYdR=true
if not IsExisting(XL_.Entity)then WYdR=false end
if
WYdR and Logic.IsEntityMoving(XL_.Entity)==false then
if XL_.Index>0 then
API.SendScriptEvent(QSB.ScriptEvents.EntityAtCheckpoint,XL_.Entity,XL_[XL_.Index],DFb100j)local tczrIB=tostring(XL_[XL_.Index])if
type(XL_[XL_.Index])=="table"then
tczrIB=table.tostring(XL_[XL_.Index])end
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.EntityAtCheckpoint, %d, %s, %d)]],XL_.Entity,tczrIB,DFb100j))end
self.PathMovingEntities[DFb100j].Index=XL_.Index+1
if#XL_<XL_.Index then
if
Logic.IsSettler(XL_.Entity)==1 and
Logic.GetEntityType(XL_.Entity)~=Entities.D_X_TradeShip then
Logic.SetTaskList(XL_.Entity,TaskLists.TL_NPC_IDLE)
if XL_.LookAt then API.LookAt(XL_.Entity,XL_.LookAt)end;if XL_.Callback then XL_:Callback()end end
API.SendScriptEvent(QSB.ScriptEvents.EntityArrived,XL_.Entity,XL_[#XL_],DFb100j)local a=tostring(XL_[#XL_])if type(XL_[#XL_])=="table"then a=table.tostring(XL_[
#XL_])end
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.EntityArrived, %d, %s, %d)]],XL_.Entity,a,DFb100j))return true end;local QKKks_zt,Are7xU,yxjl=Logic.EntityGetPos(XL_.Entity)local ZG,Vu0cCAf,q;if
type(XL_[XL_.Index])=="table"then ZG=XL_[XL_.Index].X
Vu0cCAf=XL_[XL_.Index].Y else
ZG,Vu0cCAf,q=Logic.EntityGetPos(GetID(XL_[XL_.Index]))end
local kP7O5=Logic.EntityGetPlayer(XL_.Entity)local lqT=Logic.GetEntityPlayerSectorType(XL_.Entity)
local mP3mlD=Logic.GetPlayerSectorID(kP7O5,lqT,QKKks_zt,Are7xU)local PrPyxMK=Logic.GetPlayerSectorID(kP7O5,lqT,ZG,Vu0cCAf)
if
mP3mlD~=PrPyxMK then if Logic.IsSettler(XL_.Entity)==1 then
Logic.SetTaskList(XL_.Entity,TaskLists.TL_NPC_IDLE)end;WYdR=false end
if WYdR then
if XL_.IgnoreBlocking then
if
Logic.IsSettler(XL_.Entity)==1 and
Logic.GetEntityType(XL_.Entity)~=Entities.D_X_TradeShip then
Logic.SetTaskList(XL_.Entity,TaskLists.TL_NPC_WALK)end;Logic.MoveEntity(XL_.Entity,ZG,Vu0cCAf)else
Logic.MoveSettler(XL_.Entity,ZG,Vu0cCAf)end end end
if not WYdR then
API.SendScriptEvent(QSB.ScriptEvents.EntityStuck,XL_.Entity,XL_[XL_.Index],DFb100j)local wqU76o=tostring(XL_[XL_.Index])if
type(XL_[XL_.Index])=="table"then
wqU76o=table.tostring(XL_[XL_.Index])end
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.EntityStuck, %d, %s, %d)]],XL_.Entity,wqU76o,DFb100j))return true end end
function ModuleEntityMovement.Local:OnGameStart()
QSB.ScriptEvents.EntityArrived=API.RegisterScriptEvent("Event_EntityArrived")
QSB.ScriptEvents.EntityStuck=API.RegisterScriptEvent("Event_EntityStuck")
QSB.ScriptEvents.EntityAtCheckpoint=API.RegisterScriptEvent("Event_EntityAtCheckpoint")
QSB.ScriptEvents.PathFindingFinished=API.RegisterScriptEvent("Event_PathFindingFinished")
QSB.ScriptEvents.PathFindingFailed=API.RegisterScriptEvent("Event_PathFindingFailed")end;function ModuleEntityMovement.Local:OnEvent(LB1Z,N9L,...)end
Pathfinder={NodeDistance=300,StepsPerTurn=1,m_PathCounter=0,m_Paths={},m_ProcessedPaths={}}
function Pathfinder:Insert(hDc_M,qW0lRiD1,iD1IUx,JLCOx_ak,hPQ,...)
local R1FIoQI=self:GetClosestPositionOnNodeMap(hDc_M,iD1IUx)if not R1FIoQI then return 0 end
local NsoTwDs=self:GetClosestPositionOnNodeMap(qW0lRiD1,iD1IUx)if not qW0lRiD1 then return 0 end
self.m_PathCounter=self.m_PathCounter+1
self.m_ProcessedPaths[self.m_PathCounter]={NodeDistance=iD1IUx or 300,StepsPerTick=JLCOx_ak or 1,StartNode=R1FIoQI,TargetNode=NsoTwDs,Suspended=false,Closed={},ClosedMap={},Open={},OpenMap={},AcceptMethode=hPQ,AcceptArgs=arg}
R1FIoQI.ID="ID_"..R1FIoQI.X.."_"..R1FIoQI.Y
table.insert(self.m_ProcessedPaths[self.m_PathCounter].Open,1,R1FIoQI)
self.m_ProcessedPaths[self.m_PathCounter].OpenMap[R1FIoQI.ID]=true;return self.m_PathCounter end
function Pathfinder:Controller()for HGli,iy in pairs(self.m_ProcessedPaths)do if iy.Suspended==false then
self:Step(HGli)end end end
function Pathfinder:SendPathingSucceedEvent(m6SCS0)
API.SendScriptEvent(QSB.ScriptEvents.PathFindingFinished,m6SCS0)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.PathFindingFinished, %d)]],m6SCS0))end
function Pathfinder:SendPathingFailedEvent(NUhYw6R4)
API.SendScriptEvent(QSB.ScriptEvents.PathFindingFailed,NUhYw6R4)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.PathFindingFailed, %d)]],NUhYw6R4))end
function Pathfinder:SetSuspended(Hv,Ch)if self.m_ProcessedPaths[Hv]then self.m_ProcessedPaths[Hv].Suspended=
Ch==true end end
function Pathfinder:Step(urkh)
if not self.m_ProcessedPaths[urkh]then self.m_ProcessedPaths[urkh]=
nil;self.m_Paths[urkh]=nil
self:SendPathingFailedEvent(urkh)return true end
for zhzpBSx=1,self.m_ProcessedPaths[urkh].StepsPerTick,1 do
if#
self.m_ProcessedPaths[urkh].Open==0 then
self.m_ProcessedPaths[urkh]=nil;self.m_Paths[urkh]=nil
self:SendPathingFailedEvent(urkh)return true end
local rHSjalVy=table.remove(self.m_ProcessedPaths[urkh].Open,1)self.m_ProcessedPaths[urkh].OpenMap[rHSjalVy.ID]=
nil
if
rHSjalVy.X==
self.m_ProcessedPaths[urkh].TargetNode.X and rHSjalVy.Y==
self.m_ProcessedPaths[urkh].TargetNode.Y then local TjhsnP=rHSjalVy;local t5jzEd9={}local JZAU2=TjhsnP
while(JZAU2)do
table.insert(t5jzEd9,JZAU2)local zPXTTg=TjhsnP.Father;TjhsnP=JZAU2
JZAU2=self:GetNodeByID(urkh,zPXTTg)
if not JZAU2.Father then table.insert(t5jzEd9,JZAU2)break end end;self.m_Paths[urkh]=PathModel:New(t5jzEd9)self.m_ProcessedPaths[urkh]=
nil;self:SendPathingSucceedEvent(urkh)
return true else self:Expand(urkh,rHSjalVy)end end;return false end
function Pathfinder:Expand(seMLr,qX)local h_8=qX.X;local xL7OTb=qX.Y;local w8T3f=qX.ID;local K={}
local qL=self.m_ProcessedPaths[seMLr].NodeDistance
for vfIyB=h_8-qL,h_8+qL,qL do
for quNsijN=xL7OTb-qL,xL7OTb+qL,qL do
if not
(vfIyB==h_8 and quNsijN==xL7OTb)then
if

not self.m_ProcessedPaths[seMLr].OpenMap["ID_"..vfIyB..
"_"..quNsijN]and not
self.m_ProcessedPaths[seMLr].ClosedMap["ID_"..vfIyB.."_"..quNsijN]then
table.insert(K,{ID="ID_"..vfIyB.."_"..quNsijN,X=vfIyB,Y=quNsijN,Father=w8T3f,Distance1=API.GetDistance(qX,self.m_ProcessedPaths[seMLr].TargetNode),Distance2=API.GetDistance(self.m_ProcessedPaths[seMLr].StartNode,qX)})end end end end;self:AcceptSuccessors(seMLr,K)
self:SortOpenList(seMLr)
table.insert(self.m_ProcessedPaths[seMLr].Closed,qX)
self.m_ProcessedPaths[seMLr].OpenMap[qX.ID]=true end
function Pathfinder:AcceptSuccessors(QUh2tc,qboV)local nSBOx7={}
for u,K in pairs(qboV)do
if
not self.m_ProcessedPaths[QUh2tc].ClosedMap[
"ID_"..K.X.."_"..K.Y]then
if not
self.m_ProcessedPaths[QUh2tc].OpenMap["ID_"..K.X.."_"..K.Y]then table.insert(nSBOx7,K)end end end
for i1,zz1QI in pairs(nSBOx7)do local kFTAh=true
if self.m_ProcessedPaths[QUh2tc].AcceptMethode then
kFTAh=
kFTAh and
self.m_ProcessedPaths[QUh2tc].AcceptMethode(zz1QI,nSBOx7,unpack(self.m_ProcessedPaths[QUh2tc].AcceptArgs))end;if kFTAh then
table.insert(self.m_ProcessedPaths[QUh2tc].Open,zz1QI)
self.m_ProcessedPaths[QUh2tc].OpenMap[zz1QI.ID]=true end end end
function Pathfinder:SortOpenList(LBf)
local dijn4Ph=function(CO1,RlZo)return CO1.Distance1 <RlZo.Distance1 and
CO1.Distance2 <RlZo.Distance2 end
table.sort(self.m_ProcessedPaths[LBf].Open,dijn4Ph)end
function Pathfinder:GetClosestPositionOnNodeMap(SUn,Ib4)
if type(SUn)~="table"then SUn=GetPosition(SUn)end;local fjV1G2=Ib4;local Do=math.floor(SUn.X+0.5)
local _=(Do%fjV1G2)local TqYJ4=(_>fjV1G2/2 and(Do+ (fjV1G2-_)))or
Do-_
local DI=math.floor(SUn.Y+0.5)local b=(DI%fjV1G2)local E=
(b>fjV1G2/2 and(DI+ (fjV1G2-b)))or DI-b;return{X=TqYJ4,Y=E}end
function Pathfinder:GetNodeByID(KMw7_i1s,CQi)local nHlJ
for lw4Q7kbl=1,#self.m_ProcessedPaths[KMw7_i1s].Closed
do if
self.m_ProcessedPaths[KMw7_i1s].Closed[lw4Q7kbl].ID==CQi then
nHlJ=self.m_ProcessedPaths[KMw7_i1s].Closed[lw4Q7kbl]end end;return nHlJ end
function Pathfinder:IsPathExisting(IN)return self.m_Paths[IN]~=nil end;function Pathfinder:IsPathStillCalculated(QYf1)
return self.m_ProcessedPaths[QYf1]~=nil end;function Pathfinder:GetPath(RfsnisO)
if
self:IsPathExisting(RfsnisO)then return table.copy(self.m_Paths[RfsnisO])end end
PathModel={m_Nodes={}}
function PathModel:New(lvW2ga)local T7RKP=table.copy(self)T7RKP.m_Nodes=lvW2ga;return T7RKP end
function PathModel:FromList(_L6Bs)local SH=PathModel:New({})local wU4wYbA9=nil
local fFeQcIM=_L6Bs[1]local JEHSHPh3=_L6Bs[#_L6Bs]
for bb=1,#_L6Bs,1 do local o5e6fP=GetID(_L6Bs[bb])
local iq7ol,eMV,WDTNkTD=Logic.EntityGetPos(o5e6fP)
table.insert(SH.m_Nodes,{ID="ID_"..o5e6fP,Marker=0,Father=wU4wYbA9,Visited=false,X=iq7ol,Y=eMV,Distance1=API.GetDistance(o5e6fP,JEHSHPh3),Distance2=API.GetDistance(fFeQcIM,o5e6fP)})wU4wYbA9="ID_"..o5e6fP end;return SH end
function PathModel:AddNode(Oejsws)local CkD73N0=#self.m_Nodes;if CkD73N0 >1 then
Oejsws.Father=self.m_Nodes[CkD73N0-1].ID else Oejsws.Father=nil end
table.insert(self.m_Nodes,Oejsws)end
function PathModel:Merge(PlwhaRKJ)
if PlwhaRKJ and#PlwhaRKJ.m_Nodes>0 and
#self.m_Nodes>0 then PlwhaRKJ.m_Nodes[1].Father=self.m_Nodes[
#self.m_Nodes].ID;for Caz4NM4Z=1,#
PlwhaRKJ.m_Nodes,1 do
table.insert(self.m_Nodes,PlwhaRKJ.m_Nodes[Caz4NM4Z])end end end
function PathModel:Reduce(XVxxx)local hD=table.copy(self)local G5BuU5=#hD.m_Nodes
for AfwsY=G5BuU5,1,-1 do
if
AfwsY~=1 and AfwsY~=G5BuU5 and AfwsY%XVxxx~=0 then
hD.m_Nodes[AfwsY+
1].Father=hD.m_Nodes[AfwsY-1].Father;table.remove(hD.m_Nodes,AfwsY)end end;return hD end
function PathModel:Reset()for T,WZs in pairs(self.m_Nodes)do
self.m_Nodes[T].Visited=false end end;function PathModel:Reverse()
return PathModel:New(table.invert(self.m_Nodes))end;function PathModel:Next()
local ITdz,AjfoUo=self:GetCurrentWaypoint()
if ITdz then self.m_Nodes[AjfoUo].Visited=true end end
function PathModel:GetCurrentWaypoint()
local Er9zidsB;local X=1;repeat Er9zidsB=self.m_Nodes[X]X=X+1 until
(
(not self.m_Nodes[X])or self.m_Nodes[X].Visited==false)if
not self.m_Nodes[X]then X=X-1 end;return Er9zidsB,X end
function PathModel:Convert()
if self.m_Nodes then local dR={}
for JFXtQwy,uMV17h0 in pairs(self.m_Nodes)do
local E2NZK=Logic.CreateEntity(Entities.XD_ScriptEntity,self.m_Nodes.X,self.m_Nodes.Y,0,0)table.insert(dR,E2NZK)end;return dR end end
function PathModel:Show()
if#self.m_Nodes>0 then
for WNWWe=1,#self.m_Nodes do
local zMzjn3lk=Logic.CreateEntity(Entities.XD_ScriptEntity,self.m_Nodes[WNWWe].X,self.m_Nodes[WNWWe].Y,0,0)
Logic.SetModel(zMzjn3lk,Models.Doodads_D_X_Flag)Logic.SetVisible(zMzjn3lk,true)
self.m_Nodes[WNWWe].Marker=zMzjn3lk end end end
function PathModel:Hide()for Trkkpmd,L in pairs(self.m_Nodes)do DestroyEntity(L.Marker)
self.m_Nodes[Trkkpmd].Marker=0 end end;Swift:RegisterModule(ModuleEntityMovement)