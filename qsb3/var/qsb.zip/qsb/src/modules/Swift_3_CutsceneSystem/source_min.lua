
ModuleCutsceneSystem={Properties={Name="ModuleCutsceneSystem"},Global={Cutscene={},CutsceneQueue={},CutsceneCounter=0},Local={Cutscene={}},Shared={Text={FastForwardActivate={de="Beschleunigen",en="Fast Forward"},FastForwardDeactivate={de="Zurücksetzen",en="Normal Speed"},FastFormardMessage={de="SCHNELLER VORLAUF",en="FAST FORWARD"}}}}QSB.CinematicEventTypes.Cutscene=3
function ModuleCutsceneSystem.Global:OnGameStart()
QSB.ScriptEvents.CutsceneStarted=API.RegisterScriptEvent("Event_CutsceneStarted")
QSB.ScriptEvents.CutsceneEnded=API.RegisterScriptEvent("Event_CutsceneEnded")
QSB.ScriptEvents.CutsceneSkipButtonPressed=API.RegisterScriptEvent("Event_CutsceneSkipButtonPressed")
QSB.ScriptEvents.CutsceneFlightStarted=API.RegisterScriptEvent("Event_CutsceneFlightStarted")
QSB.ScriptEvents.CutsceneFlightEnded=API.RegisterScriptEvent("Event_CutsceneFlightEnded")for QDnlt=1,8 do self.CutsceneQueue[QDnlt]={}end
API.StartHiResJob(function()
ModuleCutsceneSystem.Global:UpdateQueue()end)end
function ModuleCutsceneSystem.Global:OnEvent(LmcA2auZ,Q,...)
if
LmcA2auZ==QSB.ScriptEvents.EscapePressed then elseif LmcA2auZ==QSB.ScriptEvents.CutsceneStarted then elseif LmcA2auZ==
QSB.ScriptEvents.CutsceneEnded then self:EndCutscene(arg[1])elseif LmcA2auZ==
QSB.ScriptEvents.CutsceneFlightStarted then
self:StartCutsceneFlight(arg[1],arg[2],arg[3])elseif LmcA2auZ==QSB.ScriptEvents.CutsceneFlightEnded then
self:EndCutsceneFlight(arg[1],arg[2])elseif LmcA2auZ==QSB.ScriptEvents.CutsceneSkipButtonPressed then
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.CutsceneSkipButtonPressed, %d)]],arg[1]))end end
function ModuleCutsceneSystem.Global:UpdateQueue()
for ZA=1,8 do
if self:CanStartCutscene(ZA)then
local _IQQ=ModuleDisplayCore.Global:LookUpCinematicInFromQueue(ZA)if
_IQQ and _IQQ[1]==QSB.CinematicEventTypes.Cutscene then self:NextCutscene(ZA)end end end end
function ModuleCutsceneSystem.Global:StartCutscene(XpkjA,pVRj,fuZ3z86)self.CutsceneQueue[pVRj]=
self.CutsceneQueue[pVRj]or{}self.CutsceneCounter=
(self.CutsceneCounter or 0)+1
fuZ3z86.CutsceneName="Cutscene #"..self.CutsceneCounter
ModuleDisplayCore.Global:PushCinematicEventToQueue(pVRj,QSB.CinematicEventTypes.Cutscene,XpkjA,fuZ3z86)end
function ModuleCutsceneSystem.Global:EndCutscene(er)
Logic.SetGlobalInvulnerability(0)if self.Cutscene[er].Finished then
self.Cutscene[er]:Finished()end
API.FinishCinematicEvent(self.Cutscene[er].Name,er)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.CutsceneEnded, %d)]],er))self.Cutscene[er]=nil end
function ModuleCutsceneSystem.Global:NextCutscene(DFb100j)
if self:CanStartCutscene(DFb100j)then
local XL_=ModuleDisplayCore.Global:PopCinematicEventFromQueue(DFb100j)
assert(XL_[1]==QSB.CinematicEventTypes.Cutscene)API.StartCinematicEvent(XL_[2],DFb100j)local WYdR=XL_[3]
WYdR.Name=XL_[2]WYdR.PlayerID=DFb100j;WYdR.BarOpacity=WYdR.BarOpacity or 1
WYdR.CurrentPage=0;self.Cutscene[DFb100j]=WYdR;if WYdR.EnableGlobalImmortality then
Logic.SetGlobalInvulnerability(1)end;if self.Cutscene[DFb100j].Starting then
self.Cutscene[DFb100j]:Starting()end
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.CutsceneStarted, %d, %s)]],DFb100j,table.tostring(self.Cutscene[DFb100j])))
API.SendScriptEvent(QSB.ScriptEvents.CutsceneStarted,DFb100j,self.Cutscene[DFb100j])end end
function ModuleCutsceneSystem.Global:StartCutsceneFlight(QKKks_zt,Are7xU,yxjl)if
self.Cutscene[QKKks_zt]==nil then return end
self.Cutscene[QKKks_zt][Are7xU].Duration=yxjl;if self.Cutscene[QKKks_zt][Are7xU].Action then
self.Cutscene[QKKks_zt][Are7xU]:Action()end
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.CutsceneFlightStarted, %d, %d, %d)]],QKKks_zt,Are7xU,yxjl))end
function ModuleCutsceneSystem.Global:EndCutsceneFlight(ZG,Vu0cCAf)if
self.Cutscene[ZG]==nil then return end
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.CutsceneFlightEnded, %d, %d)]],ZG,Vu0cCAf))end
function ModuleCutsceneSystem.Global:DisplayPage(q,kP7O5)
if self.Cutscene[q]==nil then return end
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.CutscenePageShown, %d, %d)]],q,kP7O5))end;function ModuleCutsceneSystem.Global:GetCurrentCutscene(lqT)
return self.Cutscene[lqT]end
function ModuleCutsceneSystem.Global:GetCurrentCutscenePage(mP3mlD)
if
self.Cutscene[mP3mlD]then local PrPyxMK=self.Cutscene[mP3mlD].CurrentPage;return
self.Cutscene[mP3mlD][PrPyxMK]end end
function ModuleCutsceneSystem.Global:GetPageIDByName(tczrIB,a)
if type(a)=="string"then
if
self.Cutscene[tczrIB]~=nil then
for wqU76o=1,#self.Cutscene[tczrIB],1 do
if
type(self.Cutscene[tczrIB][wqU76o])=="table"and
self.Cutscene[tczrIB][wqU76o].Name==a then return wqU76o end end end;return 0 end;return a end
function ModuleCutsceneSystem.Global:CanStartCutscene(LB1Z)return


self.Cutscene[LB1Z]==nil and not API.IsCinematicEventActive(LB1Z)and not API.IsLoadscreenVisible()end
function ModuleCutsceneSystem.Local:OnGameStart()
QSB.ScriptEvents.CutsceneStarted=API.RegisterScriptEvent("Event_CutsceneStarted")
QSB.ScriptEvents.CutsceneEnded=API.RegisterScriptEvent("Event_CutsceneEnded")
QSB.ScriptEvents.CutsceneSkipButtonPressed=API.RegisterScriptEvent("Event_CutsceneSkipButtonPressed")
QSB.ScriptEvents.CutsceneFlightStarted=API.RegisterScriptEvent("Event_CutsceneFlightStarted")
QSB.ScriptEvents.CutsceneFlightEnded=API.RegisterScriptEvent("Event_CutsceneFlightEnded")self:OverrideThroneRoomFunctions()end
function ModuleCutsceneSystem.Local:OnEvent(N9L,hDc_M,...)
if
N9L==QSB.ScriptEvents.EscapePressed then elseif N9L==QSB.ScriptEvents.CutsceneStarted then
self:StartCutscene(arg[1],arg[2])elseif N9L==QSB.ScriptEvents.CutsceneEnded then
self:EndCutscene(arg[1])elseif N9L==QSB.ScriptEvents.CutsceneFlightStarted then
self:StartCutsceneFlight(arg[1],arg[2],arg[3])elseif N9L==QSB.ScriptEvents.CutsceneFlightEnded then
self:EndCutsceneFlight(arg[1],arg[2])elseif N9L==QSB.ScriptEvents.CutsceneSkipButtonPressed then
self:SkipButtonPressed(arg[1])end end
function ModuleCutsceneSystem.Local:StartCutscene(qW0lRiD1,iD1IUx)if
GUI.GetPlayerID()~=qW0lRiD1 then return end;self.Cutscene[qW0lRiD1]=iD1IUx
self.Cutscene[qW0lRiD1].LastSkipButtonPressed=0;self.Cutscene[qW0lRiD1].CurrentPage=0
API.DeactivateNormalInterface()API.DeactivateBorderScroll()
if
not Framework.IsNetworkGame()then Game.GameTimeSetFactor(qW0lRiD1,1)end;self:ActivateCinematicMode(qW0lRiD1)
self:NextFlight(qW0lRiD1)end
function ModuleCutsceneSystem.Local:EndCutscene(JLCOx_ak)if
GUI.GetPlayerID()~=JLCOx_ak then return end;if not Framework.IsNetworkGame()then
Game.GameTimeSetFactor(JLCOx_ak,1)end
self:DeactivateCinematicMode(JLCOx_ak)API.ActivateNormalInterface()
API.ActivateBorderScroll()self.Cutscene[JLCOx_ak]=nil end
function ModuleCutsceneSystem.Local:NextFlight(hPQ)
if self.Cutscene[hPQ]then self.Cutscene[hPQ].CurrentPage=
self.Cutscene[hPQ].CurrentPage+1
local R1FIoQI=self.Cutscene[hPQ].CurrentPage
if self.Cutscene[hPQ][R1FIoQI]then
local NsoTwDs=self.Cutscene[hPQ][R1FIoQI].Flight
if Camera.IsValidCutscene(NsoTwDs)then if GUI.GetPlayerID()==hPQ then
Camera.StartCutscene(NsoTwDs)end else
error("ModuleCutsceneSystem.Local:NextFlight: "..tostring(NsoTwDs)..
" is an invalid flight!")self:PropagateCutsceneEnded(hPQ)end else self:PropagateCutsceneEnded(hPQ)end end end
function ModuleCutsceneSystem.Local:PropagateCutsceneEnded(HGli)if
not self.Cutscene[HGli]then return end
API.BroadcastScriptEventToGlobal(QSB.ScriptEvents.CutsceneEnded,HGli)end
function ModuleCutsceneSystem.Local:FlightStarted(iy)
local m6SCS0=GUI.GetPlayerID()
if self.Cutscene[m6SCS0]then
local NUhYw6R4=self.Cutscene[m6SCS0].CurrentPage
API.BroadcastScriptEventToGlobal(QSB.ScriptEvents.CutsceneFlightStarted,m6SCS0,NUhYw6R4,iy)end end;CutsceneFlightStarted=function(Hv)
ModuleCutsceneSystem.Local:FlightStarted(Hv)end;function ModuleCutsceneSystem.Local:StartCutsceneFlight(Ch,urkh,zhzpBSx)if
self.Cutscene[Ch]==nil then return end
self:DisplayPage(Ch,urkh,zhzpBSx)end
function ModuleCutsceneSystem.Local:FlightFinished()
local rHSjalVy=GUI.GetPlayerID()
if self.Cutscene[rHSjalVy]then
local TjhsnP=self.Cutscene[rHSjalVy].CurrentPage
API.BroadcastScriptEventToGlobal(QSB.ScriptEvents.CutsceneFlightEnded,rHSjalVy,TjhsnP)end end;CutsceneFlightFinished=function()
ModuleCutsceneSystem.Local:FlightFinished()end;function ModuleCutsceneSystem.Local:EndCutsceneFlight(t5jzEd9,JZAU2)if
self.Cutscene[t5jzEd9]==nil then return end
self:NextFlight(t5jzEd9)end
function ModuleCutsceneSystem.Local:DisplayPage(zPXTTg,seMLr,qX)if
GUI.GetPlayerID()~=zPXTTg then return end;self.Cutscene[zPXTTg].AnimationQueue=
self.Cutscene[zPXTTg].AnimationQueue or{}
self.Cutscene[zPXTTg].CurrentPage=seMLr
if
type(self.Cutscene[zPXTTg][seMLr])=="table"then
self.Cutscene[zPXTTg][seMLr].Started=Logic.GetTime()
self.Cutscene[zPXTTg][seMLr].Duration=qX;self:DisplayPageBars(zPXTTg,seMLr)
self:DisplayPageTitle(zPXTTg,seMLr)self:DisplayPageText(zPXTTg,seMLr)
self:DisplayPageControls(zPXTTg,seMLr)self:DisplayPageFader(zPXTTg,seMLr)end end
function ModuleCutsceneSystem.Local:DisplayPageBars(h_8,xL7OTb)
local w8T3f=self.Cutscene[h_8][xL7OTb]
local K=(w8T3f.Opacity~=nil and w8T3f.Opacity)or 1;local qL=(255*K)local vfIyB=(255*K)
local quNsijN=(w8T3f.BigBars and 1)or 0;local QUh2tc=(w8T3f.BigBars and 0)or 1;if K==0 then quNsijN=0
QUh2tc=0 end
XGUIEng.ShowWidget("/InGame/ThroneRoomBars",quNsijN)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2",QUh2tc)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_Dodge",quNsijN)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2_Dodge",QUh2tc)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars/BarBottom",1,qL)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars/BarTop",1,qL)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars_2/BarBottom",1,vfIyB)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars_2/BarTop",1,vfIyB)end
function ModuleCutsceneSystem.Local:DisplayPageTitle(qboV,nSBOx7)
local u=self.Cutscene[qboV][nSBOx7]local K="/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight"
XGUIEng.SetText(K,"")
if u.Title then local i1=API.ConvertPlaceholders(u.Title)
if
i1:find("^[A-Za-Z0-9_]+/[A-Za-Z0-9_]+$")then i1=XGUIEng.GetStringTableText(i1)end;if i1:sub(1,1)~="{"then
i1="{@color:255,250,0,255}{center}"..i1 end;XGUIEng.SetText(K,i1)end end
function ModuleCutsceneSystem.Local:DisplayPageText(zz1QI,kFTAh)
local LBf=self.Cutscene[zz1QI][kFTAh]local dijn4Ph="/InGame/ThroneRoom/Main/MissionBriefing/Text"
XGUIEng.SetText(dijn4Ph,"Bockwurst")
if LBf.Text then local CO1=API.ConvertPlaceholders(LBf.Text)
if
CO1:find("^[A-Za-Z0-9_]+/[A-Za-Z0-9_]+$")then CO1=XGUIEng.GetStringTableText(CO1)end;if CO1:sub(1,1)~="{"then CO1="{center}"..CO1 end;if not
LBf.BigBars then CO1="{cr}{cr}{cr}"..CO1 end
XGUIEng.SetText(dijn4Ph,CO1)end end
function ModuleCutsceneSystem.Local:DisplayPageControls(RlZo,SUn)
local Ib4=self.Cutscene[RlZo][SUn]local fjV1G2=1
if Ib4.DisableSkipping==true then
self.Cutscene[RlZo].FastForward=false;Game.GameTimeSetFactor(RlZo,1)fjV1G2=0 end
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Skip",fjV1G2)end
function ModuleCutsceneSystem.Local:DisplayPageFader(Do,_)
local TqYJ4=self.Cutscene[Do][_]g_Fade.To=TqYJ4.FaderAlpha or 0;local DI=TqYJ4.FadeIn;if DI then
FadeIn(DI)end;local b=TqYJ4.FadeOut
if b then
self.Cutscene[Do].FaderJob=API.StartHiResJob(function(E,KMw7_i1s)if
Logic.GetTimeMs()>E- (KMw7_i1s*1000)then FadeOut(KMw7_i1s)
return true end end,(
TqYJ4.Started*1000)+ (TqYJ4.Duration*100),b)end end
function ModuleCutsceneSystem.Local:ThroneRoomCameraControl(CQi,nHlJ)
if nHlJ then if nHlJ.DisableSkipping then
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Objectives"," ")return end
local lw4Q7kbl=API.Localize(ModuleCutsceneSystem.Shared.Text.FastForwardActivate)if self.Cutscene[CQi].FastForward then
lw4Q7kbl=API.Localize(ModuleCutsceneSystem.Shared.Text.FastForwardDeactivate)end
XGUIEng.SetText("/InGame/ThroneRoom/Main/Skip",
"{center}"..lw4Q7kbl)
if self.Cutscene[CQi].FastForward then
local IN=API.RealTimeGetSecondsPassedSinceGameStart()if not self.Cutscene[CQi].FastForwardRealTime then
self.Cutscene[CQi].FastForwardRealTime=IN end
if
self.Cutscene[CQi].FastForwardRealTime<IN then
self.Cutscene[CQi].FastForwardIndent=(
self.Cutscene[CQi].FastForwardIndent or 0)+1;if self.Cutscene[CQi].FastForwardIndent>4 then
self.Cutscene[CQi].FastForwardIndent=1 end
self.Cutscene[CQi].FastForwardRealTime=IN end
local QYf1="{cr}{cr}"..
API.Localize(ModuleCutsceneSystem.Shared.Text.FastFormardMessage)
local RfsnisO=string.rep("  ",(self.Cutscene[CQi].FastForwardIndent or 0))
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Objectives",QYf1 ..RfsnisO..". . .")else
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Objectives"," ")end end end
function ModuleCutsceneSystem.Local:SkipButtonPressed(lvW2ga)if
self.Cutscene[lvW2ga]==nil then return end
if
(self.Cutscene[lvW2ga].LastSkipButtonPressed+500)<Logic.GetTimeMs()then
self.Cutscene[lvW2ga].LastSkipButtonPressed=Logic.GetTimeMs()
if not Framework.IsNetworkGame()then
if
self.Cutscene[lvW2ga].FastForward then self.Cutscene[lvW2ga].FastForward=false
Game.GameTimeSetFactor(lvW2ga,1)else self.Cutscene[lvW2ga].FastForward=true
Game.GameTimeSetFactor(lvW2ga,10)end end end end;function ModuleCutsceneSystem.Local:GetCurrentCutscene(T7RKP)
return self.Cutscene[T7RKP]end
function ModuleCutsceneSystem.Local:GetCurrentCutscenePage(_L6Bs)if
self.Cutscene[_L6Bs]then local SH=self.Cutscene[_L6Bs].CurrentPage;return
self.Cutscene[_L6Bs][SH]end end
function ModuleCutsceneSystem.Local:GetPageIDByName(wU4wYbA9,fFeQcIM)
if type(fFeQcIM)=="string"then
if
self.Cutscene[wU4wYbA9]~=nil then
for JEHSHPh3=1,#self.Cutscene[wU4wYbA9],1 do
if

type(self.Cutscene[wU4wYbA9][JEHSHPh3])=="table"and
self.Cutscene[wU4wYbA9][JEHSHPh3].Name==fFeQcIM then return JEHSHPh3 end end end;return 0 end;return fFeQcIM end
function ModuleCutsceneSystem.Local:OverrideThroneRoomFunctions()
GameCallback_Camera_SkipButtonPressed_Orig_ModuleCutsceneSystem=GameCallback_Camera_SkipButtonPressed
GameCallback_Camera_SkipButtonPressed=function(bb)
GameCallback_Camera_SkipButtonPressed_Orig_ModuleCutsceneSystem(bb)if bb==GUI.GetPlayerID()then
API.BroadcastScriptEventToGlobal(QSB.ScriptEvents.CutsceneSkipButtonPressed,GUI.GetPlayerID())end end
GameCallback_Camera_ThroneroomCameraControl_Orig_ModuleCutsceneSystem=GameCallback_Camera_ThroneroomCameraControl
GameCallback_Camera_ThroneroomCameraControl=function(o5e6fP)
GameCallback_Camera_ThroneroomCameraControl_Orig_ModuleCutsceneSystem(o5e6fP)
if o5e6fP==GUI.GetPlayerID()then
local iq7ol=ModuleCutsceneSystem.Local:GetCurrentCutscene(o5e6fP)if iq7ol~=nil then
ModuleCutsceneSystem.Local:ThroneRoomCameraControl(o5e6fP,ModuleCutsceneSystem.Local:GetCurrentCutscenePage(o5e6fP))end end end;GameCallback_Escape_Orig_CutsceneSystem=GameCallback_Escape
GameCallback_Escape=function()if
ModuleCutsceneSystem.Local.Cutscene[GUI.GetPlayerID()]then return end
GameCallback_Escape_Orig_CutsceneSystem()end end
function ModuleCutsceneSystem.Local:ActivateCinematicMode(eMV)if self.CinematicActive or
GUI.GetPlayerID()~=eMV then return end
self.CinematicActive=true;local WDTNkTD=API.IsLoadscreenVisible()if WDTNkTD then
XGUIEng.PopPage()end;local Oejsws,CkD73N0=GUI.GetScreenSize()
XGUIEng.ShowWidget("/InGame/ThroneRoom",1)XGUIEng.PushPage("/InGame/ThroneRoomBars",false)
XGUIEng.PushPage("/InGame/ThroneRoomBars_2",false)
XGUIEng.PushPage("/InGame/ThroneRoom/Main",false)
XGUIEng.PushPage("/InGame/ThroneRoomBars_Dodge",false)
XGUIEng.PushPage("/InGame/ThroneRoomBars_2_Dodge",false)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Skip",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/StartButton",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/Frame",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/DialogBG",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/FrameEdges",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogBottomRight3pcs",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/KnightInfoButton",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Briefing",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/BackButton",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Cutscene",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/TitleContainer",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/MissionBriefing/Text",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/MissionBriefing/Title",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/MissionBriefing/Objectives",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/KnightInfo/BG",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/KnightInfo/LeftFrame",0)
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Text"," ")
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Title"," ")
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Objectives"," ")
local PlwhaRKJ,Caz4NM4Z=XGUIEng.GetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight")
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",PlwhaRKJ,65* (CkD73N0/1080))GUI.ClearSelection()GUI.ClearNotes()
GUI.ForbidContextSensitiveCommandsInSelectionState()GUI.ActivateCutSceneState()
GUI.SetFeedbackSoundOutputState(0)GUI.EnableBattleSignals(false)
Input.CutsceneMode()if not self.Cutscene[eMV].EnableFoW then
Display.SetRenderFogOfWar(0)end;if self.Cutscene[eMV].EnableSky then
Display.SetRenderSky(1)end
if
not self.Cutscene[eMV].EnableBorderPins then Display.SetRenderBorderPins(0)end;Display.SetUserOptionOcclusionEffect(0)
Camera.SwitchCameraBehaviour(5)InitializeFader()g_Fade.To=1;SetFaderAlpha(1)if WDTNkTD then
XGUIEng.PushPage("/LoadScreen/LoadScreen",false)end end
function ModuleCutsceneSystem.Local:DeactivateCinematicMode(XVxxx)
if not self.CinematicActive or
GUI.GetPlayerID()~=XVxxx then return end;self.CinematicActive=false;g_Fade.To=0;SetFaderAlpha(0)
XGUIEng.PopPage()Camera.SwitchCameraBehaviour(0)
Display.UseStandardSettings()Input.GameMode()GUI.EnableBattleSignals(true)
GUI.SetFeedbackSoundOutputState(1)GUI.ActivateSelectionState()
GUI.PermitContextSensitiveCommandsInSelectionState()Display.SetRenderSky(0)
Display.SetRenderBorderPins(1)Display.SetRenderFogOfWar(1)if
Options.GetIntValue("Display","Occlusion",0)>0 then
Display.SetUserOptionOcclusionEffect(1)end
XGUIEng.PopPage()XGUIEng.PopPage()XGUIEng.PopPage()
XGUIEng.PopPage()XGUIEng.PopPage()
XGUIEng.ShowWidget("/InGame/ThroneRoom",0)XGUIEng.ShowWidget("/InGame/ThroneRoomBars",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_Dodge",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2_Dodge",0)
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Objectives"," ")end;Swift:RegisterModule(ModuleCutsceneSystem)