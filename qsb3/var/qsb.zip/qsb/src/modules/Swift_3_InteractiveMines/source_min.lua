
ModuleInteractiveMines={Properties={Name="ModuleInteractiveMines"},Global={Mines={},Lambda={MineCondition={},MineConstructed={},MineDepleted={}}},Local={},Shared={Text={Title={de="Rohstoffquelle erschließen",en="Construct mine"},Text={de="An diesem Ort könnt Ihr eine Rohstoffquelle erschließen!",en="You're able to create a pit at this location!"}}}}
function ModuleInteractiveMines.Global:OnGameStart()
QSB.ScriptEvents.InteractiveMineActivated=API.RegisterScriptEvent("Event_InteractiveMineActivated")
QSB.ScriptEvents.InteractiveMineDepleted=API.RegisterScriptEvent("Event_InteractiveMineDepleted")
API.StartHiResJob(function()
ModuleInteractiveMines.Global:ControlIOMines()end)end
function ModuleInteractiveMines.Global:OnEvent(QDnlt,LmcA2auZ,...)
if
QDnlt==QSB.ScriptEvents.ObjectReset then if IO[arg[1]]and IO[arg[1]].IsInteractiveMine then
self:ResetIOMine(arg[1],IO[arg[1]].Type)end elseif
QDnlt==QSB.ScriptEvents.ObjectDelete then if IO[arg[1]].IsInteractiveMine and IO[arg[1]].Type then
ReplaceEntity(arg[1],IO[arg[1]].Type)end end end
function ModuleInteractiveMines.Global:CreateIOMine(Q,ZA,_IQQ,XpkjA,pVRj,fuZ3z86,er,DFb100j,XL_)
local WYdR=self:ResetIOMine(Q,ZA)local QKKks_zt={14,10}
if g_GameExtraNo>=1 then
if ZA==Entities.R_IronMine then QKKks_zt={14,10}end;if ZA==Entities.R_StoneMine then QKKks_zt={14,10}end end
API.SetupObject{Name=Q,IsInteractiveMine=true,Title=_IQQ or
ModuleInteractiveMines.Shared.Text.Title,Text=XpkjA or
ModuleInteractiveMines.Shared.Text.Text,Texture=QKKks_zt,Type=ZA,Crumbles=fuZ3z86,Costs=pVRj,InvisibleBlocker=WYdR,Distance=1200,AdditionalCondition=er,AdditionalAction=DFb100j,DepletionAction=XL_,Condition=function(Are7xU)if Are7xU.AdditionalAction then return
Are7xU:AdditionalAction()end;return true end,Action=function(yxjl,ZG,Vu0cCAf)
ReplaceEntity(yxjl.Name,yxjl.Type)DestroyEntity(yxjl.InvisibleBlocker)if yxjl.AdditionalAction then
yxjl:AdditionalAction(ZG,Vu0cCAf)end
API.SendScriptEvent(QSB.ScriptEvents.InteractiveMineActivated,yxjl.Name,ZG,Vu0cCAf)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(%d, "%s", %d, %d)]],QSB.ScriptEvents.InteractiveMineActivated,yxjl.Name,ZG,Vu0cCAf))end}end
function ModuleInteractiveMines.Global:ResetIOMine(q,kP7O5)if IO[q]then
DestroyEntity(IO[q].InvisibleBlocker)end
local lqT=ReplaceEntity(q,Entities.XD_ScriptEntity)local mP3mlD=Models.Doodads_D_SE_ResourceIron_Wrecked;if
kP7O5 ==Entities.R_StoneMine then mP3mlD=Models.R_SE_ResorceStone_10 end
Logic.SetVisible(lqT,true)Logic.SetModel(lqT,mP3mlD)
local PrPyxMK,tczrIB,a=Logic.EntityGetPos(lqT)
local wqU76o=Logic.CreateEntity(Entities.D_ME_Rock_Set01_B_07,PrPyxMK,tczrIB,0,0)Logic.SetVisible(wqU76o,false)if IO[q]then
IO[q].InvisibleBlocker=wqU76o end;return wqU76o end
function ModuleInteractiveMines.Global:ControlIOMines()
for LB1Z,N9L in pairs(IO)do
local hDc_M=GetID(LB1Z)
if
N9L.IsInteractiveMine and Logic.GetResourceDoodadGoodType(hDc_M)~=0 then
if Logic.GetResourceDoodadGoodAmount(hDc_M)==0 then
if
N9L.Crumbles==true then local qW0lRiD1=Models.Doodads_D_SE_ResourceIron_Wrecked
if
N9L.Type==Entities.R_StoneMine then qW0lRiD1=Models.R_ResorceStone_Scaffold_Destroyed end
hDc_M=ReplaceEntity(hDc_M,Entities.XD_ScriptEntity)Logic.SetVisible(hDc_M,true)
Logic.SetModel(hDc_M,qW0lRiD1)end;if N9L.DepletionAction then N9L:DepletionAction()end
API.SendScriptEvent(QSB.ScriptEvents.InteractiveMineDepleted,LB1Z)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(%d, "%s")]],QSB.ScriptEvents.InteractiveMineDepleted,LB1Z))end end end end
function ModuleInteractiveMines.Local:OnGameStart()
QSB.ScriptEvents.InteractiveMineActivated=API.RegisterScriptEvent("Event_InteractiveMineActivated")
QSB.ScriptEvents.InteractiveMineDepleted=API.RegisterScriptEvent("Event_InteractiveMineDepleted")end;Swift:RegisterModule(ModuleInteractiveMines)