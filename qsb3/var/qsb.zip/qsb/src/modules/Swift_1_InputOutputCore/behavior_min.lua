
function Goal_Decide(...)return B_Goal_Decide:new(...)end
B_Goal_Decide={Name="Goal_Decide",Description={en="Goal: Opens a Yes/No Dialog. Decision = Quest Result",de="Ziel: Öffnet einen Ja/Nein-Dialog. Die Entscheidung bestimmt das Quest-Ergebnis (ja=true, nein=false)."},Parameter={{ParameterType.Default,en="Text",de="Text"},{ParameterType.Default,en="Title",de="Titel"},{ParameterType.Custom,en="Button labels",de="Button Beschriftung"}}}function B_Goal_Decide:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_Decide:AddParameter(QDnlt,LmcA2auZ)
if(
QDnlt==0)then self.Text=LmcA2auZ elseif(QDnlt==1)then self.Title=LmcA2auZ elseif(QDnlt==2)then self.Buttons=(
LmcA2auZ=="Ok/Cancel")end end
function B_Goal_Decide:CustomFunction(Q)
if Framework.IsNetworkGame()then return false end
if
not API.IsCinematicEventActive or(API.IsCinematicEventActive and
API.IsCinematicEventActive()==false)then
if not QSB.GoalDecideDialogDisplayed then
local _IQQ=(self.Buttons and"true")or"nil"QSB.GoalDecideDialogDisplayed=true
Logic.ExecuteInLuaLocalState(string.format([[
                    local Action = function(_Yes)
                        API.BroadcastScriptCommand(QSB.ScriptCommands.SetDecisionResult, GUI.GetPlayerID(), _Yes == true);
                    end
                    API.DialogRequestBox("%s", "%s", Action, %s)
                ]],self.Title,self.Text,(
self.Buttons and"true")or"nil"))end;local ZA=QSB.DecisionWindowResult;if ZA~=nil then QSB.GoalDecideDialogDisplayed=nil;QSB.DecisionWindowResult=
nil;return ZA end end end;function B_Goal_Decide:GetIcon()return{4,12}end
function B_Goal_Decide:GetCustomData(XpkjA)if
XpkjA==2 then return{"Yes/No","Ok/Cancel"}end end
function B_Goal_Decide:Debug(pVRj)if Framework.IsNetworkGame()then
error(pVRj.Identifier..": "..self.Name..
": Can not be used in multiplayer!")return true end
return false end
function B_Goal_Decide:Reset()QSB.GoalDecideDialogDisplayed=nil end;Swift:RegisterBehavior(B_Goal_Decide)function Goal_InputDialog(...)return
B_Goal_InputDialog:new(...)end
B_Goal_InputDialog={Name="Goal_InputDialog",Description={en="Goal: Player must type in something. The passwords have to be seperated by ; and whitespaces will be ignored.",de="Ziel: Öffnet einen Dialog, der Spieler muss Lösungswörter eingeben. Diese sind durch ; abzutrennen. Leerzeichen werden ignoriert."},DefaultMessage={de="Versuche bis zum Fehlschlag: ",en="Trials remaining until failure: "},Parameter={{ParameterType.Default,en="Password to enter",de="Einzugebendes Passwort"},{ParameterType.Number,en="Trials till failure (0 endless)",de="Versuche bis Fehlschlag (0 endlos)"},{ParameterType.Default,en="Wrong password message",de="Text bei Falscheingabe"}}}
function B_Goal_InputDialog:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_InputDialog:AddParameter(fuZ3z86,er)if(fuZ3z86 ==0)then
self.Password=self:LowerCase(er or"")elseif(fuZ3z86 ==1)then self.Trials=(er or 0)*1 elseif(fuZ3z86 ==2)then
self.Message=er end end
function B_Goal_InputDialog:CustomFunction(DFb100j)
if Framework.IsNetworkGame()then return false end
if not self.Shown then
if
(not self.Trials)or(self.Trials)==0 then QSB.GoalInputDialogQuest=DFb100j.Identifier;self.Shown=true
API.ShowTextInput(DFb100j.ReceivingPlayer)elseif not self.Shown then QSB.GoalInputDialogQuest=DFb100j.Identifier
self.Shown=true;self.TrialCounter=self.TrialCounter or self.Trials
API.ShowTextInput(DFb100j.ReceivingPlayer)self.TrialCounter=self.TrialCounter-1 end end
if
not API.IsCinematicEventActive or(API.IsCinematicEventActive and
API.IsCinematicEventActive()==false)then
if self.InputDialogResult then
if self.Password~=nil and self.Password~=""then self.Shown=
nil
if
self:LowerCase(self.InputDialogResult)==self.Password then return true elseif(self.Trials==0)or
(self.Trials>0 and self.TrialCounter>0)then self:OnWrongInput(DFb100j)return else
return false end end;QSB.GoalInputDialogQuest=nil;return true end end end
function B_Goal_InputDialog:OnWrongInput(XL_)
if self.Trials>0 and not self.Message then
local WYdR=QSB.Language
Logic.DEBUG_AddNote(API.Localize(self.DefaultMessage)..self.TrialCounter)return end;if self.Message then
Logic.DEBUG_AddNote(API.Localize(self.Message))end;self.InputDialogResult=nil
self.Shown=nil end
function B_Goal_InputDialog:LowerCase(QKKks_zt)QKKks_zt=QKKks_zt:lower(QKKks_zt)
QKKks_zt=QKKks_zt:gsub("Ä","ä")QKKks_zt=QKKks_zt:gsub("Ö","ö")
QKKks_zt=QKKks_zt:gsub("Ü","ü")return QKKks_zt end;function B_Goal_InputDialog:GetIcon()return{12,2}end
function B_Goal_InputDialog:Debug(Are7xU)if
Framework.IsNetworkGame()then
error(Are7xU.Identifier..
": "..self.Name..": Can not be used in multiplayer!")return true end
return false end
function B_Goal_InputDialog:Reset(yxjl)QSB.GoalInputDialogQuest=nil
self.InputDialogResult=nil;self.TrialCounter=nil;self.Shown=nil end;function B_Goal_InputDialog:Interrupt(ZG)self:Reset(ZG)end
Swift:RegisterBehavior(B_Goal_InputDialog)