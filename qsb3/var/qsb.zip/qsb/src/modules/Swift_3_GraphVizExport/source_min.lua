
ModuleGraphVizExport={Properties={Name="ModuleGraphVizExport"},Global={},Local={},Shared={}}function ModuleGraphVizExport.Global:OnGameStart()
QSB.GraphViz:Init()end
function ModuleGraphVizExport.Global:ExecuteGraphVizExport()
Framework.WriteToLog("\n\n\n==== GraphViz Export Start ====\n\n\n")local QDnlt=QSB.GraphViz:ConvertQuests()
ModuleGraphVizExport.Global:WriteLinewiseToLog(QDnlt)
Framework.WriteToLog("\n\n\n==== GraphViz Export Ende ====\n\n\n")return QDnlt end
function ModuleGraphVizExport.Global:WriteLinewiseToLog(LmcA2auZ)
local Q=self:SplitString(LmcA2auZ)for ZA=1,#Q,1 do Framework.WriteToLog(Q[ZA])end end
function ModuleGraphVizExport.Global:SplitString(_IQQ)local XpkjA={}
local pVRj,fuZ3z86=_IQQ:find("\n")
while fuZ3z86 do
table.insert(XpkjA,_IQQ:sub(1,fuZ3z86-1))_IQQ=_IQQ:sub(fuZ3z86+1)pVRj,fuZ3z86=_IQQ:find("\n")end;table.insert(XpkjA,_IQQ)return XpkjA end
function ModuleGraphVizExport.Local:OnGameStart()QSB.GraphViz=nil end;QSB.GraphViz={SourceFile="",Quests={}}
function QSB.GraphViz:Init()API=API or{}
CreateQuest_Orig_ModuleGraphVizExport=API.CreateQuest
API.CreateQuest=function(er)
local DFb100j,XL_=CreateQuest_Orig_ModuleGraphVizExport(er)
if not DFb100j:find("DialogSystemQuest")then
local WYdR=QSB.GraphViz:AddQuestDefaults(table.copy(er))
QSB.GraphViz.Quests[#QSB.GraphViz.Quests+1]=WYdR end;return DFb100j,XL_ end;AddQuest=API.CreateQuest end
function QSB.GraphViz:AddQuestDefaults(QKKks_zt)QKKks_zt.Sender=QKKks_zt.Sender or 1;QKKks_zt.Receiver=
QKKks_zt.Receiver or 1
QKKks_zt.Time=QKKks_zt.Time or 0
QKKks_zt.Visible=(QKKks_zt.Visible==true or QKKks_zt.Suggestion~=nil)
QKKks_zt.EndMessage=QKKks_zt.EndMessage==true or(QKKks_zt.Failure~=nil or
QKKks_zt.Success~=nil)if QKKks_zt.Suggestion then
QKKks_zt.Suggestion=API.Localize(QKKks_zt.Suggestion)end;if QKKks_zt.Success then
QKKks_zt.Success=API.Localize(QKKks_zt.Success)end;if QKKks_zt.Failure then
QKKks_zt.Failure=API.Localize(QKKks_zt.Failure)end;if QKKks_zt.Description then
QKKks_zt.Description=API.Localize(QKKks_zt.Description)end;return QKKks_zt end
function QSB.GraphViz:ConvertQuests()local Are7xU=Framework.GetCurrentMapName()
local yxjl=""
yxjl=yxjl..
'\ndigraph G { graph [    fontname = "Helvetica-Oblique", fontsize = 30, label = "'..Are7xU..
'" ] \nnode [ fontname = "Courier-Bold" shape = "box" ] \n'for ZG=1,#QSB.GraphViz.Quests,1 do
for Vu0cCAf,q in
pairs(QSB.GraphViz:ConvertQuest(QSB.GraphViz.Quests[ZG]))do yxjl=yxjl.."    "..q.." \n"end end;yxjl=
yxjl..'} \n'return yxjl end
function QSB.GraphViz:ConvertQuest(kP7O5)local lqT={}
local mP3mlD={Succeed='color="#00ff00"',Fail='color="#ff0000"',Interrupt='color="#999999"',Default='color="#0000ff"'}
local function PrPyxMK(hPQ)return
string.match(string.format("%q",tostring(hPQ)),'^"(.*)"$')or"nil"end
local function tczrIB(R1FIoQI,NsoTwDs)assert(R1FIoQI)assert(NsoTwDs>3)if
string.len(R1FIoQI)<=NsoTwDs then return R1FIoQI else
return string.sub(R1FIoQI,1,NsoTwDs-3).."..."end end;local a=""local wqU76o={}local LB1Z=0
for HGli=1,#kP7O5,1 do local iy=kP7O5[HGli].Name
local m6SCS0=
(
string.find(iy,"Succe")and mP3mlD.Succeed)or(
string.find(iy,"Fail")and mP3mlD.Fail)or
(string.find(iy,"Interrupt")and mP3mlD.Interrupt)or
mP3mlD.Default;local a=(string.find(iy,"Wait")and'fontcolor="red"')or
""
local NUhYw6R4=
string.find(iy,"Goal")~=nil or string.find(iy,"Trigger")~=nil;local Hv=kP7O5[HGli].Name.."("
if kP7O5[HGli].Parameter then
for Ch=1,#
kP7O5[HGli].Parameter do if(Ch>1)then Hv=Hv..", "end;local urkh="nil"
if
kP7O5[HGli].v12ya_gg56h_al125[Ch]then urkh=kP7O5[HGli].v12ya_gg56h_al125[Ch]if type(urkh)==
"string"then urkh="'"..urkh.."'"end end;Hv=Hv..tostring(urkh)
if(
kP7O5[HGli].Parameter[Ch][1]==ParameterType.QuestName)then
table.insert(lqT,
(
NUhYw6R4 and
string.format('%q -> %q [%s]',kP7O5[HGli].v12ya_gg56h_al125[Ch],kP7O5.Name,m6SCS0))or
string.format('%q -> %q [%s, arrowhead = "odot", arrowtail = "invempty" style="dashed"]',kP7O5.Name,kP7O5[HGli].QuestName,m6SCS0))end end end;Hv=Hv..")"table.insert(wqU76o,Hv)end
local N9L=PrPyxMK(tczrIB(kP7O5.Description or"",80))N9L=
(N9L~=""and"\\nDescription: '"..N9L.."'")or""
local hDc_M=PrPyxMK(tczrIB(kP7O5.Suggestion or"",80))hDc_M=
(hDc_M~=""and"\\nSuggestion: '"..hDc_M.."'")or""
local qW0lRiD1=PrPyxMK(tczrIB(kP7O5.Failure or"",80))qW0lRiD1=
(qW0lRiD1 ~=""and"\\nFailure: '"..qW0lRiD1 .."'")or""local iD1IUx=PrPyxMK(tczrIB(kP7O5.Success or
"",80))iD1IUx=
(
iD1IUx~=""and"\\nSuccess: '"..iD1IUx.."'")or""
local JLCOx_ak="\\n=== "..kP7O5.Sender.."  ->  "..
kP7O5.Receiver.." ==="table.sort(wqU76o)
table.insert(lqT,string.format('%q [ %s label = "%s%s%s%s%s%s%s\\n\\n%s" %s%s]',kP7O5.Name,a,PrPyxMK(kP7O5.Name),JLCOx_ak,hDc_M,qW0lRiD1,iD1IUx,N9L,
kP7O5.Time~=0 and('\\nTime: '..kP7O5.Time)or'',table.concat(wqU76o,"\\n"),
kP7O5.Time~=0 and'shape="octagon" 'or'',not kP7O5.Visible and
'style="filled" fillcolor="#dddddd" 'or''))return lqT end;Swift:RegisterModule(ModuleGraphVizExport)