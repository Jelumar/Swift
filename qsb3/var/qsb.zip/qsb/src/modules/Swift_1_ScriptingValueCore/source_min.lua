
ModuleScriptingValue={Properties={Name="ModuleScriptingValue"},Global={},Local={},Shared={SV={Game="Vanilla",Vanilla={Destination={X=19,Y=20},Health=-41,Player=-71,Size=-45,Visible=-50,NPC=6},HistoryEdition={Destination={X=17,Y=18},Health=
-38,Player=-68,Size=-42,Visible=-47,NPC=6}}}}
function ModuleScriptingValue.Global:OnGameStart()if API.IsHistoryEdition()then
ModuleScriptingValue.Shared.SV.Game="HistoryEdition"end
QSB.ScriptingValue=ModuleScriptingValue.Shared.SV[ModuleScriptingValue.Shared.SV.Game]end
function ModuleScriptingValue.Local:OnGameStart()if API.IsHistoryEdition()then
ModuleScriptingValue.Shared.SV.Game="HistoryEdition"end
QSB.ScriptingValue=ModuleScriptingValue.Shared.SV[ModuleScriptingValue.Shared.SV.Game]end
function ModuleScriptingValue.Shared:qmod(QDnlt,LmcA2auZ)return QDnlt-
math.floor(QDnlt/LmcA2auZ)*LmcA2auZ end
function ModuleScriptingValue.Shared:ScriptingValueBitsInteger(Q)local ZA={}
while Q>0 do
rest=self:qmod(Q,2)table.insert(ZA,1,rest)Q=(Q-rest)/2 end;table.remove(ZA,1)return ZA end
function ModuleScriptingValue.Shared:ScriptingValueBitsFraction(_IQQ,XpkjA)
for pVRj=1,48 do _IQQ=_IQQ*2;if
(_IQQ>=1)then table.insert(XpkjA,1)_IQQ=_IQQ-1 else
table.insert(XpkjA,0)end;if(_IQQ==0)then return XpkjA end end;return XpkjA end
function ModuleScriptingValue.Shared:ScriptingValueIntegerToFloat(fuZ3z86)
if(fuZ3z86 ==0)then return 0 end;local er=1
if(fuZ3z86 <0)then fuZ3z86=2147483648+fuZ3z86;er=-1 end;local DFb100j=self:qmod(fuZ3z86,8388608)
local XL_=(fuZ3z86-DFb100j)/8388608;local WYdR=self:qmod(XL_,256)local QKKks_zt=WYdR-127;local Are7xU=1;local yxjl=0.5
local ZG=4194304
for Vu0cCAf=23,0,-1 do
if(DFb100j-ZG)>0 then Are7xU=Are7xU+yxjl;DFb100j=DFb100j-ZG end;ZG=ZG/2;yxjl=yxjl/2 end;return Are7xU*math.pow(2,QKKks_zt)*er end
function ModuleScriptingValue.Shared:ScriptingValueFloatToInteger(q)if(q==0)then return 0 end
local kP7O5=false;if(q<0)then kP7O5=true;q=q*-1 end;local lqT=0;local mP3mlD;local PrPyxMK=0
if q>=1 then
local wqU76o=math.floor(q)local LB1Z=q-wqU76o
mP3mlD=self:ScriptingValueBitsInteger(wqU76o)PrPyxMK=#mP3mlD
self:ScriptingValueBitsFraction(LB1Z,mP3mlD)else mP3mlD={}self:ScriptingValueBitsFraction(q,mP3mlD)
while(
mP3mlD[1]==0)do PrPyxMK=PrPyxMK-1;table.remove(mP3mlD,1)end;PrPyxMK=PrPyxMK-1;table.remove(mP3mlD,1)end;local tczrIB=4194304;local a=1
for N9L=a,23 do local hDc_M=mP3mlD[N9L]if(not hDc_M)then break end;if
(hDc_M==1)then lqT=lqT+tczrIB end;tczrIB=tczrIB/2 end;lqT=lqT+ (PrPyxMK+127)*8388608;if(kP7O5)then lqT=lqT-
2147483648 end;return lqT end;Swift:RegisterModule(ModuleScriptingValue)