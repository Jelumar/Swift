
do
GameCallback_EntityKilled_Orig_QSB_Goal_DestroySoldiers=GameCallback_EntityKilled
GameCallback_EntityKilled=function(QDnlt,LmcA2auZ,Q,ZA,_IQQ,XpkjA)
if LmcA2auZ~=0 and ZA~=0 then QSB.DestroyedSoldiers[ZA]=
QSB.DestroyedSoldiers[ZA]or{}QSB.DestroyedSoldiers[ZA][LmcA2auZ]=
QSB.DestroyedSoldiers[ZA][LmcA2auZ]or 0
if

Logic.IsEntityTypeInCategory(_IQQ,EntityCategories.Military)==1 and
Logic.IsEntityInCategory(QDnlt,EntityCategories.HeavyWeapon)==0 then QSB.DestroyedSoldiers[ZA][LmcA2auZ]=
QSB.DestroyedSoldiers[ZA][LmcA2auZ]+1 end end
GameCallback_EntityKilled_Orig_QSB_Goal_DestroySoldiers(QDnlt,LmcA2auZ,Q,ZA,_IQQ,XpkjA)end end
function Goal_DestroySoldiers(...)return B_Goal_DestroySoldiers:new(...)end
B_Goal_DestroySoldiers={Name="Goal_DestroySoldiers",Description={en="Goal: Destroy a given amount of enemy soldiers",de="Ziel: Zerstöre eine Anzahl gegnerischer Soldaten"},Parameter={{ParameterType.PlayerID,en="Attacking Player",de="Angreifer"},{ParameterType.PlayerID,en="Defending Player",de="Verteidiger"},{ParameterType.Number,en="Amount",de="Anzahl"}},Text={de="{center}SOLDATEN ZERSTÖREN {cr}{cr}von der Partei: %s{cr}{cr}Anzahl: %d",en="{center}DESTROY SOLDIERS {cr}{cr}from faction: %s{cr}{cr}Amount: %d"}}
function B_Goal_DestroySoldiers:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_DestroySoldiers:AddParameter(pVRj,fuZ3z86)if(pVRj==0)then self.AttackingPlayer=fuZ3z86*1 elseif(
pVRj==1)then self.AttackedPlayer=fuZ3z86*1 elseif(pVRj==2)then
self.KillsNeeded=fuZ3z86*1 end end
function B_Goal_DestroySoldiers:CustomFunction(er)
if
not er.QuestDescription or er.QuestDescription==""then
local DFb100j=GetPlayerName(self.AttackedPlayer)or""
Swift:ChangeCustomQuestCaptionText(string.format(Swift:GetTextOfDesiredLanguage(ModuleMilitaryLimit.Text),DFb100j,self.KillsNeeded),er)end
if self.KillsNeeded>=
ModuleMilitaryLimit.Global:GetEnemySoldierKillsOfPlayer(self.AttackingPlayer,self.AttackedPlayer)then return true end end
function B_Goal_DestroySoldiers:Debug(XL_)
if
Logic.GetStoreHouse(self.AttackingPlayer)==0 then
error(XL_.Identifier..": "..self.Name..
": Player "..self.AttackinPlayer.." is dead :-(")return true elseif Logic.GetStoreHouse(self.AttackedPlayer)==0 then
error(
XL_.Identifier..": "..
self.Name..": Player "..self.AttackedPlayer.." is dead :-(")return true elseif self.KillsNeeded<0 then
error(XL_.Identifier..
": "..self.Name..": Amount negative")return true end end;function B_Goal_DestroySoldiers:GetIcon()return{7,12}end
Swift:RegisterBehavior(B_Goal_DestroySoldiers)