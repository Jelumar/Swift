
ModuleTypewriter={Properties={Name="ModuleTypewriter"},Global={TypewriterEventData={},TypewriterEventQueue={},TypewriterEventCounter=0},Local={},Shared={}}QSB.CinematicEventTypes.Typewriter=1
function ModuleTypewriter.Global:OnGameStart()
QSB.ScriptEvents.TypewriterStarted=API.RegisterScriptEvent("Event_TypewriterStarted")
QSB.ScriptEvents.TypewriterEnded=API.RegisterScriptEvent("Event_TypewriterEnded")
for QDnlt=1,8 do self.TypewriterEventQueue[QDnlt]={}end
StartSimpleHiResJobEx(function()
ModuleTypewriter.Global:ControlTypewriter()end)end
function ModuleTypewriter.Global:StartTypewriter(LmcA2auZ)
self.TypewriterEventCounter=self.TypewriterEventCounter+1
local Q="CinematicEvent_Typewriter"..self.TypewriterEventCounter;LmcA2auZ.Name=Q
if API.IsLoadscreenVisible()or
API.IsCinematicEventActive(LmcA2auZ.PlayerID)then
ModuleDisplayCore.Global:PushCinematicEventToQueue(LmcA2auZ.PlayerID,QSB.CinematicEventTypes.Typewriter,Q,LmcA2auZ)return LmcA2auZ.Name end;return self:PlayTypewriter(LmcA2auZ)end
function ModuleTypewriter.Global:PlayTypewriter(ZA)
local _IQQ=API.StartCinematicEvent(ZA.Name,ZA.PlayerID)ZA.ID=_IQQ;ZA.TextTokens=self:TokenizeText(ZA)
self.TypewriterEventData[ZA.PlayerID]=ZA
Logic.ExecuteInLuaLocalState(string.format([[
        if GUI.GetPlayerID() == %d then
            API.ActivateColoredScreen(%d, %d, %d, %d);
            API.DeactivateNormalInterface();
            API.DeactivateBorderScroll(%d);
            Input.CutsceneMode()
            GUI.ClearNotes()
        end
        ]],ZA.PlayerID,ZA.Color.R,ZA.Color.G,ZA.Color.B,ZA.Color.A,ZA.TargetEntity))
API.SendScriptEvent(QSB.ScriptEvents.TypewriterStarted,ZA.PlayerID,ZA)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(%d, %d, %s)]],QSB.ScriptEvents.TypewriterStarted,ZA.PlayerID,table.tostring(ZA)))return ZA.Name end
function ModuleTypewriter.Global:FinishTypewriter(XpkjA)
if self.TypewriterEventData[XpkjA]then
local pVRj=table.copy(self.TypewriterEventData[XpkjA])
local fuZ3z86=self.TypewriterEventData[XpkjA].PlayerID
Logic.ExecuteInLuaLocalState(string.format([[
            if GUI.GetPlayerID() == %d then
                API.DeactivateColoredScreen()
                API.ActivateNormalInterface()
                API.ActivateBorderScroll()
                Input.GameMode()
                GUI.ClearNotes()
            end
            ]],XpkjA))
self.TypewriterEventData[XpkjA]:Callback()self.TypewriterEventData[XpkjA]=nil
API.FinishCinematicEvent(pVRj.Name,fuZ3z86)
API.SendScriptEvent(QSB.ScriptEvents.TypewriterEnded,fuZ3z86,pVRj)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(%d, %d, %s)]],QSB.ScriptEvents.TypewriterEnded,fuZ3z86,table.tostring(pVRj)))end end
function ModuleTypewriter.Global:TokenizeText(er)local DFb100j={}local XL_={}
local WYdR=API.ConvertPlaceholders(er.Text)WYdR=WYdR:gsub("%s+"," ")
while(true)do local Are7xU,yxjl=WYdR:find("{")
local ZG,Vu0cCAf=WYdR:find("}")
if not Are7xU or not ZG then table.insert(XL_,WYdR)break end;if Are7xU>1 then
table.insert(XL_,WYdR:sub(1,Are7xU-1))end
table.insert(XL_,WYdR:sub(Are7xU,Vu0cCAf))WYdR=WYdR:sub(Vu0cCAf+1)end;local QKKks_zt=false
for q=1,#XL_,1 do
if XL_[q]:find("{")then local kP7O5=#DFb100j;if QKKks_zt then DFb100j[kP7O5]=
DFb100j[kP7O5]..XL_[q]else
table.insert(DFb100j,kP7O5+1,XL_[q])end;QKKks_zt=true else local lqT=1
while(lqT<=
#XL_[q])do if
string.byte(XL_[q]:sub(lqT,lqT))==195 then
table.insert(DFb100j,XL_[q]:sub(lqT,lqT+1))lqT=lqT+1 else
table.insert(DFb100j,XL_[q]:sub(lqT,lqT))end;lqT=
lqT+1 end;QKKks_zt=false end end;return DFb100j end
function ModuleTypewriter.Global:ControlTypewriter()
for mP3mlD=1,8 do
if

not API.IsLoadscreenVisible()and not API.IsCinematicEventActive(mP3mlD)then
local PrPyxMK=ModuleDisplayCore.Global:LookUpCinematicInFromQueue(mP3mlD)
if
PrPyxMK and PrPyxMK[1]==QSB.CinematicEventTypes.Typewriter then
local tczrIB=ModuleDisplayCore.Global:PopCinematicEventFromQueue(mP3mlD)self:PlayTypewriter(tczrIB)end end end
for a,wqU76o in pairs(self.TypewriterEventData)do
if
self.TypewriterEventData[a].Delay>0 then self.TypewriterEventData[a].Delay=
self.TypewriterEventData[a].Delay-1
Logic.ExecuteInLuaLocalState(string.format([[if GUI.GetPlayerID() == %d then GUI.ClearNotes() end]],self.TypewriterEventData[a].PlayerID))end
if self.TypewriterEventData[a].Delay==0 then self.TypewriterEventData[a].Index=
wqU76o.Index+wqU76o.CharSpeed;if wqU76o.Index>#
self.TypewriterEventData[a].TextTokens then
self.TypewriterEventData[a].Index=
#self.TypewriterEventData[a].TextTokens end;local LB1Z=math.floor(
wqU76o.Index+0.5)local N9L=""
for hDc_M=1,LB1Z,1 do N9L=N9L..
self.TypewriterEventData[a].TextTokens[hDc_M]end
Logic.ExecuteInLuaLocalState(string.format(
[[
                if GUI.GetPlayerID() == %d then
                    GUI.ClearNotes()
                    GUI.AddNote("]]..N9L..[[");
                end
                ]],self.TypewriterEventData[a].PlayerID))
if
LB1Z==#self.TypewriterEventData[a].TextTokens then
self.TypewriterEventData[a].Waittime=wqU76o.Waittime-1
if wqU76o.Waittime<=0 then self:FinishTypewriter(a)end end end end end
function ModuleTypewriter.Local:OnGameStart()
QSB.ScriptEvents.TypewriterStarted=API.RegisterScriptEvent("Event_TypewriterStarted")
QSB.ScriptEvents.TypewriterEnded=API.RegisterScriptEvent("Event_TypewriterEnded")end;Swift:RegisterModule(ModuleTypewriter)