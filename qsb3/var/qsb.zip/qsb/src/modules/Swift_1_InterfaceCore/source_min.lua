
ModuleInterfaceCore={Properties={Name="ModuleInterfaceCore"},Global={HumanKnightType=0,HumanPlayerID=1},Local={BuildingButtons={BindingCounter=0,Bindings={},Configuration={["BuyAmmunitionCart"]={TypeExclusion="^B_.*StoreHouse",OriginalPosition=nil,Bind=nil},["BuyBattallion"]={TypeExclusion="^B_[CB]a[sr][tr][la][ec]",OriginalPosition=
nil,Bind=nil},["PlaceField"]={TypeExclusion="^B_.*[BFH][aei][erv][kme]",OriginalPosition=nil,Bind=nil},["StartFestival"]={TypeExclusion="^B_Marketplace",OriginalPosition=
nil,Bind=nil},["StartTheatrePlay"]={TypeExclusion="^B_Theatre",OriginalPosition=nil,Bind=nil},["UpgradeTurret"]={TypeExclusion="^B_WallTurret",OriginalPosition=
nil,Bind=nil},["BuyBatteringRamCart"]={TypeExclusion="^B_SiegeEngineWorkshop",OriginalPosition=nil,Bind=nil},["BuyCatapultCart"]={TypeExclusion="^B_SiegeEngineWorkshop",OriginalPosition=
nil,Bind=nil},["BuySiegeTowerCart"]={TypeExclusion="^B_SiegeEngineWorkshop",OriginalPosition=nil,Bind=nil}}},HiddenWidgets={},HotkeyDescriptions={},ForbidRegularSave=false,DisableHEAutoSave=false,HumanKnightType=0,HumanPlayerID=1},Shared={}}QSB.PlayerNames={}
function ModuleInterfaceCore.Global:OnGameStart()
self.HumanKnightType=Logic.GetEntityType(Logic.GetKnightID(QSB.HumanPlayerID))self.HumanPlayerID=QSB.HumanPlayerID
StartSimpleJobEx(function()if Logic.GetTime()>1 then
ModuleInterfaceCore.Global:OverridePlayerLost()return true end end)end
function ModuleInterfaceCore.Global:OverridePlayerLost()
GameCallback_PlayerLost=function(QDnlt)
if
QDnlt==QSB.HumanPlayerID then if not Framework.IsNetworkGame()then
QuestTemplate:TerminateEventsAndStuff()
if MissionCallback_Player1Lost then MissionCallback_Player1Lost()end end end end end
function ModuleInterfaceCore.Global:SetControllingPlayer(LmcA2auZ,Q,ZA)
assert(type(LmcA2auZ)=="number")assert(type(Q)=="number")ZA=ZA or""
local _IQQ=Logic.GetKnightID(Q)local XpkjA=Logic.GetEntityType(_IQQ)
Logic.PlayerSetIsHumanFlag(LmcA2auZ,0)Logic.PlayerSetIsHumanFlag(Q,1)
Logic.PlayerSetGameStateToPlaying(Q)self.HumanKnightType=XpkjA;self.HumanPlayerID=Q;QSB.HumanPlayerID=Q
Logic.ExecuteInLuaLocalState(
[[
        GUI.ClearSelection()
        GUI.SetControlledPlayer(]]..
Q..
[[)
        
        local KnightID = Logic.GetKnightID(]]..
Q..
[[)
        ModuleInterfaceCore.Local.HumanPlayerID = ]]..
Q..
[[
        QSB.HumanPlayerID = ]]..

Q..
[[;

        for k,v in pairs(Buffs) do
            GUI_Buffs.UpdateBuffsInInterface(]]..
Q..

[[, v)
            GUI.ResetMiniMap()
        end

        if IsExisting(Logic.GetKnightID(GUI.GetPlayerID())) then
            local Portrait = GetKnightActor(]]..
XpkjA..

[[)
            local KnightType = Logic.GetEntityType(KnightID)
            ModuleInterfaceCore.Local.HumanKnightType = KnightType;
            g_PlayerPortrait[GUI.GetPlayerID()] = Portrait
            LocalSetKnightPicture()
        end

        local NewName = "]]..
ZA..

[["
        if NewName ~= "" then
            GUI_MissionStatistic.PlayerNames[GUI.GetPlayerID()] = NewName
        end
        HideOtherMenus()

        function GUI_Knight.GetTitleNameByTitleID(_KnightType, _TitleIndex)
            local KeyName = "Title_" .. GetNameOfKeyInTable(KnightTitles, _TitleIndex) .. "_" .. KnightGender[]]..
XpkjA..
[[]
            local String = XGUIEng.GetStringTableText("UI_ObjectNames/" .. KeyName)
            if String == nil or String == "" then
                String = "Knight not in Gender Table? (localscript.lua)"
            end
            return String
        end
    ]])self.HumanPlayerChangedOnce=true end
function ModuleInterfaceCore.Local:OnGameStart()
self.HumanKnightType=Logic.GetEntityType(Logic.GetKnightID(QSB.HumanPlayerID))self.HumanPlayerID=QSB.HumanPlayerID
self:InitBackupPositions()self:OverrideOnSelectionChanged()
self:OverrideMissionGoodCounter()self:OverrideUpdateClaimTerritory()
self:SetupHackRegisterHotkey()self:OverrideBuyAmmunitionCart()
self:OverrideBuyBattalion()self:OverrideBuySiegeEngineCart()
self:OverridePlaceField()self:OverrideStartFestival()
self:OverrideStartTheatrePlay()self:OverrideUpgradeTurret()
API.AddBlockQuicksaveCondition(function()return
ModuleInterfaceCore.Local.ForbidRegularSave==true end)
API.AddBlockQuicksaveCondition(function(...)return not arg[1]and
ModuleInterfaceCore.Local.DisableHEAutoSave==true end)end
function ModuleInterfaceCore.Local:OnEvent(pVRj,fuZ3z86,...)if
pVRj==QSB.ScriptEvents.SaveGameLoaded then self:UpdateHiddenWidgets()
self:DisplaySaveButtons()end end
function ModuleInterfaceCore.Local:OverrideOnSelectionChanged()
GameCallback_GUI_SelectionChanged_Orig_InterfaceCore=GameCallback_GUI_SelectionChanged
GameCallback_GUI_SelectionChanged=function(er)
GameCallback_GUI_SelectionChanged_Orig_InterfaceCore(er)
ModuleInterfaceCore.Local:UnbindButtons()
ModuleInterfaceCore.Local:BindButtons(GUI.GetSelectedEntity())end end
function ModuleInterfaceCore.Local:OverrideBuyAmmunitionCart()
GUI_BuildingButtons.BuyAmmunitionCartClicked_Orig_InterfaceCore=GUI_BuildingButtons.BuyAmmunitionCartClicked
GUI_BuildingButtons.BuyAmmunitionCartClicked=function()
local DFb100j=XGUIEng.GetCurrentWidgetID()local XL_=XGUIEng.GetWidgetNameByID(DFb100j)
local WYdR=GUI.GetSelectedEntity()
local QKKks_zt=ModuleInterfaceCore.Local.BuildingButtons.Configuration[XL_].Bind
if not QKKks_zt then return
GUI_BuildingButtons.BuyAmmunitionCartClicked_Orig_InterfaceCore()end;QKKks_zt.Action(DFb100j,WYdR)end
GUI_BuildingButtons.BuyAmmunitionCartUpdate_Orig_InterfaceCore=GUI_BuildingButtons.BuyAmmunitionCartUpdate
GUI_BuildingButtons.BuyAmmunitionCartUpdate=function()
local Are7xU=XGUIEng.GetCurrentWidgetID()local yxjl=XGUIEng.GetWidgetNameByID(Are7xU)
local ZG=GUI.GetSelectedEntity()
local Vu0cCAf=ModuleInterfaceCore.Local.BuildingButtons.Configuration[yxjl].Bind
if not Vu0cCAf then SetIcon(Are7xU,{10,4})
XGUIEng.ShowWidget(Are7xU,1)XGUIEng.DisableButton(Are7xU,0)return
GUI_BuildingButtons.BuyAmmunitionCartUpdate_Orig_InterfaceCore()end;Vu0cCAf.Update(Are7xU,ZG)end end
function ModuleInterfaceCore.Local:OverrideBuyBattalion()
GUI_BuildingButtons.BuyBattalionClicked_Orig_InterfaceCore=GUI_BuildingButtons.BuyBattalionClicked
GUI_BuildingButtons.BuyBattalionClicked=function()
local q=XGUIEng.GetCurrentWidgetID()local kP7O5=XGUIEng.GetWidgetNameByID(q)
local lqT=GUI.GetSelectedEntity()
local mP3mlD=ModuleInterfaceCore.Local.BuildingButtons.Configuration[kP7O5].Bind
if not mP3mlD then return
GUI_BuildingButtons.BuyBattalionClicked_Orig_InterfaceCore()end;mP3mlD.Action(q,lqT)end
GUI_BuildingButtons.BuyBattalionMouseOver_Orig_InterfaceCore=GUI_BuildingButtons.BuyBattalionMouseOver
GUI_BuildingButtons.BuyBattalionMouseOver=function()
local PrPyxMK=XGUIEng.GetCurrentWidgetID()local tczrIB=XGUIEng.GetWidgetNameByID(PrPyxMK)
local a=GUI.GetSelectedEntity()local wqU76o;if
ModuleInterfaceCore.Local.BuildingButtons.Configuration[tczrIB]then
wqU76o=ModuleInterfaceCore.Local.BuildingButtons.Configuration[tczrIB].Bind end
if not
wqU76o then return
GUI_BuildingButtons.BuyBattalionMouseOver_Orig_InterfaceCore()end;wqU76o.Tooltip(PrPyxMK,a)end
GUI_BuildingButtons.BuyBattalionUpdate_Orig_InterfaceCore=GUI_BuildingButtons.BuyBattalionUpdate
GUI_BuildingButtons.BuyBattalionUpdate=function()
local LB1Z=XGUIEng.GetCurrentWidgetID()local N9L=XGUIEng.GetWidgetNameByID(LB1Z)
local hDc_M=GUI.GetSelectedEntity()
local qW0lRiD1=ModuleInterfaceCore.Local.BuildingButtons.Configuration[N9L].Bind;if not qW0lRiD1 then XGUIEng.ShowWidget(LB1Z,1)
XGUIEng.DisableButton(LB1Z,0)
return GUI_BuildingButtons.BuyBattalionUpdate_Orig_InterfaceCore()end
qW0lRiD1.Update(LB1Z,hDc_M)end end
function ModuleInterfaceCore.Local:OverridePlaceField()
GUI_BuildingButtons.PlaceFieldClicked_Orig_InterfaceCore=GUI_BuildingButtons.PlaceFieldClicked
GUI_BuildingButtons.PlaceFieldClicked=function()
local iD1IUx=XGUIEng.GetCurrentWidgetID()local JLCOx_ak=XGUIEng.GetWidgetNameByID(iD1IUx)
local hPQ=GUI.GetSelectedEntity()
local R1FIoQI=ModuleInterfaceCore.Local.BuildingButtons.Configuration[JLCOx_ak].Bind
if not R1FIoQI then return
GUI_BuildingButtons.PlaceFieldClicked_Orig_InterfaceCore()end;R1FIoQI.Action(iD1IUx,hPQ)end
GUI_BuildingButtons.PlaceFieldMouseOver_Orig_InterfaceCore=GUI_BuildingButtons.PlaceFieldMouseOver
GUI_BuildingButtons.PlaceFieldMouseOver=function()
local NsoTwDs=XGUIEng.GetCurrentWidgetID()local HGli=XGUIEng.GetWidgetNameByID(NsoTwDs)
local iy=GUI.GetSelectedEntity()
local m6SCS0=ModuleInterfaceCore.Local.BuildingButtons.Configuration[HGli].Bind
if not m6SCS0 then return
GUI_BuildingButtons.PlaceFieldMouseOver_Orig_InterfaceCore()end;m6SCS0.Tooltip(NsoTwDs,iy)end
GUI_BuildingButtons.PlaceFieldUpdate_Orig_InterfaceCore=GUI_BuildingButtons.PlaceFieldUpdate
GUI_BuildingButtons.PlaceFieldUpdate=function()
local NUhYw6R4=XGUIEng.GetCurrentWidgetID()local Hv=XGUIEng.GetWidgetNameByID(NUhYw6R4)
local Ch=GUI.GetSelectedEntity()
local urkh=ModuleInterfaceCore.Local.BuildingButtons.Configuration[Hv].Bind;if not urkh then XGUIEng.ShowWidget(NUhYw6R4,1)
XGUIEng.DisableButton(NUhYw6R4,0)
return GUI_BuildingButtons.PlaceFieldUpdate_Orig_InterfaceCore()end
urkh.Update(NUhYw6R4,Ch)end end
function ModuleInterfaceCore.Local:OverrideStartFestival()
GUI_BuildingButtons.StartFestivalClicked_Orig_InterfaceCore=GUI_BuildingButtons.StartFestivalClicked
GUI_BuildingButtons.StartFestivalClicked=function()
local zhzpBSx=XGUIEng.GetCurrentWidgetID()local rHSjalVy=XGUIEng.GetWidgetNameByID(zhzpBSx)
local TjhsnP=GUI.GetSelectedEntity()
local t5jzEd9=ModuleInterfaceCore.Local.BuildingButtons.Configuration[rHSjalVy].Bind
if not t5jzEd9 then return
GUI_BuildingButtons.StartFestivalClicked_Orig_InterfaceCore()end;t5jzEd9.Action(zhzpBSx,TjhsnP)end
GUI_BuildingButtons.StartFestivalMouseOver_Orig_InterfaceCore=GUI_BuildingButtons.StartFestivalMouseOver
GUI_BuildingButtons.StartFestivalMouseOver=function()
local JZAU2=XGUIEng.GetCurrentWidgetID()local zPXTTg=XGUIEng.GetWidgetNameByID(JZAU2)
local seMLr=GUI.GetSelectedEntity()
local qX=ModuleInterfaceCore.Local.BuildingButtons.Configuration[zPXTTg].Bind
if not qX then return
GUI_BuildingButtons.StartFestivalMouseOver_Orig_InterfaceCore()end;qX.Tooltip(JZAU2,seMLr)end
GUI_BuildingButtons.StartFestivalUpdate_Orig_InterfaceCore=GUI_BuildingButtons.StartFestivalUpdate
GUI_BuildingButtons.StartFestivalUpdate=function()
local h_8=XGUIEng.GetCurrentWidgetID()local xL7OTb=XGUIEng.GetWidgetNameByID(h_8)
local w8T3f=GUI.GetSelectedEntity()
local K=ModuleInterfaceCore.Local.BuildingButtons.Configuration[xL7OTb].Bind
if not K then SetIcon(h_8,{4,15})XGUIEng.ShowWidget(h_8,1)
XGUIEng.DisableButton(h_8,0)
return GUI_BuildingButtons.StartFestivalUpdate_Orig_InterfaceCore()end;K.Update(h_8,w8T3f)end end
function ModuleInterfaceCore.Local:OverrideStartTheatrePlay()
GUI_BuildingButtons.StartTheatrePlayClicked_Orig_InterfaceCore=GUI_BuildingButtons.StartTheatrePlayClicked
GUI_BuildingButtons.StartTheatrePlayClicked=function()
local qL=XGUIEng.GetCurrentWidgetID()local vfIyB=XGUIEng.GetWidgetNameByID(qL)
local quNsijN=GUI.GetSelectedEntity()
local QUh2tc=ModuleInterfaceCore.Local.BuildingButtons.Configuration[vfIyB].Bind
if not QUh2tc then return
GUI_BuildingButtons.StartTheatrePlayClicked_Orig_InterfaceCore()end;QUh2tc.Action(qL,quNsijN)end
GUI_BuildingButtons.StartTheatrePlayMouseOver_Orig_InterfaceCore=GUI_BuildingButtons.StartTheatrePlayMouseOver
GUI_BuildingButtons.StartTheatrePlayMouseOver=function()
local qboV=XGUIEng.GetCurrentWidgetID()local nSBOx7=XGUIEng.GetWidgetNameByID(qboV)
local u=GUI.GetSelectedEntity()
local K=ModuleInterfaceCore.Local.BuildingButtons.Configuration[nSBOx7].Bind
if not K then return
GUI_BuildingButtons.StartTheatrePlayMouseOver_Orig_InterfaceCore()end;K.Tooltip(qboV,u)end
GUI_BuildingButtons.StartTheatrePlayUpdate_Orig_InterfaceCore=GUI_BuildingButtons.StartTheatrePlayUpdate
GUI_BuildingButtons.StartTheatrePlayUpdate=function()
local i1=XGUIEng.GetCurrentWidgetID()local zz1QI=XGUIEng.GetWidgetNameByID(i1)
local kFTAh=GUI.GetSelectedEntity()
local LBf=ModuleInterfaceCore.Local.BuildingButtons.Configuration[zz1QI].Bind
if not LBf then SetIcon(i1,{16,2})XGUIEng.ShowWidget(i1,1)
XGUIEng.DisableButton(i1,0)
return GUI_BuildingButtons.StartTheatrePlayUpdate_Orig_InterfaceCore()end;LBf.Update(i1,kFTAh)end end
function ModuleInterfaceCore.Local:OverrideUpgradeTurret()
GUI_BuildingButtons.UpgradeTurretClicked_Orig_InterfaceCore=GUI_BuildingButtons.UpgradeTurretClicked
GUI_BuildingButtons.UpgradeTurretClicked=function()
local dijn4Ph=XGUIEng.GetCurrentWidgetID()local CO1=XGUIEng.GetWidgetNameByID(dijn4Ph)
local RlZo=GUI.GetSelectedEntity()
local SUn=ModuleInterfaceCore.Local.BuildingButtons.Configuration[CO1].Bind;if not SUn then
return GUI_BuildingButtons.UpgradeTurretClicked_Orig_InterfaceCore()end
SUn.Action(dijn4Ph,RlZo)end
GUI_BuildingButtons.UpgradeTurretMouseOver_Orig_InterfaceCore=GUI_BuildingButtons.UpgradeTurretMouseOver
GUI_BuildingButtons.UpgradeTurretMouseOver=function()
local Ib4=XGUIEng.GetCurrentWidgetID()local fjV1G2=XGUIEng.GetWidgetNameByID(Ib4)
local Do=GUI.GetSelectedEntity()
local _=ModuleInterfaceCore.Local.BuildingButtons.Configuration[fjV1G2].Bind;if not _ then
return GUI_BuildingButtons.UpgradeTurretMouseOver_Orig_InterfaceCore()end;_.Tooltip(Ib4,Do)end
GUI_BuildingButtons.UpgradeTurretUpdate_Orig_InterfaceCore=GUI_BuildingButtons.UpgradeTurretUpdate
GUI_BuildingButtons.UpgradeTurretUpdate=function()
local TqYJ4=XGUIEng.GetCurrentWidgetID()local DI=XGUIEng.GetWidgetNameByID(TqYJ4)
local b=GUI.GetSelectedEntity()
local E=ModuleInterfaceCore.Local.BuildingButtons.Configuration[DI].Bind;if not E then XGUIEng.ShowWidget(TqYJ4,1)
XGUIEng.DisableButton(TqYJ4,0)
return GUI_BuildingButtons.UpgradeTurretUpdate_Orig_InterfaceCore()end
E.Update(TqYJ4,b)end end
function ModuleInterfaceCore.Local:OverrideBuySiegeEngineCart()
GUI_BuildingButtons.BuySiegeEngineCartClicked_Orig_InterfaceCore=GUI_BuildingButtons.BuySiegeEngineCartClicked
GUI_BuildingButtons.BuySiegeEngineCartClicked=function(KMw7_i1s)
local CQi=XGUIEng.GetCurrentWidgetID()local nHlJ=XGUIEng.GetWidgetNameByID(CQi)
local lw4Q7kbl=GUI.GetSelectedEntity()local IN
if
nHlJ=="BuyCatapultCart"or nHlJ=="BuySiegeTowerCart"or nHlJ=="BuyBatteringRamCart"then
IN=ModuleInterfaceCore.Local.BuildingButtons.Configuration[nHlJ].Bind end
if not IN then return
GUI_BuildingButtons.BuySiegeEngineCartClicked_Orig_InterfaceCore(KMw7_i1s)end;IN.Action(CQi,lw4Q7kbl)end
GUI_BuildingButtons.BuySiegeEngineCartMouseOver_Orig_InterfaceCore=GUI_BuildingButtons.BuySiegeEngineCartMouseOver
GUI_BuildingButtons.BuySiegeEngineCartMouseOver=function(QYf1,RfsnisO)
local lvW2ga=XGUIEng.GetCurrentWidgetID()local T7RKP=XGUIEng.GetWidgetNameByID(lvW2ga)
local _L6Bs=GUI.GetSelectedEntity()local SH
if
T7RKP=="BuyCatapultCart"or T7RKP=="BuySiegeTowerCart"or T7RKP=="BuyBatteringRamCart"then
SH=ModuleInterfaceCore.Local.BuildingButtons.Configuration[T7RKP].Bind end
if not SH then return
GUI_BuildingButtons.BuySiegeEngineCartMouseOver_Orig_InterfaceCore(QYf1,RfsnisO)end;SH.Tooltip(lvW2ga,_L6Bs)end
GUI_BuildingButtons.BuySiegeEngineCartUpdate_Orig_InterfaceCore=GUI_BuildingButtons.BuySiegeEngineCartUpdate
GUI_BuildingButtons.BuySiegeEngineCartUpdate=function(wU4wYbA9)
local fFeQcIM=XGUIEng.GetCurrentWidgetID()local JEHSHPh3=XGUIEng.GetWidgetNameByID(fFeQcIM)
local bb=GUI.GetSelectedEntity()local o5e6fP
if

JEHSHPh3 =="BuyCatapultCart"or JEHSHPh3 =="BuySiegeTowerCart"or JEHSHPh3 =="BuyBatteringRamCart"then
o5e6fP=ModuleInterfaceCore.Local.BuildingButtons.Configuration[JEHSHPh3].Bind end
if not o5e6fP then
if JEHSHPh3 =="BuyBatteringRamCart"then SetIcon(fFeQcIM,{9,2})elseif JEHSHPh3 ==
"BuySiegeTowerCart"then SetIcon(fFeQcIM,{9,3})elseif JEHSHPh3 =="BuyCatapultCart"then
SetIcon(fFeQcIM,{9,1})end;XGUIEng.ShowWidget(fFeQcIM,1)
XGUIEng.DisableButton(fFeQcIM,0)return
GUI_BuildingButtons.BuySiegeEngineCartUpdate_Orig_InterfaceCore(wU4wYbA9)end;o5e6fP.Update(fFeQcIM,bb)end end
function ModuleInterfaceCore.Local:InitBackupPositions()
for iq7ol,eMV in
pairs(self.BuildingButtons.Configuration)do
local WDTNkTD,Oejsws=XGUIEng.GetWidgetLocalPosition("/InGame/Root/Normal/BuildingButtons/"..iq7ol)
self.BuildingButtons.Configuration[iq7ol].OriginalPosition={WDTNkTD,Oejsws}end end
function ModuleInterfaceCore.Local:GetButtonsForOverwrite(CkD73N0,PlwhaRKJ)local Caz4NM4Z={}
local XVxxx=Logic.GetEntityType(CkD73N0)local hD=Logic.GetEntityTypeName(XVxxx)
for G5BuU5,AfwsY in
pairs(self.BuildingButtons.Configuration)do if#Caz4NM4Z==PlwhaRKJ then break end
if
not hD:find(AfwsY.TypeExclusion)then table.insert(Caz4NM4Z,G5BuU5)end end;assert(#Caz4NM4Z==PlwhaRKJ)
table.sort(Caz4NM4Z)return Caz4NM4Z end
function ModuleInterfaceCore.Local:AddButtonBinding(T,WZs,ITdz,AjfoUo,Er9zidsB,X)if not
self.BuildingButtons.Bindings[T]then
self.BuildingButtons.Bindings[T]={}end
if#
self.BuildingButtons.Bindings[T]<6 then self.BuildingButtons.BindingCounter=
self.BuildingButtons.BindingCounter+1
table.insert(self.BuildingButtons.Bindings[T],{ID=self.BuildingButtons.BindingCounter,Position={WZs,ITdz},Action=AjfoUo,Tooltip=Er9zidsB,Update=X})return self.BuildingButtons.BindingCounter end;return 0 end
function ModuleInterfaceCore.Local:RemoveButtonBinding(dR,JFXtQwy)if not
self.BuildingButtons.Bindings[dR]then
self.BuildingButtons.Bindings[dR]={}end
for uMV17h0=#
self.BuildingButtons.Bindings[dR],1,-1 do if
self.BuildingButtons.Bindings[dR][uMV17h0].ID==JFXtQwy then
table.remove(self.BuildingButtons.Bindings[dR],uMV17h0)end end end
function ModuleInterfaceCore.Local:BindButtons(E2NZK)if E2NZK==nil or E2NZK==0 or
(
Logic.IsBuilding(E2NZK)==0 and not Logic.IsWall(E2NZK))then
return self:UnbindButtons()end
local WNWWe=Logic.GetEntityName(E2NZK)local zMzjn3lk=Logic.GetEntityType(E2NZK)local Trkkpmd;if
self.BuildingButtons.Bindings[WNWWe]then Trkkpmd=WNWWe end
if not Trkkpmd and
self.BuildingButtons.Bindings[zMzjn3lk]then Trkkpmd=zMzjn3lk end;if
not Trkkpmd and self.BuildingButtons.Bindings[0]then Trkkpmd=0 end
if Trkkpmd then
local L=self:GetButtonsForOverwrite(E2NZK,#
self.BuildingButtons.Bindings[Trkkpmd])local GGv=0
for ZIzh4Si=1,#self.BuildingButtons.Bindings[Trkkpmd]do
self.BuildingButtons.Configuration[L[ZIzh4Si]].Bind=self.BuildingButtons.Bindings[Trkkpmd][ZIzh4Si]
XGUIEng.ShowWidget("/InGame/Root/Normal/BuildingButtons/"..L[ZIzh4Si],1)
XGUIEng.DisableButton("/InGame/Root/Normal/BuildingButtons/"..L[ZIzh4Si],0)
local c8D4n81=self.BuildingButtons.Bindings[Trkkpmd][ZIzh4Si].Position
if not c8D4n81[1]or not c8D4n81[2]then local cSjJHx={12,296}c8D4n81[1]=
cSjJHx[1]+ (64*GGv)c8D4n81[2]=cSjJHx[2]GGv=GGv+1 end
XGUIEng.SetWidgetLocalPosition("/InGame/Root/Normal/BuildingButtons/"..L[ZIzh4Si],c8D4n81[1],c8D4n81[2])end end end
function ModuleInterfaceCore.Local:UnbindButtons()
for fa,M in
pairs(self.BuildingButtons.Configuration)do
local dIZlrvD=self.BuildingButtons.Configuration[fa].OriginalPosition;if dIZlrvD then
XGUIEng.SetWidgetLocalPosition("/InGame/Root/Normal/BuildingButtons/"..fa,dIZlrvD[1],dIZlrvD[2])end;self.BuildingButtons.Configuration[fa].Bind=
nil end end
function ModuleInterfaceCore.Local:DisplaySaveButtons()
if self.ForbidRegularSave then
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/QuickSave",0)
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/SaveGame",0)else
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/QuickSave",1)
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/SaveGame",1)end end
function ModuleInterfaceCore.Local:DisplayInterfaceButton(jQgsATKd,aBbGg)self.HiddenWidgets[jQgsATKd]=
aBbGg==true
XGUIEng.ShowWidget(jQgsATKd,(aBbGg==true and 0)or 1)end
function ModuleInterfaceCore.Local:UpdateHiddenWidgets()for D9,G in pairs(self.HiddenWidgets)do
XGUIEng.ShowWidget(D9,0)end end
function ModuleInterfaceCore.Local:OverrideMissionGoodCounter()
StartMissionGoodOrEntityCounter=function(gE,QgC)
local CYoa="/InGame/Root/Normal/MissionGoodOrEntityCounter/Icon"local K3ipRr="/InGame/Root/Normal/MissionGoodOrEntityCounter"if
type(gE[3])=="string"then
ModuleInterfaceCore.Local:SetIcon(CYoa,gE,64,gE[3])else SetIcon(CYoa,gE)end
g_MissionGoodOrEntityCounterAmountToReach=QgC;g_MissionGoodOrEntityCounterIcon=gE
XGUIEng.ShowWidget(K3ipRr,1)end end
function ModuleInterfaceCore.Local:OverrideUpdateClaimTerritory()
GUI_Knight.ClaimTerritoryUpdate_Orig_QSB_InterfaceCore=GUI_Knight.ClaimTerritoryUpdate
GUI_Knight.ClaimTerritoryUpdate=function()
GUI_Knight.ClaimTerritoryUpdate_Orig_QSB_InterfaceCore()
local F2tY="/InGame/Root/Normal/AlignBottomRight/DialogButtons/Knight/ClaimTerritory"
if
ModuleInterfaceCore.Local.HiddenWidgets[F2tY]==true then XGUIEng.ShowWidget(F2tY,0)return true end end end
function ModuleInterfaceCore.Local:SetPlayerPortraitByPrimaryKnight(rb21L2)
local o_v255=Logic.GetKnightID(rb21L2)local wUVm="H_NPC_Generic_Trader"
if o_v255 ~=0 then
local VQ=Logic.GetEntityType(o_v255)local oTYNsnP=Logic.GetEntityTypeName(VQ)
wUVm="H"..
string.sub(oTYNsnP,2,8).."_"..string.sub(oTYNsnP,9)
if not Models["Heads_"..wUVm]then wUVm="H_NPC_Generic_Trader"end end;g_PlayerPortrait[rb21L2]=wUVm end
function ModuleInterfaceCore.Local:SetPlayerPortraitBySettler(I,L)
local mR5gwW={["U_KnightChivalry"]="H_Knight_Chivalry",["U_KnightHealing"]="H_Knight_Healing",["U_KnightPlunder"]="H_Knight_Plunder",["U_KnightRedPrince"]="H_Knight_RedPrince",["U_KnightSabatta"]="H_Knight_Sabatt",["U_KnightSong"]="H_Knight_Song",["U_KnightTrading"]="H_Knight_Trading",["U_KnightWisdom"]="H_Knight_Wisdom",["U_NPC_Amma_NE"]="H_NPC_Amma",["U_NPC_Castellan_ME"]="H_NPC_Castellan_ME",["U_NPC_Castellan_NA"]="H_NPC_Castellan_NA",["U_NPC_Castellan_NE"]="H_NPC_Castellan_NE",["U_NPC_Castellan_SE"]="H_NPC_Castellan_SE",["U_MilitaryBandit_Ranged_ME"]="H_NPC_Mercenary_ME",["U_MilitaryBandit_Melee_NA"]="H_NPC_Mercenary_NA",["U_MilitaryBandit_Melee_NE"]="H_NPC_Mercenary_NE",["U_MilitaryBandit_Melee_SE"]="H_NPC_Mercenary_SE",["U_NPC_Monk_ME"]="H_NPC_Monk_ME",["U_NPC_Monk_NA"]="H_NPC_Monk_NA",["U_NPC_Monk_NE"]="H_NPC_Monk_NE",["U_NPC_Monk_SE"]="H_NPC_Monk_SE",["U_NPC_Villager01_ME"]="H_NPC_Villager01_ME",["U_NPC_Villager01_NA"]="H_NPC_Villager01_NA",["U_NPC_Villager01_NE"]="H_NPC_Villager01_NE",["U_NPC_Villager01_SE"]="H_NPC_Villager01_SE"}
if g_GameExtraNo>0 then mR5gwW["U_KnightPraphat"]="H_Knight_Praphat"
mR5gwW["U_KnightSaraya"]="H_Knight_Saraya"mR5gwW["U_KnightKhana"]="H_Knight_Khana"
mR5gwW["U_MilitaryBandit_Melee_AS"]="H_NPC_Mercenary_AS"mR5gwW["U_NPC_Castellan_AS"]="H_NPC_Castellan_AS"
mR5gwW["U_NPC_Villager_AS"]="H_NPC_Villager_AS"mR5gwW["U_NPC_Monk_AS"]="H_NPC_Monk_AS"
mR5gwW["U_NPC_Monk_Khana"]="H_NPC_Monk_Khana"end;local DfbW="H_NPC_Generic_Trader"local sh=GetID(L)
if sh~=0 then
local rrFLbCtj=Logic.GetEntityType(sh)local YcPea0vg=Logic.GetEntityTypeName(rrFLbCtj)DfbW=
mR5gwW[YcPea0vg]or"H_NPC_Generic_Trader"if not DfbW then
DfbW="H_NPC_Generic_Trader"end end;g_PlayerPortrait[I]=DfbW end
function ModuleInterfaceCore.Local:SetPlayerPortraitByModelName(usLpLoaH,e7dv)
if not
Models["Heads_"..tostring(e7dv)]then e7dv="H_NPC_Generic_Trader"end;g_PlayerPortrait[usLpLoaH]=e7dv end
function ModuleInterfaceCore.Local:SetIcon(inx0,A5k5yt,B7SHDx7h,EEpoeR)local _k=""if
type(A5k5yt[3])=="number"then
_k=((A5k5yt[3]>0 and A5k5yt[3]+1)or"")end
if EEpoeR==nil then EEpoeR="icons"end;if B7SHDx7h==nil then B7SHDx7h=64 end;if B7SHDx7h==44 then
EEpoeR=EEpoeR.._k..".png"end;if B7SHDx7h==64 then
EEpoeR=EEpoeR.."big".._k..".png"end;if B7SHDx7h==128 then
EEpoeR=EEpoeR.."verybig".._k..".png"end;local Ef,KfM,Vd,Oynw
Ef=(A5k5yt[1]-1)*B7SHDx7h;Vd=(A5k5yt[2]-1)*B7SHDx7h
KfM=(A5k5yt[1])*B7SHDx7h;Oynw=(A5k5yt[2])*B7SHDx7h;State=1;if
XGUIEng.IsButton(inx0)==1 then State=7 end
XGUIEng.SetMaterialAlpha(inx0,State,255)XGUIEng.SetMaterialTexture(inx0,State,EEpoeR)
XGUIEng.SetMaterialUV(inx0,State,Ef,Vd,KfM,Oynw)end
function ModuleInterfaceCore.Local:TextNormal(QBO,s4ggux,hrVI4meU)if QBO and
QBO:find("[A-Za-z0-9]+/[A-Za-z0-9]+$")then
QBO=XGUIEng.GetStringTableText(QBO)end;if s4ggux and
s4ggux:find("[A-Za-z0-9]+/[A-Za-z0-9]+$")then
s4ggux=XGUIEng.GetStringTableText(s4ggux)end
hrVI4meU=hrVI4meU or""
if
hrVI4meU and hrVI4meU:find("[A-Za-z0-9]+/[A-Za-z0-9]+$")then hrVI4meU=XGUIEng.GetStringTableText(hrVI4meU)end;local xEq6TAF="/InGame/Root/Normal/TooltipNormal"
local UIjls=XGUIEng.GetWidgetID(xEq6TAF)
local jdLnB0vD=XGUIEng.GetWidgetID(xEq6TAF.."/FadeIn/Name")
local PSlD=XGUIEng.GetWidgetID(xEq6TAF.."/FadeIn/Text")
local nN=XGUIEng.GetWidgetID(xEq6TAF.."/FadeIn/BG")local J=XGUIEng.GetWidgetID(xEq6TAF.."/FadeIn")
local A=XGUIEng.GetCurrentWidgetID()local g3Qeqnr=(QBO and QBO)or""
local qHpY64=(s4ggux and s4ggux)or""local z=""if
XGUIEng.IsButtonDisabled(A)==1 and hrVI4meU then
z=z.."{cr}{@color:255,32,32,255}"..hrVI4meU end
XGUIEng.SetText(jdLnB0vD,"{center}"..g3Qeqnr)XGUIEng.SetText(PSlD,qHpY64 ..z)
local qccJ5b=XGUIEng.GetTextHeight(PSlD,true)local ARuba,Wo53nZ=XGUIEng.GetWidgetSize(PSlD)
XGUIEng.SetWidgetSize(PSlD,ARuba,qccJ5b)GUI_Tooltip.ResizeBG(nN,PSlD)local XRfQ={nN}
GUI_Tooltip.SetPosition(UIjls,XRfQ,A)GUI_Tooltip.FadeInTooltip(J)end
function ModuleInterfaceCore.Local:TextCosts(gFPRdEC,lw9gLt3,T,I5,JmE)I5=I5 or{}local s4={}for nbqmx=1,4,1 do
s4[nbqmx]=I5[nbqmx]end
if
gFPRdEC and gFPRdEC:find("[A-Za-z0-9]+/[A-Za-z0-9]+$")then gFPRdEC=XGUIEng.GetStringTableText(gFPRdEC)end;if lw9gLt3 and lw9gLt3:find("[A-Za-z0-9]+/[A-Za-z0-9]+$")then
lw9gLt3=XGUIEng.GetStringTableText(lw9gLt3)end
if T and
T:find("^[A-Za-z0-9]+/[A-Za-z0-9]+$")then T=XGUIEng.GetStringTableText(T)end;local FFG="/InGame/Root/Normal/TooltipBuy"
local a31jEAS=XGUIEng.GetWidgetID(FFG)
local LS4h=XGUIEng.GetWidgetID(FFG.."/FadeIn/Name")
local eux092_P=XGUIEng.GetWidgetID(FFG.."/FadeIn/Text")local ZA9=XGUIEng.GetWidgetID(FFG.."/FadeIn/BG")local hWgmxm=XGUIEng.GetWidgetID(
FFG.."/FadeIn")
local UBg54E=XGUIEng.GetWidgetID(FFG.."/Costs")local gQGq=XGUIEng.GetCurrentWidgetID()local OyHc5FEv=
(gFPRdEC and gFPRdEC)or""
local Dn1Xi=(lw9gLt3 and lw9gLt3)or""local _gGmBBE=""if
XGUIEng.IsButtonDisabled(gQGq)==1 and T then
_gGmBBE=_gGmBBE.."{cr}{@color:255,32,32,255}"..T end
XGUIEng.SetText(LS4h,"{center}"..OyHc5FEv)XGUIEng.SetText(eux092_P,Dn1Xi.._gGmBBE)
local rIX4=XGUIEng.GetTextHeight(eux092_P,true)local AI14eFhp,iW2O=XGUIEng.GetWidgetSize(eux092_P)
XGUIEng.SetWidgetSize(eux092_P,AI14eFhp,rIX4)GUI_Tooltip.ResizeBG(ZA9,eux092_P)
GUI_Tooltip.SetCosts(UBg54E,s4,JmE)local Gdp={a31jEAS,UBg54E,ZA9}
GUI_Tooltip.SetPosition(a31jEAS,Gdp,gQGq,nil,true)
GUI_Tooltip.OrderTooltip(Gdp,hWgmxm,UBg54E,gQGq,ZA9)GUI_Tooltip.FadeInTooltip(hWgmxm)end
function ModuleInterfaceCore.Local:SetupHackRegisterHotkey()
function g_KeyBindingsOptions:OnShow()if
Game~=nil then
XGUIEng.ShowWidget("/InGame/KeyBindingsMain/Backdrop",1)else
XGUIEng.ShowWidget("/InGame/KeyBindingsMain/Backdrop",0)end
if
g_KeyBindingsOptions.Descriptions==nil then g_KeyBindingsOptions.Descriptions={}
DescRegister("MenuInGame")DescRegister("MenuDiplomacy")
DescRegister("MenuProduction")DescRegister("MenuPromotion")
DescRegister("MenuWeather")DescRegister("ToggleOutstockInformations")
DescRegister("JumpMarketplace")DescRegister("JumpMinimapEvent")
DescRegister("BuildingUpgrade")DescRegister("BuildLastPlaced")
DescRegister("BuildStreet")DescRegister("BuildTrail")DescRegister("KnockDown")
DescRegister("MilitaryAttack")DescRegister("MilitaryStandGround")
DescRegister("MilitaryGroupAdd")DescRegister("MilitaryGroupSelect")
DescRegister("MilitaryGroupStore")DescRegister("MilitaryToggleUnits")
DescRegister("UnitSelect")DescRegister("UnitSelectToggle")
DescRegister("UnitSelectSameType")DescRegister("StartChat")DescRegister("StopChat")
DescRegister("QuickSave")DescRegister("QuickLoad")
DescRegister("TogglePause")DescRegister("RotateBuilding")
DescRegister("ExitGame")DescRegister("Screenshot")
DescRegister("ResetCamera")DescRegister("CameraMove")
DescRegister("CameraMoveMouse")DescRegister("CameraZoom")
DescRegister("CameraZoomMouse")DescRegister("CameraRotate")
for IWQcC,cvRh in
pairs(ModuleInterfaceCore.Local.HotkeyDescriptions)do
if cvRh then cvRh[1]=
(type(cvRh[1])=="table"and API.Localize(cvRh[1]))or cvRh[1]cvRh[2]=
(
type(cvRh[2])=="table"and API.Localize(cvRh[2]))or cvRh[2]
table.insert(g_KeyBindingsOptions.Descriptions,1,cvRh)end end end
XGUIEng.ListBoxPopAll(g_KeyBindingsOptions.Widget.ShortcutList)
XGUIEng.ListBoxPopAll(g_KeyBindingsOptions.Widget.ActionList)
for W9yaJm,oJ1ec in ipairs(g_KeyBindingsOptions.Descriptions)do
XGUIEng.ListBoxPushItem(g_KeyBindingsOptions.Widget.ShortcutList,oJ1ec[1])
XGUIEng.ListBoxPushItem(g_KeyBindingsOptions.Widget.ActionList,oJ1ec[2])end end end;Swift:RegisterModule(ModuleInterfaceCore)