SCP.Selection={}
ModuleSelection={Properties={Name="ModuleSelection"},Global={TrebuchetIDToCart={},SelectedEntities={}},Local={SelectedEntities={},ThiefRelease=false,SiegeEngineRelease=true,MilitaryRelease=true,Tooltips={KnightButton={Title={de="Ritter selektieren",en="Select Knight"},Text={de="- Klick selektiert den Ritter {cr}- Doppelklick springt zum Ritter{cr}- STRG halten selektiert alle Ritter",en="- Click selects the knight {cr}- Double click jumps to knight{cr}- Press CTRL to select all knights"}},BattalionButton={Title={de="Militär selektieren",en="Select Units"},Text={de="- Selektiert alle Militäreinheiten {cr}- SHIFT halten um auch Diebe, Munitionswagen und Trebuchets auszuwählen",en="- Selects all military units {cr}- Press SHIFT to additionally select ammunition carts, thieves and trebuchets"}},ReleaseSoldiers={Title={de="Militär entlassen",en="Release military unit"},Text={de="- Eine Militäreinheit entlassen {cr}- Soldaten werden nacheinander entlassen",en="- Dismiss a military unit {cr}- Soldiers will be dismissed each after another"},Disabled={de="Kann nicht entlassen werden!",en="Releasing is impossible!"}},TrebuchetCart={Title={de="Trebuchetwagen",en="Trebuchet cart"},Text={de="- Kann einmalig zum Trebuchet ausgebaut werden",en="- Can uniquely be transmuted into a trebuchet"}},Trebuchet={Title={de="Trebuchet",en="Trebuchet"},Text={de="- Kann über weite Strecken Gebäude angreifen {cr}- Kann Gebäude in Brand stecken {cr}- Trebuchet kann manuell zurückgeschickt werden",en="- Can perform long range attacks on buildings {cr}- Can set buildings on fire {cr}- The trebuchet can be manually send back to the city"}}}},Shared={}}
function ModuleSelection.Global:OnGameStart()
QSB.ScriptEvents.SelectionChanged=API.RegisterScriptEvent("Event_SelectionChanged")
API.RegisterScriptCommand("Cmd_SelectionDestroyEntity",SCP.Selection.DestroyEntity)
API.RegisterScriptCommand("Cmd_SelectionSetTaskList",SCP.Selection.SetTaskList)
API.RegisterScriptCommand("Cmd_SelectionErectTrebuchet",SCP.Selection.ErectTrebuchet)
API.RegisterScriptCommand("Cmd_SelectionDisambleTrebuchet",SCP.Selection.DisambleTrebuchet)for QDnlt=1,8 do self.SelectedEntities[QDnlt]={}end end
function ModuleSelection.Global:OnEvent(LmcA2auZ,Q,...)
if
LmcA2auZ==QSB.ScriptEvents.SelectionChanged then self.SelectedEntities[arg[1]]=arg[3]end end
function ModuleSelection.Global:MilitaryDisambleTrebuchet(ZA)
local _IQQ,XpkjA,pVRj=Logic.EntityGetPos(ZA)local fuZ3z86=Logic.EntityGetPlayer(ZA)if GameCallback_QSB_OnDisambleTrebuchet then
GameCallback_QSB_OnDisambleTrebuchet(ZA,fuZ3z86,_IQQ,XpkjA,pVRj)return end
Logic.CreateEffect(EGL_Effects.E_Shockwave01,_IQQ,XpkjA,0)Logic.SetEntityInvulnerabilityFlag(ZA,1)
Logic.SetEntitySelectableFlag(ZA,0)Logic.SetVisible(ZA,false)
local er=self.TrebuchetIDToCart[ZA]
if er~=nil then Logic.SetEntityInvulnerabilityFlag(er,0)
Logic.SetEntitySelectableFlag(er,1)Logic.SetVisible(er,true)else
er=Logic.CreateEntity(Entities.U_SiegeEngineCart,_IQQ,XpkjA,0,fuZ3z86)self.TrebuchetIDToCart[ZA]=er end;Logic.DEBUG_SetSettlerPosition(er,_IQQ,XpkjA)
Logic.SetTaskList(er,TaskLists.TL_NPC_IDLE)
Logic.ExecuteInLuaLocalState([[
        GUI.SelectEntity(]]..er..[[)
    ]])end
function ModuleSelection.Global:MilitaryErectTrebuchet(DFb100j)
local XL_,WYdR,QKKks_zt=Logic.EntityGetPos(DFb100j)local Are7xU=Logic.EntityGetPlayer(DFb100j)
Logic.CreateEffect(EGL_Effects.E_Shockwave01,XL_,WYdR,0)Logic.SetEntityInvulnerabilityFlag(DFb100j,1)
Logic.SetEntitySelectableFlag(DFb100j,0)Logic.SetVisible(DFb100j,false)local yxjl
for ZG,Vu0cCAf in
pairs(self.TrebuchetIDToCart)do if Vu0cCAf==DFb100j then yxjl=tonumber(ZG)end end
if yxjl==nil then
yxjl=Logic.CreateEntity(Entities.U_Trebuchet,XL_,WYdR,0,Are7xU)self.TrebuchetIDToCart[yxjl]=DFb100j end;Logic.SetEntityInvulnerabilityFlag(yxjl,0)
Logic.SetEntitySelectableFlag(yxjl,1)Logic.SetVisible(yxjl,true)
Logic.DEBUG_SetSettlerPosition(yxjl,XL_,WYdR)
Logic.ExecuteInLuaLocalState([[
        GUI.SelectEntity(]]..yxjl..[[)
    ]])end
function ModuleSelection.Local:OnGameStart()
QSB.ScriptEvents.SelectionChanged=API.RegisterScriptEvent("Event_SelectionChanged")if API.IsHistoryEditionNetworkGame()then return end
self:OverrideSelection()self:OverwriteMilitaryCommands()
self:OverwriteMilitaryErect()self:OverwriteMilitaryDisamble()
self:OverwriteMultiselectIcon()self:OverwriteMilitaryDismount()
self:OverwriteThiefDeliver()self:OverwriteSelectKnight()
self:OverwriteSelectAllUnits()self:OverwriteNamesAndDescription()end
function ModuleSelection.Local:OverrideSelection()
GameCallback_GUI_SelectionChanged_Orig_ModuleSelection=GameCallback_GUI_SelectionChanged
GameCallback_GUI_SelectionChanged=function(q)
GameCallback_GUI_SelectionChanged_Orig_ModuleSelection(q)
ModuleSelection.Local:OnSelectionCanged(q)end end
function ModuleSelection.Local:OverwriteMilitaryCommands()
GUI_Military.StandGroundClicked=function()
Sound.FXPlay2DSound("ui\\menu_click")local kP7O5={GUI.GetSelectedEntities()}
for lqT=1,#kP7O5 do
local mP3mlD=kP7O5[lqT]local PrPyxMK=Logic.GetEntityType(mP3mlD)
GUI.SendCommandStationaryDefend(mP3mlD)if PrPyxMK==Entities.U_Trebuchet then
API.BroadcastScriptCommand(QSB.ScriptCommands.SelectionSetTaskList,mP3mlD,TaskLists.TL_NPC_IDLE)end end end
GUI_Military.StandGroundUpdate=function()
local tczrIB="/InGame/Root/Normal/AlignBottomRight/DialogButtons/Military/Attack"local a={GUI.GetSelectedEntities()}
SetIcon(tczrIB,{12,4})
if#a==1 then local wqU76o=a[1]local LB1Z=Logic.GetEntityType(wqU76o)
if LB1Z==
Entities.U_Trebuchet then
if Logic.GetAmmunitionAmount(wqU76o)>0 then
XGUIEng.ShowWidget(tczrIB,0)else XGUIEng.ShowWidget(tczrIB,1)end;SetIcon(tczrIB,{1,10})else
XGUIEng.ShowWidget(tczrIB,1)end end end end
function ModuleSelection.Local:OverwriteMilitaryErect()
GUI_Military.ErectClicked_Orig_ModuleSelection=GUI_Military.ErectClicked
GUI_Military.ErectClicked=function()
GUI_Military.ErectClicked_Orig_ModuleSelection()local N9L=GUI.GetPlayerID()
local hDc_M={GUI.GetSelectedEntities()}
for qW0lRiD1=1,#hDc_M,1 do local iD1IUx=Logic.GetEntityType(hDc_M[qW0lRiD1])if
iD1IUx==Entities.U_SiegeEngineCart then
API.BroadcastScriptCommand(QSB.ScriptCommands.ErectTrebuchet,hDc_M[qW0lRiD1])end end end
GUI_Military.ErectUpdate_Orig_ModuleSelection=GUI_Military.ErectUpdate
GUI_Military.ErectUpdate=function()local JLCOx_ak=XGUIEng.GetCurrentWidgetID()
local hPQ=GUI.GetSelectedEntity()local R1FIoQI=GUI.GetPlayerID()
local NsoTwDs=Logic.GetEntityType(hPQ)
if NsoTwDs==Entities.U_SiegeEngineCart then
XGUIEng.DisableButton(JLCOx_ak,0)SetIcon(JLCOx_ak,{12,6})elseif NsoTwDs==Entities.U_CannonCart then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons/SiegeEngineCart",1)XGUIEng.DisableButton(JLCOx_ak,0)
SetIcon(JLCOx_ak,{12,6})else
GUI_Military.ErectUpdate_Orig_ModuleSelection()end end
GUI_Military.ErectMouseOver_Orig_ModuleSelection=GUI_Military.ErectMouseOver
GUI_Military.ErectMouseOver=function()local HGli=GUI.GetSelectedEntity()local iy
if
Logic.GetEntityType(HGli)==Entities.U_SiegeEngineCart then iy="ErectCatapult"else
GUI_Military.ErectMouseOver_Orig_ModuleSelection()return end;GUI_Tooltip.TooltipNormal(iy,"Erect")end end
function ModuleSelection.Local:OverwriteMilitaryDisamble()
GUI_Military.DisassembleClicked_Orig_ModuleSelection=GUI_Military.DisassembleClicked
GUI_Military.DisassembleClicked=function()
GUI_Military.DisassembleClicked_Orig_ModuleSelection()local m6SCS0=GUI.GetPlayerID()
local NUhYw6R4={GUI.GetSelectedEntities()}
for Hv=1,#NUhYw6R4,1 do local Ch=Logic.GetEntityType(NUhYw6R4[Hv])if Ch==
Entities.U_Trebuchet then
API.BroadcastScriptCommand(QSB.ScriptCommands.DisambleTrebuchet,NUhYw6R4[Hv])end end end
GUI_Military.DisassembleUpdate_Orig_ModuleSelection=GUI_Military.DisassembleUpdate
GUI_Military.DisassembleUpdate=function()local urkh=XGUIEng.GetCurrentWidgetID()
local zhzpBSx=GUI.GetPlayerID()local rHSjalVy=GUI.GetSelectedEntity()
local TjhsnP=Logic.GetEntityType(rHSjalVy)
if TjhsnP==Entities.U_Trebuchet then
XGUIEng.DisableButton(urkh,0)SetIcon(urkh,{12,9})elseif TjhsnP==Entities.U_MilitaryCannon then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons/SiegeEngine",1)XGUIEng.DisableButton(urkh,0)
SetIcon(urkh,{12,9})else
GUI_Military.DisassembleUpdate_Orig_ModuleSelection()end end end
function ModuleSelection.Local:OnSelectionCanged(t5jzEd9)
local JZAU2=self.SelectedEntities or{}local zPXTTg={GUI.GetSelectedEntities()}
local seMLr=GUI.GetPlayerID()local qX=GUI.GetSelectedEntity()
local h_8=Logic.GetEntityType(qX)
local xL7OTb=Swift:ConvertTableToString(self.SelectedEntities[seMLr]or{})self.SelectedEntities[seMLr]=zPXTTg
local w8T3f=Swift:ConvertTableToString(
self.SelectedEntities[seMLr]or{})
API.SendScriptEvent(QSB.ScriptEvents.SelectionChanged,seMLr,JZAU2[seMLr],zPXTTg)
API.SendScriptEventToGlobal(QSB.ScriptEvents.SelectionChanged,seMLr,JZAU2[seMLr],zPXTTg)
if qX~=nil then
if h_8 ==Entities.U_SiegeEngineCart then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/Selection",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/BGMilitary",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/DialogButtons",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons/SiegeEngineCart",1)elseif h_8 ==Entities.U_Trebuchet then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/Selection",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/BGMilitary",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/DialogButtons",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Military",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Military",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Military/Attack",0)GUI_Military.StrengthUpdate()
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons/SiegeEngine",1)end end end
function ModuleSelection.Local:OverwriteMultiselectIcon()
GUI_MultiSelection.IconUpdate_Orig_ModuleSelection=GUI_MultiSelection.IconUpdate
GUI_MultiSelection.IconUpdate=function()local K=XGUIEng.GetCurrentWidgetID()
local qL=XGUIEng.GetWidgetsMotherID(K)local vfIyB=XGUIEng.GetWidgetNameByID(qL)local quNsijN=vfIyB+0
local QUh2tc=XGUIEng.GetWidgetPathByID(qL)local qboV=QUh2tc.."/Health"
local nSBOx7=g_MultiSelection.EntityList[quNsijN]local u=Logic.GetEntityType(nSBOx7)
local Ki1=Logic.GetEntityHealth(nSBOx7)local zz1QI=Logic.GetEntityMaxHealth(nSBOx7)if
u~=Entities.U_SiegeEngineCart and u~=Entities.U_Trebuchet then
GUI_MultiSelection.IconUpdate_Orig_ModuleSelection()return end;if
Logic.IsEntityAlive(nSBOx7)==false then XGUIEng.ShowWidget(qL,0)
GUI_MultiSelection.CreateEX()return end
SetIcon(K,g_TexturePositions.Entities[u])Ki1=math.floor(Ki1/zz1QI*100)
if Ki1 <50 then local kFTAh=math.floor(2*255*
(Ki1/100))
XGUIEng.SetMaterialColor(qboV,0,255,kFTAh,20,255)else
local LBf=2*255-math.floor(2*255* (Ki1/100))XGUIEng.SetMaterialColor(qboV,0,LBf,255,20,255)end;XGUIEng.SetProgressBarValues(qboV,Ki1,100)end
GUI_MultiSelection.IconMouseOver_Orig_ModuleSelection=GUI_MultiSelection.IconMouseOver
GUI_MultiSelection.IconMouseOver=function()
local dijn4Ph=XGUIEng.GetCurrentWidgetID()local CO1=XGUIEng.GetWidgetsMotherID(dijn4Ph)
local RlZo=XGUIEng.GetWidgetNameByID(CO1)local SUn=tonumber(RlZo)
local Ib4=g_MultiSelection.EntityList[SUn]local fjV1G2=Logic.GetEntityType(Ib4)if
fjV1G2 ~=Entities.U_SiegeEngineCart and fjV1G2 ~=Entities.U_Trebuchet then
GUI_MultiSelection.IconMouseOver_Orig_ModuleSelection()return end
if
fjV1G2 ==Entities.U_SiegeEngineCart then
local Do=API.Localize(ModuleSelection.Local.Tooltips.TrebuchetCart)API.SetTooltipNormal(Do.Title,Do.Text)elseif fjV1G2 ==
Entities.U_Trebuchet then
local _=API.Localize(ModuleSelection.Local.Tooltips.Trebuchet)API.SetTooltipNormal(_.Title,_.Text)end end end
function ModuleSelection.Local:OverwriteMilitaryDismount()
GUI_Military.DismountClicked_Orig_ModuleSelection=GUI_Military.DismountClicked
GUI_Military.DismountClicked=function()local TqYJ4=GUI.GetSelectedEntity()
local DI=Logic.GetEntityType(TqYJ4)local b=Logic.GetGuardedEntityID(TqYJ4)
local E=Logic.GetGuardianEntityID(TqYJ4)if
b~=0 and Logic.EntityGetPlayer(b)~=GUI.GetPlayerID()then
GUI_Military.DismountClicked_Orig_ModuleSelection()return end
if

Logic.IsKnight(TqYJ4)or
Logic.IsEntityInCategory(TqYJ4,EntityCategories.AttackableMerchant)==1 then
GUI_Military.DismountClicked_Orig_ModuleSelection()return end
if Logic.IsLeader(TqYJ4)==1 and b==0 then
if
ModuleSelection.Local.MilitaryRelease then Sound.FXPlay2DSound("ui\\menu_click")
local KMw7_i1s={Logic.GetSoldiersAttachedToLeader(TqYJ4)}
API.BroadcastScriptCommand(QSB.ScriptCommands.SelectionDestroyEntity,KMw7_i1s[#KMw7_i1s])return end end
if





DI==Entities.U_AmmunitionCart or DI==Entities.U_BatteringRamCart or DI==Entities.U_CatapultCart or DI==Entities.U_SiegeTowerCart or DI==Entities.U_MilitaryBatteringRam or Entities.U_MilitaryCatapult or DI==Entities.U_MilitarySiegeTower then
if ModuleSelection.Local.SiegeEngineRelease and E==0 then
Sound.FXPlay2DSound("ui\\menu_click")
API.BroadcastScriptCommand(QSB.ScriptCommands.SelectionDestroyEntity,TqYJ4)else
GUI_Military.DismountClicked_Orig_ModuleSelection()end end end
GUI_Military.DismountUpdate_Orig_ModuleSelection=GUI_Military.DismountUpdate
GUI_Military.DismountUpdate=function()local CQi=XGUIEng.GetCurrentWidgetID()
local nHlJ=GUI.GetSelectedEntity()local lw4Q7kbl=Logic.GetEntityType(nHlJ)
local IN=Logic.GetGuardedEntityID(nHlJ)local QYf1=Logic.GetGuardianEntityID(nHlJ)
SetIcon(CQi,{12,1})
if
IN~=0 and Logic.EntityGetPlayer(IN)~=GUI.GetPlayerID()then XGUIEng.DisableButton(CQi,0)
GUI_Military.DismountUpdate_Orig_ModuleSelection()return end
if
Logic.IsKnight(nHlJ)or
Logic.IsEntityInCategory(nHlJ,EntityCategories.AttackableMerchant)==1 then XGUIEng.DisableButton(CQi,0)
GUI_Military.DismountUpdate_Orig_ModuleSelection()return end;SetIcon(CQi,{14,12})
if lw4Q7kbl==Entities.U_MilitaryLeader then if not
ModuleSelection.Local.MilitaryRelease then XGUIEng.DisableButton(CQi,1)else
XGUIEng.DisableButton(CQi,0)end;return end
if




lw4Q7kbl==Entities.U_AmmunitionCart or
lw4Q7kbl==Entities.U_BatteringRamCart or lw4Q7kbl==Entities.U_CatapultCart or lw4Q7kbl==Entities.U_SiegeTowerCart or lw4Q7kbl==Entities.U_MilitaryBatteringRam or Entities.U_MilitaryCatapult or lw4Q7kbl==Entities.U_MilitarySiegeTower then
if QYf1 ~=0 then SetIcon(CQi,{12,1})
XGUIEng.DisableButton(CQi,0)else
if not ModuleSelection.Local.SiegeEngineRelease then
XGUIEng.DisableButton(CQi,1)else XGUIEng.DisableButton(CQi,0)end end end end end
function ModuleSelection.Local:OverwriteThiefDeliver()
GUI_Thief.ThiefDeliverClicked_Orig_ModuleSelection=GUI_Thief.ThiefDeliverClicked
GUI_Thief.ThiefDeliverClicked=function()if not ModuleSelection.Local.ThiefRelease then
GUI_Thief.ThiefDeliverClicked_Orig_ModuleSelection()return end
Sound.FXPlay2DSound("ui\\menu_click")local RfsnisO=GUI.GetPlayerID()local lvW2ga=GUI.GetSelectedEntity()if

lvW2ga==nil or Logic.GetEntityType(lvW2ga)~=Entities.U_Thief then return end
API.BroadcastScriptCommand(QSB.ScriptCommands.SelectionDestroyEntity,lvW2ga)end
GUI_Thief.ThiefDeliverMouseOver_Orig_ModuleSelection=GUI_Thief.ThiefDeliverMouseOver
GUI_Thief.ThiefDeliverMouseOver=function()if not ModuleSelection.Local.ThiefRelease then
GUI_Thief.ThiefDeliverMouseOver_Orig_ModuleSelection()return end
local T7RKP=API.Localize(ModuleSelection.Local.Tooltips.ReleaseSoldiers)
API.SetTooltipNormal(T7RKP.Title,T7RKP.Text,T7RKP.Disabled)end
GUI_Thief.ThiefDeliverUpdate_Orig_ModuleSelection=GUI_Thief.ThiefDeliverUpdate
GUI_Thief.ThiefDeliverUpdate=function()if not ModuleSelection.Local.ThiefRelease then
GUI_Thief.ThiefDeliverUpdate_Orig_ModuleSelection()return end
local _L6Bs=XGUIEng.GetCurrentWidgetID()local SH=GUI.GetSelectedEntity()
if SH==nil or Logic.GetEntityType(SH)~=
Entities.U_Thief then
XGUIEng.DisableButton(_L6Bs,1)else XGUIEng.DisableButton(_L6Bs,0)end;SetIcon(_L6Bs,{14,12})end end
function ModuleSelection.Local:OverwriteSelectKnight()
GUI_Knight.JumpToButtonClicked=function()
local wU4wYbA9=GUI.GetPlayerID()local fFeQcIM=Logic.GetKnightID(wU4wYbA9)
if fFeQcIM>0 then
g_MultiSelection.EntityList={}g_MultiSelection.Highlighted={}GUI.ClearSelection()
if
XGUIEng.IsModifierPressed(Keys.ModifierControl)then local JEHSHPh3={}Logic.GetKnights(wU4wYbA9,JEHSHPh3)for bb=1,#JEHSHPh3 do
GUI.SelectEntity(JEHSHPh3[bb])end else
GUI.SelectEntity(Logic.GetKnightID(wU4wYbA9))
if
(
(Framework.GetTimeMs()-g_Selection.LastClickTime)<g_Selection.MaxDoubleClickTime)then local o5e6fP=GetPosition(fFeQcIM)
Camera.RTS_SetLookAtPosition(o5e6fP.X,o5e6fP.Y)else Sound.FXPlay2DSound("ui\\mini_knight")end;g_Selection.LastClickTime=Framework.GetTimeMs()end
GUI_MultiSelection.CreateMultiSelection(g_SelectionChangedSource.User)else GUI.AddNote("Debug: You do not have a knight")end end end
function ModuleSelection.Local:OverwriteSelectAllUnits()
GUI_MultiSelection.SelectAllPlayerUnitsClicked=function()
if
XGUIEng.IsModifierPressed(Keys.ModifierShift)then
ModuleSelection.Local:ExtendedLeaderSortOrder()else
ModuleSelection.Local:NormalLeaderSortOrder()end;Sound.FXPlay2DSound("ui\\menu_click")
GUI.ClearSelection()local iq7ol=GUI.GetPlayerID()
for WDTNkTD=1,#LeaderSortOrder do
local Oejsws=GetPlayerEntities(iq7ol,LeaderSortOrder[WDTNkTD])
for CkD73N0=1,#Oejsws do GUI.SelectEntity(Oejsws[CkD73N0])end end;local eMV={}Logic.GetKnights(iq7ol,eMV)for PlwhaRKJ=1,#eMV do
GUI.SelectEntity(eMV[PlwhaRKJ])end
GUI_MultiSelection.CreateMultiSelection(g_SelectionChangedSource.User)end end
function ModuleSelection.Local:NormalLeaderSortOrder()g_MultiSelection={}
g_MultiSelection.EntityList={}g_MultiSelection.Highlighted={}LeaderSortOrder={}
LeaderSortOrder[1]=Entities.U_MilitarySword;LeaderSortOrder[2]=Entities.U_MilitaryBow
LeaderSortOrder[3]=Entities.U_MilitarySword_RedPrince;LeaderSortOrder[4]=Entities.U_MilitaryBow_RedPrince
LeaderSortOrder[5]=Entities.U_MilitaryBandit_Melee_ME;LeaderSortOrder[6]=Entities.U_MilitaryBandit_Melee_NA
LeaderSortOrder[7]=Entities.U_MilitaryBandit_Melee_NE;LeaderSortOrder[8]=Entities.U_MilitaryBandit_Melee_SE
LeaderSortOrder[9]=Entities.U_MilitaryBandit_Ranged_ME;LeaderSortOrder[10]=Entities.U_MilitaryBandit_Ranged_NA
LeaderSortOrder[11]=Entities.U_MilitaryBandit_Ranged_NE;LeaderSortOrder[12]=Entities.U_MilitaryBandit_Ranged_SE
LeaderSortOrder[13]=Entities.U_MilitaryCatapult;LeaderSortOrder[14]=Entities.U_MilitarySiegeTower
LeaderSortOrder[15]=Entities.U_MilitaryBatteringRam;LeaderSortOrder[16]=Entities.U_CatapultCart
LeaderSortOrder[17]=Entities.U_SiegeTowerCart;LeaderSortOrder[18]=Entities.U_BatteringRamCart
if g_GameExtraNo>=1 then
table.insert(LeaderSortOrder,4,Entities.U_MilitarySword_Khana)
table.insert(LeaderSortOrder,6,Entities.U_MilitaryBow_Khana)
table.insert(LeaderSortOrder,7,Entities.U_MilitaryBandit_Melee_AS)
table.insert(LeaderSortOrder,12,Entities.U_MilitaryBandit_Ranged_AS)end;if Entities.U_MilitaryCavalry then
table.insert(LeaderSortOrder,2,Entities.U_MilitaryCavalry)end;if Entities.U_MilitaryPoleArm then
table.insert(LeaderSortOrder,2,Entities.U_MilitaryPoleArm)end;if Entities.U_MilitaryCannon then
table.insert(LeaderSortOrder,17,Entities.U_MilitaryCannon)end end
function ModuleSelection.Local:ExtendedLeaderSortOrder()g_MultiSelection={}
g_MultiSelection.EntityList={}g_MultiSelection.Highlighted={}LeaderSortOrder={}
LeaderSortOrder[1]=Entities.U_MilitarySword;LeaderSortOrder[2]=Entities.U_MilitaryBow
LeaderSortOrder[3]=Entities.U_MilitarySword_RedPrince;LeaderSortOrder[4]=Entities.U_MilitaryBow_RedPrince
LeaderSortOrder[5]=Entities.U_MilitaryBandit_Melee_ME;LeaderSortOrder[6]=Entities.U_MilitaryBandit_Melee_NA
LeaderSortOrder[7]=Entities.U_MilitaryBandit_Melee_NE;LeaderSortOrder[8]=Entities.U_MilitaryBandit_Melee_SE
LeaderSortOrder[9]=Entities.U_MilitaryBandit_Ranged_ME;LeaderSortOrder[10]=Entities.U_MilitaryBandit_Ranged_NA
LeaderSortOrder[11]=Entities.U_MilitaryBandit_Ranged_NE;LeaderSortOrder[12]=Entities.U_MilitaryBandit_Ranged_SE
LeaderSortOrder[13]=Entities.U_MilitaryCatapult;LeaderSortOrder[14]=Entities.U_Trebuchet
LeaderSortOrder[15]=Entities.U_MilitarySiegeTower;LeaderSortOrder[16]=Entities.U_MilitaryBatteringRam
LeaderSortOrder[17]=Entities.U_CatapultCart;LeaderSortOrder[18]=Entities.U_SiegeTowerCart
LeaderSortOrder[19]=Entities.U_BatteringRamCart;LeaderSortOrder[20]=Entities.U_AmmunitionCart
LeaderSortOrder[21]=Entities.U_Thief
if g_GameExtraNo>=1 then
table.insert(LeaderSortOrder,4,Entities.U_MilitarySword_Khana)
table.insert(LeaderSortOrder,6,Entities.U_MilitaryBow_Khana)
table.insert(LeaderSortOrder,7,Entities.U_MilitaryBandit_Melee_AS)
table.insert(LeaderSortOrder,12,Entities.U_MilitaryBandit_Ranged_AS)end;if Entities.U_MilitaryCavalry then
table.insert(LeaderSortOrder,2,Entities.U_MilitaryCavalry)end;if Entities.U_MilitaryPoleArm then
table.insert(LeaderSortOrder,2,Entities.U_MilitaryPoleArm)end;if Entities.U_MilitaryCannon then
table.insert(LeaderSortOrder,17,Entities.U_MilitaryCannon)end end
function ModuleSelection.Local:OverwriteNamesAndDescription()
GUI_Tooltip.SetNameAndDescription_Orig_ModuleSelection=GUI_Tooltip.SetNameAndDescription
GUI_Tooltip.SetNameAndDescription=function(Caz4NM4Z,XVxxx,hD,G5BuU5,AfwsY)local T="/InGame/Root/Normal/AlignBottomRight"
local WZs=XGUIEng.GetCurrentWidgetID()
if
XGUIEng.GetWidgetID(T.."/MapFrame/KnightButton")==WZs then
local ITdz=API.Localize(ModuleSelection.Local.Tooltips.KnightButton)API.SetTooltipNormal(ITdz.Title,ITdz.Text)return end
if
XGUIEng.GetWidgetID(T.."/MapFrame/BattalionButton")==WZs then
local AjfoUo=API.Localize(ModuleSelection.Local.Tooltips.BattalionButton)API.SetTooltipNormal(AjfoUo.Title,AjfoUo.Text)
return end
if


XGUIEng.GetWidgetID(T.."/DialogButtons/SiegeEngineCart/Dismount")==WZs or
XGUIEng.GetWidgetID(T.."/DialogButtons/AmmunitionCart/Dismount")==WZs or
XGUIEng.GetWidgetID(T.."/DialogButtons/Military/Dismount")==WZs then local Er9zidsB=GUI.GetSelectedEntity()
if Er9zidsB~=0 then
if
Logic.IsEntityInCategory(Er9zidsB,EntityCategories.Military)==1 then
local X=Logic.GetGuardianEntityID(Er9zidsB)local dR=Logic.GetGuardedEntityID(Er9zidsB)
if X==0 and dR==0 then
local JFXtQwy=API.Localize(ModuleSelection.Local.Tooltips.ReleaseSoldiers)
API.SetTooltipNormal(JFXtQwy.Title,JFXtQwy.Text,JFXtQwy.Disabled)return end end end end
GUI_Tooltip.SetNameAndDescription_Orig_ModuleSelection(Caz4NM4Z,XVxxx,hD,G5BuU5,AfwsY)end end;Swift:RegisterModule(ModuleSelection)