function Goal_ActivateSeveralObjects(...)
return B_Goal_ActivateSeveralObjects:new(...)end
B_Goal_ActivateSeveralObjects={Name="Goal_ActivateSeveralObjects",Description={en="Goal: Activate an interactive object",de="Ziel: Aktiviere ein interaktives Objekt"},Parameter={{ParameterType.Default,en="Object name 1",de="Skriptname 1"},{ParameterType.Default,en="Object name 2",de="Skriptname 2"},{ParameterType.Default,en="Object name 3",de="Skriptname 3"},{ParameterType.Default,en="Object name 4",de="Skriptname 4"}},ScriptNames={}}
function B_Goal_ActivateSeveralObjects:GetGoalTable()return
{Objective.Object,{unpack(self.ScriptNames)}}end
function B_Goal_ActivateSeveralObjects:AddParameter(QDnlt,LmcA2auZ)if QDnlt==0 then
assert(LmcA2auZ~=nil and LmcA2auZ~="","Goal_ActivateSeveralObjects: At least one IO needed!")end;if LmcA2auZ~=nil and
LmcA2auZ~=""then
table.insert(self.ScriptNames,LmcA2auZ)end end
function B_Goal_ActivateSeveralObjects:GetMsgKey()return"Quest_Object_Activate"end
Swift:RegisterBehavior(B_Goal_ActivateSeveralObjects)
B_Reward_ObjectInit.CustomFunction=function(Q,ZA)local _IQQ=GetID(Q.ScriptName)
if _IQQ==0 then return end;QSB.InitalizedObjekts[_IQQ]=ZA.Identifier;local XpkjA;if Q.RewardType and Q.RewardType~=
"-"then
XpkjA={Goods[Q.RewardType],Q.RewardAmount}end;local pVRj
if Q.FirstCostType and
Q.FirstCostType~="-"then pVRj=XpkjA or{}
table.insert(pVRj,Goods[Q.FirstCostType])
table.insert(pVRj,Goods[Q.FirstCostAmount])end
if Q.SecondCostType and Q.SecondCostType~="-"then pVRj=XpkjA or{}
table.insert(pVRj,Goods[Q.SecondCostType])
table.insert(pVRj,Goods[Q.SecondCostAmount])end
API.SetupObject{Name=Q.ScriptName,Distance=Q.Distance,Waittime=Q.Waittime,Reward=XpkjA,Costs=pVRj}
API.InteractiveObjectActivate(Q.ScriptName,Q.UsingState)end