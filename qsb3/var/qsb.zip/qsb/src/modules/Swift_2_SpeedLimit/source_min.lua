
ModuleSpeedLimitation={Properties={Name="ModuleSpeedLimitation"},Global={},Local={SpeedLimit=1},Shared={}}function ModuleSpeedLimitation.Global:OnGameStart()end;function ModuleSpeedLimitation.Local:OnGameStart()
self:InitForbidSpeedUp()end
function ModuleSpeedLimitation.Local:SetSpeedLimit(QDnlt)if
Framework.IsNetworkGame()then
info("ModuleSpeedLimitation: Detect network game. Aborting!")return end;QDnlt=
(QDnlt<1 and 1)or math.floor(QDnlt)
info(
"ModuleSpeedLimitation: Setting speed limit to "..QDnlt)self.SpeedLimit=QDnlt end
function ModuleSpeedLimitation.Local:ActivateSpeedLimit(LmcA2auZ)if
Framework.IsNetworkGame()then
info("ModuleSpeedLimitation: Detect network game. Aborting!")return end
self.UseSpeedLimit=LmcA2auZ==true
if LmcA2auZ and
Game.GameTimeGetFactor(GUI.GetPlayerID())>self.SpeedLimit then
info("ModuleSpeedLimitation: Speed is capped at "..self.SpeedLimit)
Game.GameTimeSetFactor(GUI.GetPlayerID(),self.SpeedLimit)end end
function ModuleSpeedLimitation.Local:InitForbidSpeedUp()
GameCallback_GameSpeedChanged_Orig_Preferences_ForbidSpeedUp=GameCallback_GameSpeedChanged
GameCallback_GameSpeedChanged=function(Q)
GameCallback_GameSpeedChanged_Orig_Preferences_ForbidSpeedUp(Q)
if ModuleSpeedLimitation.Local.UseSpeedLimit==true then
info("ModuleSpeedLimitation: Checking speed limit.")
if Q>ModuleSpeedLimitation.Local.SpeedLimit then
info(
"ModuleSpeedLimitation: Speed is capped at "..tostring(Q)..".")
Game.GameTimeSetFactor(GUI.GetPlayerID(),ModuleSpeedLimitation.Local.SpeedLimit)end end end end;Swift:RegisterModule(ModuleSpeedLimitation)