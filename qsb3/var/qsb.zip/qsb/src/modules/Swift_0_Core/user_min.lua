QSB.RefillAmounts={}function Swift:InitalizeCallbackGlobal()
self:OverrideSaveLoadedCallback()self:OverwriteGeologistRefill()
self:OverrideSoldierPayment()end;function Swift:InitalizeCallbackLocal()
self:SetEscapeKeyTrigger()end
function Swift:TriggerEntityKilledCallbacks(QDnlt,LmcA2auZ)local Q=GetID(QDnlt)local ZA=GetID(
LmcA2auZ or 0)if ZA==0 or Q==0 or
Logic.GetEntityHealth(Q)>0 then return end
local _IQQ,XpkjA,pVRj=Logic.EntityGetPos(Q)local fuZ3z86=Logic.EntityGetPlayer(Q)
local er=Logic.GetEntityType(Q)local DFb100j=Logic.EntityGetPlayer(ZA)
local XL_=Logic.GetEntityType(ZA)
GameCallback_EntityKilled(Q,fuZ3z86,ZA,DFb100j,er,XL_)
Logic.ExecuteInLuaLocalState(string.format("GameCallback_Feedback_EntityKilled(%d, %d, %d, %d,%d, %d, %f, %f)",Q,fuZ3z86,ZA,DFb100j,er,XL_,_IQQ,XpkjA))end
function Swift:OverrideSaveLoadedCallback()
if Mission_OnSaveGameLoaded then
Mission_OnSaveGameLoaded_Orig_Swift=Mission_OnSaveGameLoaded
Mission_OnSaveGameLoaded=function()Mission_OnSaveGameLoaded_Orig_Swift()
Swift:RestoreAfterLoad()
Logic.ExecuteInLuaLocalState("Swift:RestoreAfterLoad()")
Swift:DispatchScriptEvent(QSB.ScriptEvents.SaveGameLoaded)
Logic.ExecuteInLuaLocalState("Swift:DispatchScriptEvent(QSB.ScriptEvents.SaveGameLoaded)")end end end
function Swift:RestoreAfterLoad()debug("Loading save game",true)
self:OverrideString()self:OverrideTable()if self:IsGlobalEnvironment()then
self:GlobalRestoreDebugAfterLoad()self:GlobalRestoreBugfixesAfterLoad()
self:DisableLogicFestival()end
if
self:IsLocalEnvironment()then self:LocalRestoreDebugAfterLoad()
self:LocalRestoreBugfixesAfterLoad()self:SetEscapeKeyTrigger()
self:CreateRandomSeed()self:AlterQuickSaveHotkey()end end;function Swift:SetEscapeKeyTrigger()
Input.KeyBindDown(Keys.Escape,"Swift:ExecuteEscapeCallback()",30,false)end
function Swift:ExecuteEscapeCallback()
API.BroadcastScriptEventToGlobal(QSB.ScriptEvents.EscapePressed,GUI.GetPlayerID())
Swift:DispatchScriptEvent(QSB.ScriptEvents.EscapePressed,GUI.GetPlayerID())end
function Swift:OverwriteGeologistRefill()
if Framework.GetGameExtraNo()>=1 then
GameCallback_OnGeologistRefill_Orig_QSB_SwiftCore=GameCallback_OnGeologistRefill
GameCallback_OnGeologistRefill=function(WYdR,QKKks_zt,Are7xU)
GameCallback_OnGeologistRefill_Orig_QSB_SwiftCore(WYdR,QKKks_zt,Are7xU)
if QSB.RefillAmounts[QKKks_zt]then local yxjl=QSB.RefillAmounts[QKKks_zt]
local ZG=
yxjl+math.random(1,math.floor((yxjl*0.2)+0.5))Logic.SetResourceDoodadGoodAmount(QKKks_zt,ZG)
if ZG>0 then
if
Logic.GetResourceDoodadGoodType(QKKks_zt)==Goods.G_Iron then
Logic.SetModel(QKKks_zt,Models.Doodads_D_SE_ResourceIron)else
Logic.SetModel(QKKks_zt,Models.R_ResorceStone_Scaffold)end end end end end end
function Swift:OverrideSoldierPayment()
GameCallback_SetSoldierPaymentLevel_Orig=GameCallback_SetSoldierPaymentLevel
GameCallback_SetSoldierPaymentLevel=function(Vu0cCAf,q)if q<=2 then
return GameCallback_SetSoldierPaymentLevel_Orig(Vu0cCAf,q)end
Swift:ProcessScriptCommand(Vu0cCAf,q)end end