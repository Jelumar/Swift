function Goal_NPC(...)return B_Goal_NPC:new(...)end
B_Goal_NPC={Name="Goal_NPC",Description={en="Goal: The hero has to talk to a non-player character.",de="Ziel: Der Held muss einen Nichtspielercharakter ansprechen."},Parameter={{ParameterType.ScriptName,en="NPC",de="NPC"},{ParameterType.ScriptName,en="Hero",de="Held"}}}
function B_Goal_NPC:GetGoalTable()return
{Objective.Distance,-65565,self.Hero,self.NPC,self}end
function B_Goal_NPC:AddParameter(QDnlt,LmcA2auZ)
if(QDnlt==0)then self.NPC=LmcA2auZ elseif(QDnlt==1)then
self.Hero=LmcA2auZ;if self.Hero=="-"then self.Hero=nil end end end;function B_Goal_NPC:GetIcon()return{14,10}end
Swift:RegisterBehavior(B_Goal_NPC)