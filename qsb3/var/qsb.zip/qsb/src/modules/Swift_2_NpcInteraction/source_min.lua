
ModuleNpcInteraction={Properties={Name="ModuleNpcInteraction"},Global={Interactions={},NPC={},UseMarker=true},Local={},Shared={Text={StartConversation={de="Gespräch beginnen",en="Start conversation",fr="Parlez à caractère"}}}}QSB.Npc={LastNpcEntityID=0,LastHeroEntityID=0}
function ModuleNpcInteraction.Global:OnGameStart()
QSB.ScriptEvents.NpcInteraction=API.RegisterScriptEvent("Event_NpcInteraction")self:OverrideQuestFunctions()
API.StartHiResJob(function()if
Logic.GetTime()>1 then
ModuleNpcInteraction.Global:InteractionTriggerController()end end)
API.StartJob(function()
ModuleNpcInteraction.Global:InteractableMarkerController()end)end
function ModuleNpcInteraction.Global:OnEvent(QDnlt,LmcA2auZ,...)
if
QDnlt==QSB.ScriptEvents.NpcInteraction then QSB.Npc.LastNpcEntityID=arg[1]QSB.Npc.LastHeroEntityID=arg[2]self.Interactions[arg[1]]=
self.Interactions[arg[1]]or{}
if
self.Interactions[arg[1]][arg[2]]then if Logic.GetCurrentTurn()<=
self.Interactions[arg[1]][arg[2]]+5 then return end end
self.Interactions[arg[1]][arg[2]]=Logic.GetCurrentTurn()self:PerformNpcInteraction(arg[3])end end
function ModuleNpcInteraction.Global:CreateNpc(Q)
self.NPC[Q.Name]={Name=Q.Name,Active=true,Type=Q.Type or 1,Player=
Q.Player or{1,2,3,4,5,6,7,8},WrongPlayerAction=Q.WrongPlayerAction,Hero=Q.Hero,WrongHeroAction=Q.WrongHeroAction,Distance=Q.Distance or 350,Condition=Q.Condition,Callback=Q.Callback,UseMarker=
self.UseMarker==true,MarkerID=0}self:UpdateNpc(Q)return self.NPC[Q.Name]end
function ModuleNpcInteraction.Global:DestroyNpc(ZA)ZA.Active=false
self:UpdateNpc(ZA)self:DestroyMarker(ZA.Name)self.NPC[ZA.Name]=nil end
function ModuleNpcInteraction.Global:GetNpc(_IQQ)return self.NPC[_IQQ]end
function ModuleNpcInteraction.Global:UpdateNpc(XpkjA)if
not IsExisting(XpkjA.Name)then return end
if not self.NPC[XpkjA.Name]then
local pVRj=GetID(XpkjA.Name)Logic.SetOnScreenInformation(pVRj,0)return end
for fuZ3z86,er in pairs(XpkjA)do self.NPC[XpkjA.Name][fuZ3z86]=er end;self:CreateMarker(XpkjA.Name)
if
self.NPC[XpkjA.Name].Active then local DFb100j=GetID(XpkjA.Name)
Logic.SetOnScreenInformation(DFb100j,self.NPC[XpkjA.Name].Type)else local XL_=GetID(XpkjA.Name)
Logic.SetOnScreenInformation(XL_,0)end end
function ModuleNpcInteraction.Global:PerformNpcInteraction(WYdR)
local QKKks_zt=Logic.GetEntityName(QSB.Npc.LastNpcEntityID)
if self.NPC[QKKks_zt]then local Are7xU=self.NPC[QKKks_zt]
self:RotateActorsToEachother(WYdR)self:AdjustHeroTalkingDistance(Are7xU.Distance)
if not
self:InteractionIsAppropriatePlayer(QKKks_zt,WYdR,QSB.Npc.LastHeroEntityID)then return end;Are7xU.TalkedTo=QSB.Npc.LastHeroEntityID;if not
self:InteractionIsAppropriateHero(QKKks_zt)then return end
if

Are7xU.Condition==nil or Are7xU:Condition(WYdR,QSB.Npc.LastHeroEntityID)then Are7xU.Active=false;if Are7xU.Callback then
Are7xU:Callback(WYdR,QSB.Npc.LastHeroEntityID)end else Are7xU.TalkedTo=0 end;self:UpdateNpc(Are7xU)end end
function ModuleNpcInteraction.Global:InteractionIsAppropriatePlayer(yxjl,ZG,Vu0cCAf)local q=true
if
self.NPC[yxjl]then local kP7O5=self.NPC[yxjl]
if kP7O5.Player~=nil then if
type(kP7O5.Player)=="table"then q=table.contains(kP7O5.Player,ZG)else
q=kP7O5.Player==ZG end
if not q then local lqT=
(kP7O5.WrongHeroTick or 0)+1;local mP3mlD=Logic.GetTime()
if
kP7O5.WrongPlayerAction and lqT<mP3mlD then
self.NPC[yxjl].LastWongPlayerTick=mP3mlD;kP7O5:WrongPlayerAction(ZG)end end end end;return q end
function ModuleNpcInteraction.Global:InteractionIsAppropriateHero(PrPyxMK)local tczrIB=true
if
self.NPC[PrPyxMK]then local a=self.NPC[PrPyxMK]
if a.Hero~=nil then if type(a.Hero)=="table"then
tczrIB=table.contains(a.Hero,Logic.GetEntityName(QSB.Npc.LastHeroEntityID))end;tczrIB=a.Hero==
Logic.GetEntityName(QSB.Npc.LastHeroEntityID)
if not tczrIB then local wqU76o=
(a.WrongHeroTick or 0)+1;local LB1Z=Logic.GetTime()
if a.WrongHeroAction and wqU76o<
LB1Z then
self.NPC[PrPyxMK].WrongHeroTick=LB1Z;a:WrongHeroAction(QSB.Npc.LastHeroEntityID)end end end end;return tczrIB end
function ModuleNpcInteraction.Global:RotateActorsToEachother(N9L)local hDc_M={}
Logic.GetKnights(N9L,hDc_M)
for qW0lRiD1,iD1IUx in pairs(hDc_M)do local JLCOx_ak=API.GetEntityMovementTarget(iD1IUx)
local hPQ,R1FIoQI,NsoTwDs=Logic.EntityGetPos(QSB.Npc.LastNpcEntityID)
if
math.floor(JLCOx_ak.X)==math.floor(hPQ)and
math.floor(JLCOx_ak.Y)==math.floor(R1FIoQI)then hPQ,R1FIoQI,NsoTwDs=Logic.EntityGetPos(iD1IUx)
Logic.MoveEntity(iD1IUx,hPQ,R1FIoQI)API.LookAt(iD1IUx,QSB.Npc.LastNpcEntityID)end end
API.LookAt(QSB.Npc.LastHeroEntityID,QSB.Npc.LastNpcEntityID)
API.LookAt(QSB.Npc.LastNpcEntityID,QSB.Npc.LastHeroEntityID)end
function ModuleNpcInteraction.Global:AdjustHeroTalkingDistance(HGli)local iy=HGli*
API.GetEntityScale(QSB.Npc.LastNpcEntityID)
if
API.GetDistance(QSB.Npc.LastHeroEntityID,QSB.Npc.LastNpcEntityID)<=iy*0.7 then
local m6SCS0=Logic.GetEntityOrientation(QSB.Npc.LastNpcEntityID)
local NUhYw6R4,Hv,Ch=Logic.EntityGetPos(QSB.Npc.LastHeroEntityID)local urkh=NUhYw6R4+
((iy*0.5)*math.cos(math.rad(m6SCS0)))
local zhzpBSx=Hv+ ((iy*0.5)*
math.sin(math.rad(m6SCS0)))
local rHSjalVy=Logic.CreateEntityOnUnblockedLand(Entities.XD_ScriptEntity,urkh,zhzpBSx,0,0)local TjhsnP,t5jzEd9,JZAU2=Logic.EntityGetPos(rHSjalVy)
Logic.MoveSettler(QSB.Npc.LastHeroEntityID,TjhsnP,t5jzEd9)
API.StartHiResJob(function(zPXTTg,seMLr,qX)if Logic.GetTime()>qX+0.5 and
Logic.IsEntityMoving(zPXTTg)==false then API.Confront(zPXTTg,seMLr)
return true end end,QSB.Npc.LastHeroEntityID,QSB.Npc.LastNpcEntityID,Logic.GetTime())end end
function ModuleNpcInteraction.Global:OverrideQuestFunctions()
GameCallback_OnNPCInteraction_Orig_QSB_ModuleNpcInteraction=GameCallback_OnNPCInteraction
GameCallback_OnNPCInteraction=function(h_8,xL7OTb,w8T3f)
GameCallback_OnNPCInteraction_Orig_QSB_ModuleNpcInteraction(h_8,xL7OTb,w8T3f)local K=w8T3f or
ModuleNpcInteraction.Global:GetClosestKnight(h_8,xL7OTb)
API.SendScriptEvent(QSB.ScriptEvents.NpcInteraction,h_8,K,xL7OTb)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.NpcInteraction, %d, %d, %d)]],h_8,K,xL7OTb))end
QuestTemplate.RemoveQuestMarkers_Orig_ModuleNpcInteraction=QuestTemplate.RemoveQuestMarkers
QuestTemplate.RemoveQuestMarkers=function(qL)
for vfIyB=1,qL.Objectives[0]do
if qL.Objectives[vfIyB].Type==
Objective.Distance then
if qL.Objectives[vfIyB].Data[1]~=
-65565 then
QuestTemplate.RemoveQuestMarkers_Orig_ModuleNpcInteraction(qL)else if qL.Objectives[vfIyB].Data[4]then
API.NpcDispose(qL.Objectives[vfIyB].Data[4].NpcInstance)
qL.Objectives[vfIyB].Data[4].NpcInstance=nil end end else
QuestTemplate.RemoveQuestMarkers_Orig_ModuleNpcInteraction(qL)end end end
QuestTemplate.ShowQuestMarkers_Orig_ModuleNpcInteraction=QuestTemplate.ShowQuestMarkers
QuestTemplate.ShowQuestMarkers=function(quNsijN)
for QUh2tc=1,quNsijN.Objectives[0]do
if
quNsijN.Objectives[QUh2tc].Type==Objective.Distance then
if
quNsijN.Objectives[QUh2tc].Data[1]~=-65565 then
QuestTemplate.ShowQuestMarkers_Orig_ModuleNpcInteraction(quNsijN)else
if not
quNsijN.Objectives[QUh2tc].Data[4].NpcInstance then
quNsijN.Objectives[QUh2tc].Data[4].NpcInstance=API.NpcCompose{Name=quNsijN.Objectives[QUh2tc].Data[3],Hero=quNsijN.Objectives[QUh2tc].Data[2],Player=quNsijN.ReceivingPlayer}end end end end end
QuestTemplate.IsObjectiveCompleted_Orig_ModuleNpcInteraction=QuestTemplate.IsObjectiveCompleted
QuestTemplate.IsObjectiveCompleted=function(qboV,nSBOx7)local u=nSBOx7.Type;local K=nSBOx7.Data;if
nSBOx7.Completed~=nil then return nSBOx7.Completed end
if
u~=Objective.Distance then
return qboV:IsObjectiveCompleted_Orig_ModuleNpcInteraction(nSBOx7)else
if K[1]==-65565 then
if not IsExisting(K[3])then
error(K[3].." is dead! :(")nSBOx7.Completed=false else if
API.NpcTalkedTo(K[4].NpcInstance,K[2],qboV.ReceivingPlayer)then nSBOx7.Completed=true end end else
return qboV:IsObjectiveCompleted_Orig_ModuleNpcInteraction(nSBOx7)end end end end
function ModuleNpcInteraction.Global:GetClosestKnight(i1,zz1QI)local kFTAh={}
Logic.GetKnights(zz1QI,kFTAh)return API.GetClosestToTarget(i1,kFTAh)end
function ModuleNpcInteraction.Global:ToggleMarkerUsage(LBf)self.UseMarker=LBf==true;for dijn4Ph,CO1 in
pairs(self.NPC)do self.NPC[dijn4Ph].UseMarker=LBf==true
self:HideMarker(dijn4Ph)end end
function ModuleNpcInteraction.Global:CreateMarker(RlZo)
if self.NPC[RlZo]then
local SUn,Ib4,fjV1G2=Logic.EntityGetPos(GetID(RlZo))
local Do=Logic.CreateEntity(Entities.XD_ScriptEntity,SUn,Ib4,0,0)DestroyEntity(self.NPC[RlZo].MarkerID)
self.NPC[RlZo].MarkerID=Do;self:HideMarker(RlZo)end end
function ModuleNpcInteraction.Global:DestroyMarker(_)if self.NPC[_]then
DestroyEntity(self.NPC[_].MarkerID)self.NPC[_].MarkerID=0 end end
function ModuleNpcInteraction.Global:HideMarker(TqYJ4)
if self.NPC[TqYJ4]then
if
IsExisting(self.NPC[TqYJ4].MarkerID)then
Logic.SetModel(self.NPC[TqYJ4].MarkerID,Models.Effects_E_NullFX)
Logic.SetVisible(self.NPC[TqYJ4].MarkerID,false)end end end
function ModuleNpcInteraction.Global:ShowMarker(DI)
if self.NPC[DI]then
if

self.NPC[DI].UseMarker==true and IsExisting(self.NPC[DI].MarkerID)then local b=API.GetEntityScale(DI)
API.SetEntityScale(self.NPC[DI].MarkerID,b)
Logic.SetModel(self.NPC[DI].MarkerID,Models.Effects_E_Wealth)
Logic.SetVisible(self.NPC[DI].MarkerID,true)end end end
function ModuleNpcInteraction.Global:InteractionTriggerController()
for E=1,8,1 do local KMw7_i1s={}
Logic.GetKnights(E,KMw7_i1s)
for CQi=1,#KMw7_i1s,1 do
if
Logic.GetCurrentTaskList(KMw7_i1s[CQi])=="TL_NPC_INTERACTION"then local nHlJ,lw4Q7kbl=Logic.EntityGetPos(KMw7_i1s[CQi])
for IN,QYf1 in
pairs(self.NPC)do
if QYf1.Distance>=350 then
local RfsnisO=API.GetEntityMovementTarget(KMw7_i1s[CQi])local lvW2ga,T7RKP=Logic.EntityGetPos(GetID(IN))
if
math.floor(RfsnisO.X)==math.floor(lvW2ga)and math.floor(RfsnisO.Y)==
math.floor(T7RKP)then if
IsExisting(IN)and IsNear(KMw7_i1s[CQi],IN,QYf1.Distance)then
GameCallback_OnNPCInteraction(GetID(IN),E,KMw7_i1s[CQi])return end end end end end end end end
function ModuleNpcInteraction.Global:InteractableMarkerController()
for _L6Bs,SH in pairs(self.NPC)do
if SH.Active then if
SH.UseMarker and IsExisting(SH.MarkerID)and
API.IsEntityVisible(SH.MarkerID)then self:HideMarker(_L6Bs)else
self:ShowMarker(_L6Bs)end
local wU4wYbA9,fFeQcIM,JEHSHPh3=Logic.EntityGetPos(SH.MarkerID)local bb,o5e6fP,iq7ol=Logic.EntityGetPos(GetID(_L6Bs))if math.abs(
wU4wYbA9-bb)>20 or
math.abs(fFeQcIM-o5e6fP)>20 then
Logic.DEBUG_SetPosition(SH.MarkerID,bb,o5e6fP)end end end end
function ModuleNpcInteraction.Local:OnGameStart()
QSB.ScriptEvents.NpcInteraction=API.RegisterScriptEvent("Event_NpcInteraction")self:OverrideQuestFunctions()end
function ModuleNpcInteraction.Local:OnEvent(eMV,WDTNkTD,...)
if
eMV==QSB.ScriptEvents.NpcInteraction then QSB.Npc.LastNpcEntityID=arg[1]QSB.Npc.LastHeroEntityID=arg[2]end end
function ModuleNpcInteraction.Local:OverrideQuestFunctions()
GUI_Interaction.DisplayQuestObjective_Orig_ModuleNpcInteraction=GUI_Interaction.DisplayQuestObjective
GUI_Interaction.DisplayQuestObjective=function(Oejsws,CkD73N0)local PlwhaRKJ=tonumber(Oejsws)
if PlwhaRKJ then Oejsws=PlwhaRKJ end
local Caz4NM4Z,XVxxx=GUI_Interaction.GetPotentialSubQuestAndType(Oejsws)local hD="/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives"
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives",0)local G5BuU5;local AfwsY;g_CurrentDisplayedQuestID=Oejsws
if XVxxx==Objective.Distance then G5BuU5=
hD.."/List"
AfwsY=Wrapped_GetStringTableText(Oejsws,"UI_Texts/QuestInteraction")local T={}
if
Caz4NM4Z.Objectives[1].Data[1]==-65565 then G5BuU5=hD.."/Distance"
AfwsY=Wrapped_GetStringTableText(Oejsws,"UI_Texts/QuestMoveHere")SetIcon(G5BuU5 .."/QuestTypeIcon",{7,10})
local WZs=GetID(Caz4NM4Z.Objectives[1].Data[2])local ITdz=Logic.GetEntityType(WZs)
local AjfoUo=g_TexturePositions.Entities[ITdz]if not AjfoUo then AjfoUo={7,9}end
SetIcon(G5BuU5 .."/IconMover",AjfoUo)
local Er9zidsB=GetID(Caz4NM4Z.Objectives[1].Data[3])local X=Logic.GetEntityType(Er9zidsB)
local dR=g_TexturePositions.Entities[X]if not dR then dR={14,10}end;local JFXtQwy=G5BuU5 .."/IconTarget"local uMV17h0=G5BuU5 ..
"/TargetPlayerColor"SetIcon(JFXtQwy,dR)
XGUIEng.SetMaterialColor(uMV17h0,0,255,255,255,0)SetIcon(G5BuU5 .."/QuestTypeIcon",{16,12})
local E2NZK=ModuleNpcInteraction.Shared.Text.StartConversation;AfwsY=API.Localize(E2NZK)
XGUIEng.SetText(G5BuU5 .."/Caption","{center}"..AfwsY)XGUIEng.ShowWidget(G5BuU5,1)else
GUI_Interaction.DisplayQuestObjective_Orig_ModuleNpcInteraction(Oejsws,CkD73N0)end else
GUI_Interaction.DisplayQuestObjective_Orig_ModuleNpcInteraction(Oejsws,CkD73N0)end end
GUI_Interaction.GetEntitiesOrTerritoryListForQuest_Orig_ModuleNpcInteraction=GUI_Interaction.GetEntitiesOrTerritoryListForQuest
GUI_Interaction.GetEntitiesOrTerritoryListForQuest=function(WNWWe,zMzjn3lk)local Trkkpmd={}local L=true
if
zMzjn3lk==Objective.Distance then
if WNWWe.Objectives[1].Data[1]==-65565 then
local GGv=GetID(WNWWe.Objectives[1].Data[3])table.insert(Trkkpmd,GGv)else return
GUI_Interaction.GetEntitiesOrTerritoryListForQuest_Orig_ModuleNpcInteraction(WNWWe,zMzjn3lk)end else return
GUI_Interaction.GetEntitiesOrTerritoryListForQuest_Orig_ModuleNpcInteraction(WNWWe,zMzjn3lk)end;return Trkkpmd,L end end;Swift:RegisterModule(ModuleNpcInteraction)