
ModuleDisplayCore={Properties={Name="ModuleDisplayCore"},Global={CinematicEventID=0,CinematicEventStatus={},CinematicEventQueue={}},Local={CinematicEventStatus={},ChatOptionsWasShown=false,MessageLogWasShown=false,PauseScreenShown=false,NormalModeHidden=false,BorderScrollDeactivated=false},Shared={}}QSB.CinematicEvents={}QSB.CinematicEventTypes={}
function ModuleDisplayCore.Global:OnGameStart()
QSB.ScriptEvents.CinematicActivated=API.RegisterScriptEvent("Event_CinematicEventActivated")
QSB.ScriptEvents.CinematicConcluded=API.RegisterScriptEvent("Event_CinematicEventConcluded")
QSB.ScriptEvents.BorderScrollLocked=API.RegisterScriptEvent("Event_BorderScrollLocked")
QSB.ScriptEvents.BorderScrollReset=API.RegisterScriptEvent("Event_BorderScrollReset")
QSB.ScriptEvents.GameInterfaceShown=API.RegisterScriptEvent("Event_GameInterfaceShown")
QSB.ScriptEvents.GameInterfaceHidden=API.RegisterScriptEvent("Event_GameInterfaceHidden")
QSB.ScriptEvents.BlackScreenShown=API.RegisterScriptEvent("Event_BlackScreenShown")
QSB.ScriptEvents.BlackScreenHidden=API.RegisterScriptEvent("Event_BlackScreenHidden")for QDnlt=1,8 do self.CinematicEventStatus[QDnlt]={}
self.CinematicEventQueue[QDnlt]={}end end
function ModuleDisplayCore.Global:OnEvent(LmcA2auZ,Q,...)
if
LmcA2auZ==QSB.ScriptEvents.CinematicActivated then
self.CinematicEventStatus[arg[2]][arg[1]]=1 elseif LmcA2auZ==QSB.ScriptEvents.CinematicConcluded then if
self.CinematicEventStatus[arg[2]][arg[1]]then
self.CinematicEventStatus[arg[2]][arg[1]]=2 end end end;function ModuleDisplayCore.Global:PushCinematicEventToQueue(ZA,_IQQ,XpkjA,pVRj)
table.insert(self.CinematicEventQueue[ZA],{_IQQ,XpkjA,pVRj})end
function ModuleDisplayCore.Global:LookUpCinematicInFromQueue(fuZ3z86)if
#self.CinematicEventQueue[fuZ3z86]>0 then return
self.CinematicEventQueue[fuZ3z86][1]end end
function ModuleDisplayCore.Global:PopCinematicEventFromQueue(er)if
#self.CinematicEventQueue[er]>0 then return
table.remove(self.CinematicEventQueue[er],1)end end
function ModuleDisplayCore.Global:GetNewCinematicEventID()
self.CinematicEventID=self.CinematicEventID+1;return self.CinematicEventID end
function ModuleDisplayCore.Global:GetCinematicEventStatus(DFb100j)
for XL_=1,8 do if
self.CinematicEventStatus[XL_][DFb100j]then
return self.CinematicEventStatus[XL_][DFb100j]end end;return 0 end
function ModuleDisplayCore.Global:ActivateCinematicEvent(WYdR)
local QKKks_zt=self:GetNewCinematicEventID()
Logic.ExecuteInLuaLocalState(string.format("API.SendScriptEvent(QSB.ScriptEvents.CinematicActivated, %d, %d);",QKKks_zt,WYdR))
API.SendScriptEvent(QSB.ScriptEvents.CinematicActivated,QKKks_zt,WYdR)return QKKks_zt end
function ModuleDisplayCore.Global:ConcludeCinematicEvent(Are7xU,yxjl)
Logic.ExecuteInLuaLocalState(string.format("API.SendScriptEvent(QSB.ScriptEvents.CinematicConcluded, %d, %d);",Are7xU,yxjl))
API.SendScriptEvent(QSB.ScriptEvents.CinematicConcluded,Are7xU,yxjl)end
function ModuleDisplayCore.Local:OnGameStart()
QSB.ScriptEvents.CinematicActivated=API.RegisterScriptEvent("Event_CinematicEventActivated")
QSB.ScriptEvents.CinematicConcluded=API.RegisterScriptEvent("Event_CinematicEventConcluded")
QSB.ScriptEvents.BorderScrollLocked=API.RegisterScriptEvent("Event_BorderScrollLocked")
QSB.ScriptEvents.BorderScrollReset=API.RegisterScriptEvent("Event_BorderScrollReset")
QSB.ScriptEvents.GameInterfaceShown=API.RegisterScriptEvent("Event_GameInterfaceShown")
QSB.ScriptEvents.GameInterfaceHidden=API.RegisterScriptEvent("Event_GameInterfaceHidden")
QSB.ScriptEvents.BlackScreenShown=API.RegisterScriptEvent("Event_BlackScreenShown")
QSB.ScriptEvents.BlackScreenHidden=API.RegisterScriptEvent("Event_BlackScreenHidden")for ZG=1,8 do self.CinematicEventStatus[ZG]={}end
self:OverrideInterfaceUpdateForCinematicMode()
self:OverrideInterfaceThroneroomForCinematicMode()end
function ModuleDisplayCore.Local:OnEvent(Vu0cCAf,q,...)
if
Vu0cCAf==QSB.ScriptEvents.CinematicActivated then
self.CinematicEventStatus[arg[2]][arg[1]]=1 elseif Vu0cCAf==QSB.ScriptEvents.CinematicConcluded then
for kP7O5=1,8 do if
self.CinematicEventStatus[kP7O5][arg[1]]then
self.CinematicEventStatus[kP7O5][arg[1]]=2 end end end end
function ModuleDisplayCore.Local:GetCinematicEventStatus(lqT)
for mP3mlD=1,8 do if
self.CinematicEventStatus[mP3mlD][lqT]then
return self.CinematicEventStatus[mP3mlD][lqT]end end;return 0 end
function ModuleDisplayCore.Local:OverrideInterfaceUpdateForCinematicMode()
API.AddBlockQuicksaveCondition(function()
if



ModuleDisplayCore.Local.NormalModeHidden or ModuleDisplayCore.Local.BorderScrollDeactivated or ModuleDisplayCore.Local.PauseScreenShown or API.IsCinematicEventActive(GUI.GetPlayerID())then return true end end)
GameCallback_GameSpeedChanged_Orig_ModuleDisplayCoreInterface=GameCallback_GameSpeedChanged
GameCallback_GameSpeedChanged=function(PrPyxMK)if
not ModuleDisplayCore.Local.PauseScreenShown then
GameCallback_GameSpeedChanged_Orig_ModuleDisplayCoreInterface(PrPyxMK)end end;MissionTimerUpdate_Orig_ModuleDisplayCoreInterface=MissionTimerUpdate
MissionTimerUpdate=function()
MissionTimerUpdate_Orig_ModuleDisplayCoreInterface()
if ModuleDisplayCore.Local.NormalModeHidden or
ModuleDisplayCore.Local.PauseScreenShown then
XGUIEng.ShowWidget("/InGame/Root/Normal/MissionTimer",0)end end
MissionGoodOrEntityCounterUpdate_Orig_ModuleDisplayCoreInterface=MissionGoodOrEntityCounterUpdate
MissionGoodOrEntityCounterUpdate=function()
MissionGoodOrEntityCounterUpdate_Orig_ModuleDisplayCoreInterface()
if ModuleDisplayCore.Local.NormalModeHidden or
ModuleDisplayCore.Local.PauseScreenShown then
XGUIEng.ShowWidget("/InGame/Root/Normal/MissionGoodOrEntityCounter",0)end end
MerchantButtonsUpdater_Orig_ModuleDisplayCoreInterface=GUI_Merchant.ButtonsUpdater
GUI_Merchant.ButtonsUpdater=function()
MerchantButtonsUpdater_Orig_ModuleDisplayCoreInterface()
if ModuleDisplayCore.Local.NormalModeHidden or
ModuleDisplayCore.Local.PauseScreenShown then
XGUIEng.ShowWidget("/InGame/Root/Normal/Selected_Merchant",0)end end
if GUI_Tradepost then
TradepostButtonsUpdater_Orig_ModuleDisplayCoreInterface=GUI_Tradepost.ButtonsUpdater
GUI_Tradepost.ButtonsUpdater=function()
TradepostButtonsUpdater_Orig_ModuleDisplayCoreInterface()
if ModuleDisplayCore.Local.NormalModeHidden or
ModuleDisplayCore.Local.PauseScreenShown then
XGUIEng.ShowWidget("/InGame/Root/Normal/Selected_Tradepost",0)end end end end
function ModuleDisplayCore.Local:OverrideInterfaceThroneroomForCinematicMode()
GameCallback_Camera_StartButtonPressed=function(tczrIB)end
OnStartButtonPressed=function()
GameCallback_Camera_StartButtonPressed(GUI.GetPlayerID())end;GameCallback_Camera_BackButtonPressed=function(a)end
OnBackButtonPressed=function()
GameCallback_Camera_BackButtonPressed(GUI.GetPlayerID())end;GameCallback_Camera_SkipButtonPressed=function(wqU76o)end
OnSkipButtonPressed=function()
GameCallback_Camera_SkipButtonPressed(GUI.GetPlayerID())end;GameCallback_Camera_ThroneRoomLeftClick=function(LB1Z)end
ThroneRoomLeftClick=function()
GameCallback_Camera_ThroneRoomLeftClick(GUI.GetPlayerID())end;GameCallback_Camera_ThroneroomCameraControl=function(N9L)end
ThroneRoomCameraControl=function()
GameCallback_Camera_ThroneroomCameraControl(GUI.GetPlayerID())end end
function ModuleDisplayCore.Local:InterfaceActivateColoredBackground(hDc_M,qW0lRiD1,iD1IUx,JLCOx_ak)
if self.PauseScreenShown then return end;self.PauseScreenShown=true
XGUIEng.PushPage("/InGame/Root/Normal/PauseScreen",false)
XGUIEng.ShowWidget("/InGame/Root/Normal/PauseScreen",1)
XGUIEng.SetMaterialColor("/InGame/Root/Normal/PauseScreen",0,hDc_M,qW0lRiD1,iD1IUx,JLCOx_ak)
API.SendScriptEventToGlobal(QSB.ScriptEvents.BlackScreenShown,GUI.GetPlayerID())
API.SendScriptEvent(QSB.ScriptEvents.BlackScreenShown,GUI.GetPlayerID())end
function ModuleDisplayCore.Local:InterfaceDeactivateColoredBackground()if not self.PauseScreenShown then
return end;self.PauseScreenShown=false
XGUIEng.ShowWidget("/InGame/Root/Normal/PauseScreen",0)
XGUIEng.SetMaterialColor("/InGame/Root/Normal/PauseScreen",0,40,40,40,180)XGUIEng.PopPage()
API.SendScriptEventToGlobal(QSB.ScriptEvents.BlackScreenHidden,GUI.GetPlayerID())
API.SendScriptEvent(QSB.ScriptEvents.BlackScreenHidden,GUI.GetPlayerID())end
function ModuleDisplayCore.Local:InterfaceDeactivateBorderScroll(hPQ)
if self.BorderScrollDeactivated then return end;self.BorderScrollDeactivated=true;if hPQ then
Camera.RTS_FollowEntity(hPQ)end;Camera.RTS_SetBorderScrollSize(0)
Camera.RTS_SetZoomWheelSpeed(0)
API.SendScriptEventToGlobal(QSB.ScriptEvents.BorderScrollLocked,GUI.GetPlayerID(),(hPQ or 0))
API.SendScriptEvent(QSB.ScriptEvents.BorderScrollLocked,GUI.GetPlayerID(),hPQ)end
function ModuleDisplayCore.Local:InterfaceActivateBorderScroll()if
not self.BorderScrollDeactivated then return end;self.BorderScrollDeactivated=false
Camera.RTS_FollowEntity(0)Camera.RTS_SetBorderScrollSize(3.0)
Camera.RTS_SetZoomWheelSpeed(4.2)
API.SendScriptEventToGlobal(QSB.ScriptEvents.BorderScrollReset,GUI.GetPlayerID())
API.SendScriptEvent(QSB.ScriptEvents.BorderScrollReset,GUI.GetPlayerID())end
function ModuleDisplayCore.Local:InterfaceDeactivateNormalInterface()
if self.NormalModeHidden then return end;self.NormalModeHidden=true
XGUIEng.PushPage("/InGame/Root/Normal/NotesWindow",false)
XGUIEng.ShowWidget("/InGame/Root/3dOnScreenDisplay",0)XGUIEng.ShowWidget("/InGame/Root/Normal",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/TextMessages",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/MessagePortrait/SpeechStartAgainOrStop",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopRight",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopLeft",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopLeft/TopBar",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopLeft/TopBar/UpdateFunction",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/MessagePortrait/Buttons",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopLeft/QuestLogButton",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopLeft/QuestTimers",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/SubTitles",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/Selected_Merchant",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MissionGoodOrEntityCounter",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MissionTimer",0)HideOtherMenus()
if
XGUIEng.IsWidgetShown("/InGame/Root/Normal/AlignTopLeft/GameClock")==1 then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopLeft/GameClock",0)self.GameClockWasShown=true end
if
XGUIEng.IsWidgetShownEx("/InGame/Root/Normal/ChatOptions/Background")==1 then
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions",0)self.ChatOptionsWasShown=true end
if
XGUIEng.IsWidgetShownEx("/InGame/Root/Normal/MessageLog/Name")==1 then
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog",0)self.MessageLogWasShown=true end;if g_GameExtraNo>0 then
XGUIEng.ShowWidget("/InGame/Root/Normal/Selected_Tradepost",0)end
API.SendScriptEventToGlobal(QSB.ScriptEvents.GameInterfaceHidden,GUI.GetPlayerID())
API.SendScriptEvent(QSB.ScriptEvents.GameInterfaceHidden,GUI.GetPlayerID())end
function ModuleDisplayCore.Local:InterfaceActivateNormalInterface()if not self.NormalModeHidden then
return end;self.NormalModeHidden=false
XGUIEng.ShowWidget("/InGame/Root/Normal",1)
XGUIEng.ShowWidget("/InGame/Root/3dOnScreenDisplay",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/MessagePortrait/SpeechStartAgainOrStop",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopRight",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopLeft",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopLeft/TopBar",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopLeft/TopBar/UpdateFunction",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/MessagePortrait/Buttons",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopLeft/QuestLogButton",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopLeft/QuestTimers",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/Selected_Merchant",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message",1)XGUIEng.PopPage()if g_MissionTimerEndTime then
XGUIEng.ShowWidget("/InGame/Root/Normal/MissionTimer",1)end;if g_MissionGoodOrEntityCounterAmountToReach then
XGUIEng.ShowWidget("/InGame/Root/Normal/MissionGoodOrEntityCounter",1)end
if self.GameClockWasShown then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopLeft/GameClock",1)self.GameClockWasShown=false end
if self.ChatOptionsWasShown then
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions",1)self.ChatOptionsWasShown=false end
if self.MessageLogWasShown then
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog",1)self.MessageLogWasShown=false end;if g_GameExtraNo>0 then
XGUIEng.ShowWidget("/InGame/Root/Normal/Selected_Tradepost",1)end
API.SendScriptEventToGlobal(QSB.ScriptEvents.GameInterfaceShown,GUI.GetPlayerID())
API.SendScriptEvent(QSB.ScriptEvents.GameInterfaceShown,GUI.GetPlayerID())end;Swift:RegisterModule(ModuleDisplayCore)