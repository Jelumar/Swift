
ModuleInteractiveChests={Properties={Name="ModuleInteractiveChests"},Global={Chests={}},Local={},Shared={},Text={Chest={Title={de="Schatztruhe",en="Treasure Chest"},Text={de="Diese Truhe enthält einen geheimen Schatz. Öffnet sie, um den Schatz zu bergen.",en="This chest contains a secred treasure. Open it to salvage the treasure."}},Treasure={Title={de="Versteckter Schatz",en="Hidden treasure"},Text={de="Ihr habt einen geheimen Schatz entdeckt. Beeilt Euch und beansprucht ihn für Euch!",en="You have discovered a secred treasure. Be quick to claim it before it is to late!"}}}}QSB.NonPlayerCharacterObjects={}
function ModuleInteractiveChests.Global:OnGameStart()
QSB.ScriptEvents.InteractiveTreasureActivated=API.RegisterScriptEvent("Event_InteractiveTreasureActivated")end
function ModuleInteractiveChests.Global:OnEvent(QDnlt,LmcA2auZ,...)
if
QDnlt==QSB.ScriptEvents.ObjectReset then if IO[arg[1]]and IO[arg[1]].IsInteractiveChest then
self:ResetIOChest(arg[1])end elseif
QDnlt==QSB.ScriptEvents.ObjectDelete then
if IO[arg[1]]and IO[arg[1]].IsInteractiveChest then end end end
function ModuleInteractiveChests.Global:CreateRandomChest(Q,ZA,_IQQ,XpkjA,pVRj,fuZ3z86,er)
_IQQ=math.floor((
_IQQ~=nil and _IQQ>0 and _IQQ)or 1)
XpkjA=math.floor((XpkjA~=nil and XpkjA>1 and XpkjA)or 2)if not pVRj then pVRj=function()end end
assert(ZA~=nil,"CreateRandomChest: Good does not exist!")
assert(_IQQ<=XpkjA,"CreateRandomChest: min amount must be smaller or equal than max amount!")
debug(string.format("ModuleInteractiveChests: Creating chest (%s, %s, %d, %d, %s, %s)",Q,Logic.GetGoodTypeName(ZA),_IQQ,XpkjA,tostring(pVRj),tostring(er)))
local DFb100j=ModuleInteractiveChests.Text.Treasure.Title
local XL_=ModuleInteractiveChests.Text.Treasure.Text
if not er then
DFb100j=ModuleInteractiveChests.Text.Chest.Title
XL_=ModuleInteractiveChests.Text.Chest.Text;local yxjl=ReplaceEntity(Q,Entities.XD_ScriptEntity,0)
Logic.SetModel(yxjl,Models.Doodads_D_X_ChestClose)Logic.SetVisible(yxjl,true)end;local WYdR=_IQQ
if _IQQ<XpkjA then WYdR=math.random(_IQQ,XpkjA)end;local QKKks_zt;local Are7xU
if not fuZ3z86 then Are7xU={ZA,WYdR}else QKKks_zt={ZA,WYdR}end
API.SetupObject{Name=Q,IsInteractiveChest=true,Title=DFb100j,Text=XL_,Reward=Are7xU,DirectReward=QKKks_zt,Texture={1,6},Distance=(er and 1200)or 650,Waittime=0,State=0,DoNotChangeModel=er==true,CallbackOpened=pVRj,Action=function(ZG,Vu0cCAf,q)if
not ZG.DoNotChangeModel then
Logic.SetModel(GetID(ZG.Name),Models.Doodads_D_X_ChestOpenEmpty)end;if ZG.DirectReward then
AddGood(ZG.DirectReward[1],ZG.DirectReward[2],q)end
IO[ZG.Name]:CallbackOpened()
API.SendScriptEvent(QSB.ScriptEvents.InteractiveTreasureActivated,ZG.Name,Vu0cCAf,q)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(%d, "%s", %d, %d)]],QSB.ScriptEvents.InteractiveTreasureActivated,ZG.Name,Vu0cCAf,q))end}end
function ModuleInteractiveChests.Global:ResetIOChest(kP7O5)
if
not IO[kP7O5].DoNotChangeModel then
local lqT=ReplaceEntity(kP7O5,Entities.XD_ScriptEntity,0)
Logic.SetModel(lqT,Models.Doodads_D_X_ChestClose)Logic.SetVisible(lqT,true)end end;function ModuleInteractiveChests.Global:CreateRandomGoldChest(mP3mlD)
self:CreateRandomChest(mP3mlD,Goods.G_Gold,300,600,false)end
function ModuleInteractiveChests.Global:CreateRandomResourceChest(PrPyxMK)
local tczrIB={Goods.G_Iron,Goods.G_Stone,Goods.G_Wood,Goods.G_Wool,Goods.G_Carcass,Goods.G_Herb,Goods.G_Honeycomb,Goods.G_Milk,Goods.G_RawFish,Goods.G_Grain}local a=tczrIB[math.random(1,#tczrIB)]
self:CreateRandomChest(PrPyxMK,a,30,60,false)end
function ModuleInteractiveChests.Global:CreateRandomLuxuryChest(wqU76o)
local LB1Z={Goods.G_Salt,Goods.G_Dye}
if g_GameExtraNo>=1 then table.insert(LB1Z,Goods.G_Gems)
table.insert(LB1Z,Goods.G_MusicalInstrument)table.insert(LB1Z,Goods.G_Olibanum)end;local N9L=LB1Z[math.random(1,#LB1Z)]
self:CreateRandomChest(wqU76o,N9L,50,100,false)end
function ModuleInteractiveChests.Local:OnGameStart()
QSB.ScriptEvents.InteractiveTreasureActivated=API.RegisterScriptEvent("Event_InteractiveTreasureActivated")end;Swift:RegisterModule(ModuleInteractiveChests)