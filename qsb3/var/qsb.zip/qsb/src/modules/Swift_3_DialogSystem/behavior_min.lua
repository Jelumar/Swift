
function Reprisal_Dialog(...)return B_Reprisal_Dialog:new(...)end
B_Reprisal_Dialog={Name="Reprisal_Dialog",Description={en="Reprisal: Calls a function to start an new dialog briefing.",de="Lohn: Ruft die Funktion auf und startet den enthaltenen Dialog."},Parameter={{ParameterType.Default,en="Dialog name",de="Name des Dialog"},{ParameterType.Default,en="Dialog function",de="Funktion mit Dialog"}}}function B_Reprisal_Dialog:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function B_Reprisal_Dialog:AddParameter(QDnlt,LmcA2auZ)
if(
QDnlt==0)then self.DialogName=LmcA2auZ elseif(QDnlt==1)then self.Function=LmcA2auZ end end;function B_Reprisal_Dialog:CustomFunction(Q)
_G[self.Function](self.DialogName,Q.ReceivingPlayer)end
function B_Reprisal_Dialog:Debug(ZA)
if
self.DialogName==nil or self.DialogName==""then
error(string.format("%s: %s: Dialog name is invalid!",ZA.Identifier,self.Name))return true end
if not type(_G[self.Function])=="function"then
error(
ZA.Identifier..": "..
self.Name..": '"..self.Function.."' was not found!")return true end;return false end;Swift:RegisterBehavior(B_Reprisal_Dialog)function Reward_Dialog(...)return
B_Reward_Dialog:new(...)end
B_Reward_Dialog=Swift:CopyTable(B_Reprisal_Dialog)B_Reward_Dialog.Name="Reward_Dialog"
B_Reward_Dialog.Description.en="Reward: Calls a function to start an new dialog briefing."
B_Reward_Dialog.Description.de="Lohn: Ruft die Funktion auf und startet den enthaltenen Dialog."B_Reward_Dialog.GetReprisalTable=nil
B_Reward_Dialog.GetRewardTable=function(_IQQ,XpkjA)return
{Reward.Custom,{_IQQ,_IQQ.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_Dialog)function Trigger_Dialog(...)return
B_Trigger_Dialog:new(...)end
B_Trigger_Dialog={Name="Trigger_Dialog",Description={en="Trigger: Checks if an dialog has concluded and starts the quest if so.",de="Auslöser: Prüft, ob ein Dialog beendet ist und startet dann den Quest."},Parameter={{ParameterType.Default,en="Dialog name",de="Name des Dialog"},{ParameterType.PlayerID,en="Player ID",de="Player ID"},{ParameterType.Number,en="Wait time",de="Wartezeit"}}}function B_Trigger_Dialog:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_Dialog:AddParameter(pVRj,fuZ3z86)
if(
pVRj==0)then self.DialogName=fuZ3z86 elseif(pVRj==1)then self.PlayerID=fuZ3z86*1 elseif(pVRj==
2)then fuZ3z86=fuZ3z86 or 0;self.WaitTime=fuZ3z86*1 end end
function B_Trigger_Dialog:CustomFunction(er)
if
API.GetCinematicEventStatus(self.DialogName,self.PlayerID)==CinematicEventStatus.Concluded then
if
self.WaitTime and self.WaitTime>0 then
self.WaitTimeTimer=self.WaitTimeTimer or Logic.GetTime()if
Logic.GetTime()>=self.WaitTimeTimer+self.WaitTime then return true end else return true end end;return false end
function B_Trigger_Dialog:Debug(DFb100j)if self.WaitTime<0 then
error(string.format("%s: %s: Wait time must be 0 or greater!",DFb100j.Identifier,self.Name))return true end
if
self.PlayerID<1 or self.PlayerID>8 then
error(string.format("%s: %s: Player-ID must be between 1 and 8!",DFb100j.Identifier,self.Name))return true end
if self.DialogName==nil or self.DialogName==""then
error(string.format("%s: %s: Dialog name is invalid!",DFb100j.Identifier,self.Name))return true end;return false end;Swift:RegisterBehavior(B_Trigger_Dialog)