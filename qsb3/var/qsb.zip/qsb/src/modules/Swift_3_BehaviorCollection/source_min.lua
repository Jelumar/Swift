
ModuleBehaviorCollection={Properties={Name="ModuleBehaviorCollection"},Global={Cutscene={},CutsceneQueue={},CutsceneCounter=0},Local={Cutscene={}},Shared={Text={FastForwardActivate={de="Beschleunigen",en="Fast Forward"},FastForwardDeactivate={de="Zurücksetzen",en="Normal Speed"},FastFormardMessage={de="SCHNELLER VORLAUF",en="FAST FORWARD"}}}}
function ModuleBehaviorCollection.Global:OnGameStart()
self:OverrideIsObjectiveCompleted()self:OverrideOnQuestTriggered()end
function ModuleBehaviorCollection.Global:OnEvent(QDnlt,LmcA2auZ,...)
if QDnlt==
QSB.ScriptEvents.ThiefInfiltratedBuilding then
self:OnThiefInfiltratedBuilding(arg[1],arg[2],arg[3],arg[4])elseif QDnlt==QSB.ScriptEvents.ThiefDeliverEarnings then
self:OnThiefDeliverEarnings(arg[1],arg[2],arg[3],arg[4],arg[5])end end
function ModuleBehaviorCollection.Global:OverrideOnQuestTriggered()
QuestTemplate.Trigger_Orig_QSB_SwiftBehaviors=QuestTemplate.Trigger
QuestTemplate.Trigger=function(Q)
for ZA=1,#Q.Objectives,1 do
if Q.Objectives[ZA]then
if Q.Objectives[ZA].Type==
Objective.DestroyEntities and
Q.Objectives[ZA].Data[1]==3 then
if
Q.Objectives[ZA].Data[5]~=true then
local _IQQ=Q.Objectives[ZA].Data[2][0]local XpkjA=Q.Objectives[ZA].Data[3]
for fuZ3z86=1,_IQQ,1 do
local er=GetID(Q.Objectives[ZA].Data[2][fuZ3z86])local DFb100j={Logic.GetSpawnedEntities(er)}for XL_=1,#DFb100j,1 do
DestroyEntity(DFb100j[XL_])end end
while(XpkjA>0)do
for WYdR=1,_IQQ,1 do if XpkjA<1 then break end
local QKKks_zt=GetID(Q.Objectives[ZA].Data[2][WYdR])Logic.RespawnResourceEntity_Spawn(QKKks_zt)
XpkjA=XpkjA-1 end end
local pVRj=Logic.GetSpawnedEntities(Q.Objectives[ZA].Data[2][1])
if not Q.Objectives[ZA].Data[6]then
Q.Objectives[ZA].Data[6]={7,12}
if
Logic.IsEntityInCategory(pVRj,EntityCategories.AttackableAnimal)==1 then Q.Objectives[ZA].Data[6]={13,8}end end;Q.Objectives[ZA].Data[5]=true end elseif Q.Objectives[ZA].Type==Objective.Deliver and
Q.Objectives[ZA].Data[8]==true then
local Are7xU=Q.Objectives[ZA].Data;Q.Objectives[ZA].Data[2]=
(Are7xU[2]>100 and 100)or Are7xU[2]
Q.Objectives[ZA].Data[2]=(
Are7xU[2]<1 and 1)or Are7xU[2]
if Are7xU[9]==nil then if Q.Objectives[ZA].Data[9]==nil then
Q.Objectives[ZA].Data[9]=Q.Objectives[ZA].Data[2]end
local yxjl=
Logic.GetGoodCategoryForGoodType(Are7xU[1])==GoodCategories.GC_Resource;local ZG=Are7xU[1]==Goods.G_Gold
local Vu0cCAf=GetPlayerGoodsInSettlement(Are7xU[1],Q.ReceivingPlayer,false)
if API.CastleStoreGetGoodAmount then Vu0cCAf=Vu0cCAf+
API.CastleStoreGetGoodAmount(Q.ReceivingPlayer,Are7xU[1])end;Vu0cCAf=Vu0cCAf+math.ceil(Vu0cCAf*0.2)
if ZG and
Vu0cCAf<250 then Vu0cCAf=250 elseif yxjl and Vu0cCAf<48 then Vu0cCAf=48 elseif not ZG and not yxjl and
Vu0cCAf<18 then Vu0cCAf=18 end
local q=math.ceil((Vu0cCAf/100)*Are7xU[9])Q.Objectives[ZA].Data[2]=q end end end end;Q:Trigger_Orig_QSB_SwiftBehaviors()end end
function ModuleBehaviorCollection.Global:OverrideIsObjectiveCompleted()
QuestTemplate.IsObjectiveCompleted_Orig_QSB_SwiftBehaviors=QuestTemplate.IsObjectiveCompleted
QuestTemplate.IsObjectiveCompleted=function(kP7O5,lqT)local mP3mlD=lqT.Type
if lqT.Completed~=nil then if
lqT.Data[1]==3 then lqT.Data[5]=nil end;return lqT.Completed end
if mP3mlD==Objective.DestroyEntities then if lqT.Data[1]==3 then
lqT.Completed=kP7O5:AreSpawnedQuestEntitiesDestroyed(lqT)else
return kP7O5:IsObjectiveCompleted_Orig_QSB_SwiftBehaviors(lqT)end else return
kP7O5:IsObjectiveCompleted_Orig_QSB_SwiftBehaviors(lqT)end end
QuestTemplate.AreSpawnedQuestEntitiesDestroyed=function(PrPyxMK,tczrIB)
if tczrIB.Data[1]==3 then local a={}for wqU76o=1,tczrIB.Data[2][0],1
do local LB1Z=GetID(tczrIB.Data[2][wqU76o])
a=Array_Append(a,{Logic.GetSpawnedEntities(LB1Z)})end;if#a==0 then
return true end end end end
function ModuleBehaviorCollection.Global:GetPossibleModels()local N9L={}
for hDc_M,qW0lRiD1 in pairs(Models)do
if



not
string.find(hDc_M,"Animals_")and not string.find(hDc_M,"MissionMap_")and not string.find(hDc_M,"R_Fish")and not string.find(hDc_M,"^[GEHUVXYZgt][ADSTfm]*")and
not string.find(string.lower(hDc_M),"goods|tools_")then table.insert(N9L,hDc_M)end end;table.insert(N9L,"Effects_Dust01")
table.insert(N9L,"Effects_E_DestructionSmoke")table.insert(N9L,"Effects_E_DustLarge")
table.insert(N9L,"Effects_E_DustSmall")table.insert(N9L,"Effects_E_Firebreath")
table.insert(N9L,"Effects_E_Fireworks01")table.insert(N9L,"Effects_E_Flies01")
table.insert(N9L,"Effects_E_Grasshopper03")table.insert(N9L,"Effects_E_HealingFX")
table.insert(N9L,"Effects_E_Knight_Chivalry_Aura")table.insert(N9L,"Effects_E_Knight_Plunder_Aura")
table.insert(N9L,"Effects_E_Knight_Song_Aura")table.insert(N9L,"Effects_E_Knight_Trader_Aura")
table.insert(N9L,"Effects_E_Knight_Wisdom_Aura")table.insert(N9L,"Effects_E_KnightFight")
table.insert(N9L,"Effects_E_NA_BlowingSand01")table.insert(N9L,"Effects_E_NE_BlowingSnow01")
table.insert(N9L,"Effects_E_Oillamp")table.insert(N9L,"Effects_E_SickBuilding")
table.insert(N9L,"Effects_E_Splash")table.insert(N9L,"Effects_E_Torch")
table.insert(N9L,"Effects_Fire01")table.insert(N9L,"Effects_FX_Lantern")
table.insert(N9L,"Effects_FX_SmokeBIG")table.insert(N9L,"Effects_XF_BuildingSmoke")
table.insert(N9L,"Effects_XF_BuildingSmokeLarge")
table.insert(N9L,"Effects_XF_BuildingSmokeMedium")table.insert(N9L,"Effects_XF_HouseFire")
table.insert(N9L,"Effects_XF_HouseFireLo")table.insert(N9L,"Effects_XF_HouseFireMedium")
table.insert(N9L,"Effects_XF_HouseFireSmall")
if g_GameExtraNo>0 then
table.insert(N9L,"Effects_E_KhanaTemple_Fire")table.insert(N9L,"Effects_E_Knight_Saraya_Aura")end;table.sort(N9L)return N9L end
function ModuleBehaviorCollection.Global:OnThiefInfiltratedBuilding(iD1IUx,JLCOx_ak,hPQ,R1FIoQI)
for NsoTwDs=1,Quests[0]do
if


Quests[NsoTwDs]and Quests[NsoTwDs].State==QuestState.Active and Quests[NsoTwDs].ReceivingPlayer==JLCOx_ak then
for HGli=1,Quests[NsoTwDs].Objectives[0]do
if
Quests[NsoTwDs].Objectives[HGli].Type==Objective.Custom2 then
if
Quests[NsoTwDs].Objectives[HGli].Data[1].Name=="Goal_SpyOnBuilding"then
if
GetID(Quests[NsoTwDs].Objectives[HGli].Data[1].Building)==hPQ then
Quests[NsoTwDs].Objectives[HGli].Data[1].Infiltrated=true;if
Quests[NsoTwDs].Objectives[HGli].Data[1].Delete then DestroyEntity(iD1IUx)end end elseif
Quests[NsoTwDs].Objectives[HGli].Data[1].Name=="Goal_StealFromBuilding"then local iy;local m6SCS0=
Logic.IsEntityInCategory(hPQ,EntityCategories.Cathedrals)==1;local NUhYw6R4=
Logic.GetEntityType(hPQ)==Entities.B_StoreHouse
if NUhYw6R4 or
m6SCS0 then
Quests[NsoTwDs].Objectives[HGli].Data[1].SuccessfullyStohlen=true else
for Hv=1,#
Quests[NsoTwDs].Objectives[HGli].Data[1].RobberList do
local Ch=Quests[NsoTwDs].Objectives[HGli].Data[1].RobberList[Hv]if Ch[1]==hPQ and Ch[2]==iD1IUx then iy=true;break end end end;if not iy then
table.insert(Quests[NsoTwDs].Objectives[HGli].Data[1].RobberList,{hPQ,iD1IUx})end end end end end end end
function ModuleBehaviorCollection.Global:OnThiefDeliverEarnings(urkh,zhzpBSx,rHSjalVy,TjhsnP,t5jzEd9)
for JZAU2=1,Quests[0]do
if Quests[JZAU2]and
Quests[JZAU2].State==QuestState.Active and
Quests[JZAU2].ReceivingPlayer==zhzpBSx then
for zPXTTg=1,Quests[JZAU2].Objectives[0]
do
if
Quests[JZAU2].Objectives[zPXTTg].Type==Objective.Custom2 then
if
Quests[JZAU2].Objectives[zPXTTg].Data[1].Name=="Goal_StealFromBuilding"then
for seMLr=1,#
Quests[JZAU2].Objectives[zPXTTg].Data[1].RobberList do
local qX=Quests[JZAU2].Objectives[zPXTTg].Data[1].RobberList[seMLr]
if
qX[1]==
GetID(Quests[JZAU2].Objectives[zPXTTg].Data[1].Building)and qX[2]==urkh then
Quests[JZAU2].Objectives[zPXTTg].Data[1].SuccessfullyStohlen=true;break end end elseif
Quests[JZAU2].Objectives[zPXTTg].Data[1].Name=="Goal_StealGold"then
local h_8=Quests[JZAU2].Objectives[zPXTTg].Data[1]
if h_8.Target==-1 or h_8.Target==TjhsnP then
Quests[JZAU2].Objectives[zPXTTg].Data[1].StohlenGold=
Quests[JZAU2].Objectives[zPXTTg].Data[1].StohlenGold+t5jzEd9;if h_8.Printout then
API.Note(string.format("%d/%d %s",h_8.StohlenGold,h_8.Amount,API.Localize({de="Talern gestohlen",en="gold stolen"})))end end end end end end end end
function ModuleBehaviorCollection.Local:OnGameStart()
self:DisplayQuestObjective()self:GetEntitiesOrTerritoryList()
self:OverrideSaveQuestEntityTypes()end
function ModuleBehaviorCollection.Local:OnEvent(xL7OTb,w8T3f,...)end
function ModuleBehaviorCollection.Local:DisplayQuestObjective()
GUI_Interaction.DisplayQuestObjective_Orig_SwiftBehavior=GUI_Interaction.DisplayQuestObjective
GUI_Interaction.DisplayQuestObjective=function(K,qL)local vfIyB=tonumber(K)if vfIyB then K=vfIyB end
local quNsijN,QUh2tc=GUI_Interaction.GetPotentialSubQuestAndType(K)local qboV="/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives"
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives",0)
if QUh2tc==Objective.DestroyEntities and
quNsijN.Objectives[1].Data[1]==3 then
local nSBOx7=qboV.."/GroupEntityType"
local u=Wrapped_GetStringTableText(K,"UI_Texts/QuestDestroy")
local Ki1=GUI_Interaction.GetEntitiesOrTerritoryListForQuest(quNsijN,QUh2tc)local zz1QI=#Ki1;if
not quNsijN.Objectives[1].Data[5]and#Ki1 ==0 then
zz1QI=
quNsijN.Objectives[1].Data[2][0]*quNsijN.Objectives[1].Data[3]end
XGUIEng.ShowWidget(
nSBOx7 .."/AdditionalCaption",0)
XGUIEng.ShowWidget(nSBOx7 .."/AdditionalCondition",0)
SetIcon(nSBOx7 .."/Icon",quNsijN.Objectives[1].Data[6])
XGUIEng.SetText(nSBOx7 .."/Number","{center}"..zz1QI)
XGUIEng.SetText(nSBOx7 .."/Caption","{center}"..u)XGUIEng.ShowWidget(nSBOx7,1)
GUI_Interaction.SetQuestTypeIcon(nSBOx7 ..
"/QuestTypeIcon",K)
if quNsijN.State==QuestState.Over then
if
quNsijN.Result==QuestResult.Success then
XGUIEng.ShowWidget(qboV.."/QuestOverSuccess",1)elseif quNsijN.Result==QuestResult.Failure then
XGUIEng.ShowWidget(qboV.."/QuestOverFailure",1)end end;return end
GUI_Interaction.DisplayQuestObjective_Orig_SwiftBehavior(K,qL)end end
function ModuleBehaviorCollection.Local:GetEntitiesOrTerritoryList()
GUI_Interaction.GetEntitiesOrTerritoryListForQuest_Orig_SwiftBehavior=GUI_Interaction.GetEntitiesOrTerritoryListForQuest
GUI_Interaction.GetEntitiesOrTerritoryListForQuest=function(kFTAh,LBf)local dijn4Ph=true;local CO1={}
if
LBf==Objective.DestroyEntities then
if kFTAh.Objectives[1].Data and
kFTAh.Objectives[1].Data[1]==3 then
for RlZo=1,kFTAh.Objectives[1].Data[2][0],1
do
local SUn=GetID(kFTAh.Objectives[1].Data[2][RlZo])
CO1=Array_Append(CO1,{Logic.GetSpawnedEntities(SUn)})end;return CO1,dijn4Ph end end;return
GUI_Interaction.GetEntitiesOrTerritoryListForQuest_Orig_SwiftBehavior(kFTAh,LBf)end end
function ModuleBehaviorCollection.Local:OverrideSaveQuestEntityTypes()
GUI_Interaction.SaveQuestEntityTypes_Orig_SwiftBehavior=GUI_Interaction.SaveQuestEntityTypes
GUI_Interaction.SaveQuestEntityTypes=function(Ib4)if
g_Interaction.SavedQuestEntityTypes[Ib4]~=nil then return end
local fjV1G2,Do=GUI_Interaction.GetPotentialSubQuestAndType(Ib4)local _
if Do~=Objective.DestroyEntities or
fjV1G2.Objectives[1].Data[1]~=3 then return end
_=GUI_Interaction.GetEntitiesOrTerritoryListForQuest(fjV1G2,Do)_[0]=#_
if _~=nil then
g_Interaction.SavedQuestEntityTypes[Ib4]={}
for TqYJ4=1,_[0],1 do if Logic.IsEntityAlive(_[TqYJ4])then
local DI=Logic.GetEntityType(GetID(_[TqYJ4]))
table.insert(g_Interaction.SavedQuestEntityTypes[Ib4],TqYJ4,DI)end end;return end
GUI_Interaction.SaveQuestEntityTypes_Orig_SwiftBehavior(Ib4)end end;Swift:RegisterModule(ModuleBehaviorCollection)