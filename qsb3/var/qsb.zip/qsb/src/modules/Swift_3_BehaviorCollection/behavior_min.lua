
function Goal_MoveToPosition(...)return B_Goal_MoveToPosition:new(...)end
B_Goal_MoveToPosition={Name="Goal_MoveToPosition",Description={en="Goal: A entity have to moved as close as the distance to another entity. The target can be marked with a static marker.",de="Ziel: Ein Entity muss sich einer anderen bis auf eine bestimmte Distanz nähern. Die Lupe wird angezeigt, das Ziel kann markiert werden."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.ScriptName,en="Target",de="Ziel"},{ParameterType.Number,en="Distance",de="Entfernung"},{ParameterType.Custom,en="Marker",de="Ziel markieren"}}}
function B_Goal_MoveToPosition:GetGoalTable()return
{Objective.Distance,self.Entity,self.Target,self.Distance,self.Marker}end
function B_Goal_MoveToPosition:AddParameter(QDnlt,LmcA2auZ)
if(QDnlt==0)then self.Entity=LmcA2auZ elseif(QDnlt==1)then
self.Target=LmcA2auZ elseif(QDnlt==2)then self.Distance=LmcA2auZ*1 elseif(QDnlt==3)then
self.Marker=API.ToBoolean(LmcA2auZ)end end;function B_Goal_MoveToPosition:GetCustomData(Q)local ZA={}
if Q==3 then ZA={"true","false"}end;return ZA end
Swift:RegisterBehavior(B_Goal_MoveToPosition)
function Goal_WinQuest(...)return B_Goal_WinQuest:new(...)end
B_Goal_WinQuest={Name="Goal_WinQuest",Description={en="Goal: The player has to win a given quest.",de="Ziel: Der Spieler muss eine angegebene Quest erfolgreich abschliessen."},Parameter={{ParameterType.QuestName,en="Quest Name",de="Questname"}}}function B_Goal_WinQuest:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_WinQuest:AddParameter(_IQQ,XpkjA)if(
_IQQ==0)then self.Quest=XpkjA end end
function B_Goal_WinQuest:CustomFunction(pVRj)
local fuZ3z86=Quests[GetQuestID(self.Quest)]if fuZ3z86 then
if fuZ3z86.Result==QuestResult.Failure then return false end
if fuZ3z86.Result==QuestResult.Success then return true end end
return nil end
function B_Goal_WinQuest:Debug(er)
if
Quests[GetQuestID(self.Quest)]==nil then
error(er.Identifier..": "..self.Name..
": Quest '"..self.Quest.."' does not exist!")return true end;return false end;Swift:RegisterBehavior(B_Goal_WinQuest)function Goal_AmmunitionAmount(...)return
B_Goal_AmmunitionAmount:new(...)end
B_Goal_AmmunitionAmount={Name="Goal_AmmunitionAmount",Description={en="Goal: Reach a smaller or bigger value than the given amount of ammunition in a war machine.",de="Ziel: Über- oder unterschreite die angegebene Anzahl Munition in einem Kriegsgerät."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Amount",de="Menge"}}}
function B_Goal_AmmunitionAmount:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_AmmunitionAmount:AddParameter(DFb100j,XL_)
if(DFb100j==0)then self.Scriptname=XL_ elseif
(DFb100j==1)then
self.bRelSmallerThan=tostring(XL_)=="true"or XL_=="<"elseif(DFb100j==2)then self.Amount=XL_*1 end end
function B_Goal_AmmunitionAmount:CustomFunction()local WYdR=GetID(self.Scriptname)if not
IsExisting(WYdR)then return false end
local QKKks_zt=Logic.GetAmmunitionAmount(WYdR)
if
(self.bRelSmallerThan and QKKks_zt<self.Amount)or
(not self.bRelSmallerThan and QKKks_zt>=self.Amount)then return true end;return nil end
function B_Goal_AmmunitionAmount:Debug(Are7xU)if self.Amount<0 then
error(Are7xU.Identifier..": "..
self.Name..": Amount is negative")return true end end
function B_Goal_AmmunitionAmount:GetCustomData(yxjl)if yxjl==1 then return{"<",">="}end end;Swift:RegisterBehavior(B_Goal_AmmunitionAmount)function Goal_CityReputation(...)return
B_Goal_CityReputation:new(...)end
B_Goal_CityReputation={Name="Goal_CityReputation",Description={en="Goal: The reputation of the quest receivers city must at least reach the desired hight.",de="Ziel: Der Ruf der Stadt des Empfängers muss mindestens so hoch sein, wie angegeben."},Parameter={{ParameterType.Number,en="City reputation",de="Ruf der Stadt"}},Text={de="RUF DER STADT{cr}{cr}Hebe den Ruf der Stadt durch weise Herrschaft an!{cr}Benötigter Ruf: %d",en="CITY REPUTATION{cr}{cr}Raise your reputation by fair rulership!{cr}Needed reputation: %d"}}
function B_Goal_CityReputation:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end;function B_Goal_CityReputation:AddParameter(ZG,Vu0cCAf)
if(ZG==0)then self.Reputation=Vu0cCAf*1 end end
function B_Goal_CityReputation:CustomFunction(q)
self:SetCaption(q)
local kP7O5=Logic.GetCityReputation(q.ReceivingPlayer)*100;if kP7O5 >=self.Reputation then return true end end
function B_Goal_CityReputation:SetCaption(lqT)
if
not lqT.QuestDescription or lqT.QuestDescription==""then
local mP3mlD=string.format(API.Localize(self.Text),self.Reputation)
Swift:ChangeCustomQuestCaptionText(mP3mlD.."%",lqT)end end
function B_Goal_CityReputation:Debug(PrPyxMK)
if
type(self.Reputation)~="number"or self.Reputation<
0 or self.Reputation>100 then
error(PrPyxMK.Identifier..
": "..self.Name..": Reputation must be between 0 and 100!")return true end;return false end;Swift:RegisterBehavior(B_Goal_CityReputation)function Goal_DestroySpawnedEntities(...)return
B_Goal_DestroySpawnedEntities:new(...)end
B_Goal_DestroySpawnedEntities={Name="Goal_DestroySpawnedEntities",Description={en="Goal: Destroy all entities spawned at the spawnpoint.",de="Ziel: Zerstöre alle Entitäten, die bei dem Spawnpoint erzeugt wurde."},Parameter={{ParameterType.ScriptName,en="Spawnpoint",de="Spawnpoint"},{ParameterType.Number,en="Amount",de="Menge"},{ParameterType.Custom,en="Name is prefixed",de="Name ist Präfix"}}}
function B_Goal_DestroySpawnedEntities:GetGoalTable()
if self.Prefixed then
local tczrIB=table.remove(self.SpawnPoint)local a=1;while(IsExisting(tczrIB..a))do
table.insert(self.SpawnPoint,tczrIB..a)a=a+1 end
assert(#self.SpawnPoint>0,"No spawnpoints found!")end
return{Objective.DestroyEntities,3,self.SpawnPoint,self.Amount}end
function B_Goal_DestroySpawnedEntities:AddParameter(wqU76o,LB1Z)
if(wqU76o==0)then self.SpawnPoint={LB1Z}elseif(
wqU76o==1)then self.Amount=LB1Z*1 elseif(wqU76o==2)then LB1Z=LB1Z or"false"
self.Prefixed=API.ToBoolean(LB1Z)end end
function B_Goal_DestroySpawnedEntities:GetMsgKey()
local N9L=GetID(self.SpawnPoint[1])
if N9L~=0 then
local hDc_M=Logic.GetEntityTypeName(Logic.GetEntityType(N9L))
if
Logic.IsEntityTypeInCategory(N9L,EntityCategories.AttackableBuilding)==1 then return"Quest_Destroy_Leader"elseif

hDc_M:find("Bear")or hDc_M:find("Lion")or hDc_M:find("Tiger")or hDc_M:find("Wolf")then return
"Quest_DestroyEntities_Predators"elseif
hDc_M:find("Military")or hDc_M:find("Cart")then return"Quest_DestroyEntities_Unit"end end;return"Quest_DestroyEntities"end;function B_Goal_DestroySpawnedEntities:GetCustomData(qW0lRiD1)
if qW0lRiD1 ==2 then return{"false","true"}end end
Swift:RegisterBehavior(B_Goal_DestroySpawnedEntities)
function Goal_DeliverRelative(...)return B_Goal_DeliverRelative:new(...)end;B_Goal_DeliverRelative=Swift:CopyTable(B_Goal_Deliver)
B_Goal_DeliverRelative.Name="Goal_DeliverRelative"
B_Goal_DeliverRelative.Description.en="Goal: Deliver a relative amount of goods to the requesting player or another player"
B_Goal_DeliverRelative.Description.de="Ziel: Liefere eine relative Menge an Waren zum Auftraggeber oder zu einem anderen Spieler."
B_Goal_DeliverRelative.GetGoalTable=function(iD1IUx,JLCOx_ak)
local hPQ=Logic.GetGoodTypeID(iD1IUx.GoodTypeName)return
{Objective.Deliver,hPQ,math.floor(iD1IUx.GoodAmount+0.5),iD1IUx.OverrideTarget,iD1IUx.IgnoreCapture,{},0,0,true}end;Swift:RegisterBehavior(B_Goal_DeliverRelative)function Goal_StealGold(...)return
B_Goal_StealGold:new(...)end
B_Goal_StealGold={Name="Goal_StealGold",Description={en="Goal: Steal an explicit amount of gold from a players or any players city buildings.",de="Ziel: Diebe sollen eine bestimmte Menge Gold aus feindlichen Stadtgebäuden stehlen."},Parameter={{ParameterType.Number,en="Amount on Gold",de="Zu stehlende Menge"},{ParameterType.Custom,en="Target player",de="Spieler von dem gestohlen wird"},{ParameterType.Custom,en="Cheat earnings",de="Einnahmen generieren"},{ParameterType.Custom,en="Print progress",de="Fortschritt ausgeben"}}}function B_Goal_StealGold:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_StealGold:AddParameter(R1FIoQI,NsoTwDs)
if(
R1FIoQI==0)then self.Amount=NsoTwDs*1 elseif(R1FIoQI==1)then
local HGli=tonumber(NsoTwDs)or-1;self.Target=HGli*1 elseif(R1FIoQI==2)then NsoTwDs=NsoTwDs or"false"
self.CheatEarnings=API.ToBoolean(NsoTwDs)elseif(R1FIoQI==3)then NsoTwDs=NsoTwDs or"true"
self.Printout=API.ToBoolean(NsoTwDs)end;self.StohlenGold=0 end
function B_Goal_StealGold:GetCustomData(iy)if iy==1 then return{"-",1,2,3,4,5,6,7,8}elseif iy==2 then
return{"true","false"}end end
function B_Goal_StealGold:SetDescriptionOverwrite(m6SCS0)
local NUhYw6R4=API.Localize({de=" anderen Spielern ",en=" different parties"})if self.Target~=-1 then NUhYw6R4=API.GetPlayerName(self.Target)
if
NUhYw6R4 ==nil or NUhYw6R4 ==""then NUhYw6R4=" PLAYER_NAME_MISSING "end end
if
self.CheatEarnings then local urkh={self.Target}
if self.Target==-1 then urkh={1,2,3,4,5,6,7,8}end
for zhzpBSx=1,#urkh,1 do
if zhzpBSx~=m6SCS0.ReceivingPlayer and
Logic.GetStoreHouse(zhzpBSx)~=0 then
local rHSjalVy={Logic.GetPlayerEntitiesInCategory(zhzpBSx,EntityCategories.CityBuilding)}
for TjhsnP=1,#rHSjalVy,1 do
local t5jzEd9=Logic.GetBuildingProductEarnings(rHSjalVy[TjhsnP])
if t5jzEd9 <45 and Logic.GetTime()%5 ==0 then Logic.SetBuildingEarnings(rHSjalVy[TjhsnP],
t5jzEd9+1)end end end end end;local Hv=self.Amount-self.StohlenGold
Hv=(Hv>0 and Hv)or 0
local Ch={de="Gold von %s stehlen {cr}{cr}Aus Stadtgebäuden zu stehlende Goldmenge: %d",en="Steal gold from %s {cr}{cr}Amount on gold to steal from city buildings: %d"}return
"{center}"..string.format(API.Localize(Ch),NUhYw6R4,Hv)end
function B_Goal_StealGold:CustomFunction(JZAU2)
Swift:ChangeCustomQuestCaptionText(self:SetDescriptionOverwrite(JZAU2),JZAU2)if self.StohlenGold>=self.Amount then return true end;return nil end;function B_Goal_StealGold:GetIcon()return{5,13}end
function B_Goal_StealGold:Debug(zPXTTg)
if
tonumber(self.Amount)==nil and self.Amount<0 then
error(zPXTTg.Identifier..": "..self.Name..
": amount can not be negative!")return true end;return false end;function B_Goal_StealGold:Reset(seMLr)self.StohlenGold=0 end
Swift:RegisterBehavior(B_Goal_StealGold)
function Goal_StealFromBuilding(...)return B_Goal_StealFromBuilding:new(...)end
B_Goal_StealFromBuilding={Name="Goal_StealFromBuilding",Description={en="Goal: The player has to steal from a building. Not a castle and not a village storehouse!",de="Ziel: Der Spieler muss ein bestimmtes Gebäude bestehlen. Dies darf keine Burg und kein Dorflagerhaus sein!"},Parameter={{ParameterType.ScriptName,en="Building",de="Gebäude"},{ParameterType.Custom,en="Cheat earnings",de="Einnahmen generieren"}}}
function B_Goal_StealFromBuilding:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_StealFromBuilding:AddParameter(qX,h_8)
if(qX==0)then self.Building=h_8 elseif(qX==1)then
h_8=h_8 or"false"self.CheatEarnings=API.ToBoolean(h_8)end;self.RobberList={}end;function B_Goal_StealFromBuilding:GetCustomData(xL7OTb)
if xL7OTb==1 then return{"true","false"}end end
function B_Goal_StealFromBuilding:SetDescriptionOverwrite(w8T3f)
local K=
Logic.IsEntityInCategory(GetID(self.Building),EntityCategories.Cathedrals)==1
local qL=Logic.GetEntityType(GetID(self.Building))==Entities.B_StoreHouse
local vfIyB=Logic.GetEntityType(GetID(self.Building))==Entities.B_Cistern;local quNsijN
if K then
quNsijN={de="Sabotage {cr}{cr} Sendet einen Dieb und sabotiert die markierte Kirche.",en="Sabotage {cr}{cr} Send a thief to sabotage the marked chapel."}elseif qL then
quNsijN={de="Lagerhaus bestehlen {cr}{cr} Sendet einen Dieb in das markierte Lagerhaus.",en="Steal from storehouse {cr}{cr} Steal from the marked storehouse."}elseif vfIyB then
quNsijN={de="Sabotage {cr}{cr} Sendet einen Dieb und sabotiert den markierten Brunnen.",en="Sabotage {cr}{cr} Send a thief and break the marked well of the enemy."}else
quNsijN={de="Gebäude bestehlen {cr}{cr} Sendet einen Dieb und bestehlt das markierte Gebäude.",en="Steal from building {cr}{cr} Send a thief to steal from the marked building."}end;return"{center}"..API.Localize(quNsijN)end
function B_Goal_StealFromBuilding:CustomFunction(QUh2tc)if not IsExisting(self.Building)then
if
self.Marker then Logic.DestroyEffect(self.Marker)end;return false end;if
not self.Marker then local qboV=GetPosition(self.Building)
self.Marker=Logic.CreateEffect(EGL_Effects.E_Questmarker,qboV.X,qboV.Y,0)end
if
self.CheatEarnings then local nSBOx7=GetID(self.Building)
local u=Logic.GetBuildingProductEarnings(nSBOx7)if
Logic.IsEntityInCategory(nSBOx7,EntityCategories.CityBuilding)==1 and u<45 and
Logic.GetTime()%5 ==0 then
Logic.SetBuildingEarnings(nSBOx7,u+1)end end
if self.SuccessfullyStohlen then Logic.DestroyEffect(self.Marker)return true end;return nil end;function B_Goal_StealFromBuilding:GetIcon()return{5,13}end
function B_Goal_StealFromBuilding:Debug(K)
local i1=Logic.GetEntityTypeName(Logic.GetEntityType(GetID(self.Building)))
local zz1QI=
Logic.IsEntityInCategory(GetID(self.Building),EntityCategories.Headquarters)==1
if Logic.IsBuilding(GetID(self.Building))==0 then
error(
K.Identifier..": "..self.Name..": target is not a building")return true elseif not IsExisting(self.Building)then
error(K.Identifier..": "..self.Name..
": target is destroyed :(")return true elseif
string.find(i1,"B_NPC_BanditsHQ")or
string.find(i1,"B_NPC_Cloister")or string.find(i1,"B_NPC_StoreHouse")then
error(K.Identifier..
": "..self.Name..": village storehouses are not allowed!")return true elseif zz1QI then
error(K.Identifier..": "..
self.Name..": use Goal_StealInformation for headquarters!")return true end;return false end;function B_Goal_StealFromBuilding:Reset(kFTAh)self.SuccessfullyStohlen=false
self.RobberList={}self.Marker=nil end;function B_Goal_StealFromBuilding:Interrupt(LBf)
Logic.DestroyEffect(self.Marker)end
Swift:RegisterBehavior(B_Goal_StealFromBuilding)
function Goal_SpyOnBuilding(...)return B_Goal_SpyOnBuilding:new(...)end
B_Goal_SpyOnBuilding={Name="Goal_SpyOnBuilding",IconOverwrite={5,13},Description={en="Goal: Infiltrate a building with a thief. A thief must be able to steal from the target building.",de="Ziel: Infiltriere ein Gebäude mit einem Dieb. Nur mit Gebaueden möglich, die bestohlen werden koennen."},Parameter={{ParameterType.ScriptName,en="Target Building",de="Zielgebäude"},{ParameterType.Custom,en="Cheat earnings",de="Einnahmen generieren"},{ParameterType.Custom,en="Destroy Thief",de="Dieb löschen"}}}
function B_Goal_SpyOnBuilding:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_SpyOnBuilding:AddParameter(dijn4Ph,CO1)
if(dijn4Ph==0)then self.Building=CO1 elseif(dijn4Ph==1)then CO1=
CO1 or"false"self.CheatEarnings=API.ToBoolean(CO1)elseif
(dijn4Ph==2)then CO1=CO1 or"true"self.Delete=API.ToBoolean(CO1)end end;function B_Goal_SpyOnBuilding:GetCustomData(RlZo)
if RlZo==1 then return{"true","false"}end end
function B_Goal_SpyOnBuilding:SetDescriptionOverwrite(SUn)
if
not SUn.QuestDescription then
local Ib4={de="Gebäude infriltrieren {cr}{cr}Spioniere das markierte Gebäude mit einem Dieb aus!",en="Infiltrate building {cr}{cr}Spy on the highlighted buildings with a thief!"}return API.Localize(Ib4)else return SUn.QuestDescription end end
function B_Goal_SpyOnBuilding:CustomFunction(fjV1G2)if not IsExisting(self.Building)then
if
self.Marker then Logic.DestroyEffect(self.Marker)end;return false end;if
not self.Marker then local Do=GetPosition(self.Building)
self.Marker=Logic.CreateEffect(EGL_Effects.E_Questmarker,Do.X,Do.Y,0)end
if
self.CheatEarnings then local _=GetID(self.Building)if
Logic.IsEntityInCategory(_,EntityCategories.CityBuilding)==1 and
Logic.GetBuildingEarnings(_)<5 then
Logic.SetBuildingEarnings(_,5)end end
if self.Infiltrated then Logic.DestroyEffect(self.Marker)return true end;return nil end
function B_Goal_SpyOnBuilding:GetIcon()return self.IconOverwrite end
function B_Goal_SpyOnBuilding:Debug(TqYJ4)
if
Logic.IsBuilding(GetID(self.Building))==0 then
error(TqYJ4.Identifier..
": "..self.Name..": target is not a building")return true elseif not IsExisting(self.Building)then
error(TqYJ4.Identifier..": "..self.Name..
": target is destroyed :(")return true end;return false end
function B_Goal_SpyOnBuilding:Reset(DI)self.Infiltrated=false;self.Marker=nil end;function B_Goal_SpyOnBuilding:Interrupt(b)
Logic.DestroyEffect(self.Marker)end
Swift:RegisterBehavior(B_Goal_SpyOnBuilding)
function Goal_FetchItems(...)return B_Goal_FetchItems:new(...)end
B_Goal_FetchItems={Name="Goal_FetchItems",Description={en="Goal: ",de="Ziel: "},Parameter={{ParameterType.Default,en="Search points",de="Suchpunkte"},{ParameterType.Custom,en="Shared model",de="Gemeinsames Modell"},{ParameterType.Number,en="Distance (0 = Default)",de="Enternung (0 = Default)"}},Text={{de="%d/%d Gegenstände gefunden",en="%d/%d Items gefunden"},{de="GEGENSTÄNDE FINDEN {br}{br}Findet die verloren gegangenen Gegenstände.",en="FIND VALUABLES {br}{br}Find the missing items and return them."}},Tools={Models.Doodads_D_X_Sacks,Models.Tools_T_BowNet01,Models.Tools_T_Hammer02,Models.Tools_T_Cushion01,Models.Tools_T_Knife02,Models.Tools_T_Scythe01,Models.Tools_T_SiegeChest01},Distance=300,Finished=false,Positions={},Marker={}}function B_Goal_FetchItems:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_FetchItems:AddParameter(E,KMw7_i1s)
if(
E==0)then self.SearchPositions=KMw7_i1s elseif(E==1)then self.Model=KMw7_i1s elseif(E==2)then if
KMw7_i1s==nil then KMw7_i1s=self.Distance end
self.Distance=KMw7_i1s*1;if self.Distance==0 then self.Distance=300 end end end
function B_Goal_FetchItems:CustomFunction(CQi)
Swift:ChangeCustomQuestCaptionText("{center}"..
API.Localize(self.Text[2]),CQi)
if not self.Finished then self:GetPositions(CQi)
self:CreateMarker(CQi)self:CheckPositions(CQi)
if#self.Marker>0 then return end;self.Finished=true end;return true end
function B_Goal_FetchItems:GetPositions(nHlJ)
if#self.Positions==0 then
if
type(self.SearchPositions)=="table"then self.Positions=self.SearchPositions else local lw4Q7kbl=1
while(IsExisting(
self.SearchPositions..lw4Q7kbl))do
table.insert(self.Positions,GetPosition(
self.SearchPositions..lw4Q7kbl))lw4Q7kbl=lw4Q7kbl+1 end end end end
function B_Goal_FetchItems:CreateMarker(IN)
if#self.Marker==0 then
for QYf1=1,#self.Positions,1 do
local RfsnisO=Logic.CreateEntityOnUnblockedLand(Entities.XD_ScriptEntity,self.Positions[QYf1].X,self.Positions[QYf1].Y,0,0)
if self.Model~=nil and self.Model~="-"then
Logic.SetModel(RfsnisO,Models[self.Model])else
Logic.SetModel(RfsnisO,self.Tools[math.random(1,#self.Tools)])end;Logic.SetVisible(RfsnisO,true)
table.insert(self.Marker,RfsnisO)end end end
function B_Goal_FetchItems:CheckPositions(lvW2ga)local T7RKP={}
Logic.GetKnights(lvW2ga.ReceivingPlayer,T7RKP)
for _L6Bs=#self.Marker,1,-1 do
for SH=1,#T7RKP,1 do
if
IsNear(self.Marker[_L6Bs],T7RKP[SH],self.Distance)then
DestroyEntity(table.remove(self.Marker,_L6Bs))local wU4wYbA9=#self.Positions
local fFeQcIM=wU4wYbA9-#self.Marker
API.Note(string.format(API.Localize(self.Text[1]),fFeQcIM,wU4wYbA9))break end end end end
function B_Goal_FetchItems:Reset(JEHSHPh3)self:Interrupt(JEHSHPh3)end
function B_Goal_FetchItems:Interrupt(bb)self.Finished=false;self.Positions={}
for o5e6fP=1,#self.Marker,1
do DestroyEntity(self.Marker[o5e6fP])end;self.Marker={}end
function B_Goal_FetchItems:GetCustomData(iq7ol)
if iq7ol==1 then
local eMV=ModuleBehaviorCollection.Global:GetPossibleModels()table.insert(eMV,1,"-")return eMV end end;function B_Goal_FetchItems:Debug(WDTNkTD)return false end
Swift:RegisterBehavior(B_Goal_FetchItems)
function Reprisal_SetPosition(...)return B_Reprisal_SetPosition:new(...)end
B_Reprisal_SetPosition={Name="Reprisal_SetPosition",Description={en="Reprisal: Places an entity relative to the position of another. The entity can look the target.",de="Vergeltung: Setzt eine Entity relativ zur Position einer anderen. Die Entity kann zum Ziel ausgerichtet werden."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.ScriptName,en="Target position",de="Zielposition"},{ParameterType.Custom,en="Face to face",de="Ziel ansehen"},{ParameterType.Number,en="Distance",de="Zielentfernung"}}}
function B_Reprisal_SetPosition:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_SetPosition:AddParameter(Oejsws,CkD73N0)
if(Oejsws==0)then self.Entity=CkD73N0 elseif
(Oejsws==1)then self.Target=CkD73N0 elseif(Oejsws==2)then
self.FaceToFace=API.ToBoolean(CkD73N0)elseif(Oejsws==3)then self.Distance=
(CkD73N0 ~=nil and tonumber(CkD73N0))or 100 end end
function B_Reprisal_SetPosition:CustomFunction(PlwhaRKJ)
if not IsExisting(self.Entity)or not
IsExisting(self.Target)then return end;local Caz4NM4Z=GetID(self.Entity)local XVxxx=GetID(self.Target)
local hD,G5BuU5,AfwsY=Logic.EntityGetPos(XVxxx)if Logic.IsBuilding(XVxxx)==1 then
hD,G5BuU5=Logic.GetBuildingApproachPosition(XVxxx)end;local T=
Logic.GetEntityOrientation(XVxxx)+90
if self.FaceToFace then hD=hD+self.Distance*
math.cos(math.rad(T))G5BuU5=G5BuU5+self.Distance*
math.sin(math.rad(T))
Logic.DEBUG_SetSettlerPosition(Caz4NM4Z,hD,G5BuU5)LookAt(self.Entity,self.Target)else
if
Logic.IsBuilding(XVxxx)==1 then hD,G5BuU5=Logic.GetBuildingApproachPosition(XVxxx)end
Logic.DEBUG_SetSettlerPosition(Caz4NM4Z,hD,G5BuU5)end end;function B_Reprisal_SetPosition:GetCustomData(WZs)
if WZs==2 then return{"true","false"}end end
function B_Reprisal_SetPosition:Debug(ITdz)
if
self.FaceToFace then
if
tonumber(self.Distance)==nil or self.Distance<50 then
error(ITdz.Identifier..
": "..self.Name..": Distance is nil or to short!")return true end end
if
not IsExisting(self.Entity)or not IsExisting(self.Target)then
error(ITdz.Identifier..
": "..self.Name..": Mover entity or target entity does not exist!")return true end;return false end;Swift:RegisterBehavior(B_Reprisal_SetPosition)function Reprisal_ChangePlayer(...)return
B_Reprisal_ChangePlayer:new(...)end
B_Reprisal_ChangePlayer={Name="Reprisal_ChangePlayer",Description={en="Reprisal: Changes the owner of the entity or a battalion.",de="Vergeltung: Aendert den Besitzer einer Entity oder eines Battalions."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Custom,en="Player",de="Spieler"}}}
function B_Reprisal_ChangePlayer:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_ChangePlayer:AddParameter(AjfoUo,Er9zidsB)
if(AjfoUo==0)then self.Entity=Er9zidsB elseif
(AjfoUo==1)then self.Player=tostring(Er9zidsB)end end
function B_Reprisal_ChangePlayer:CustomFunction(X)
if not IsExisting(self.Entity)then return end;local dR=GetID(self.Entity)
if Logic.IsLeader(dR)==1 then
Logic.ChangeSettlerPlayerID(dR,self.Player)else Logic.ChangeEntityPlayerID(dR,self.Player)end end
function B_Reprisal_ChangePlayer:GetCustomData(JFXtQwy)if JFXtQwy==1 then
return{"0","1","2","3","4","5","6","7","8"}end end
function B_Reprisal_ChangePlayer:Debug(uMV17h0)
if not IsExisting(self.Entity)then
error(
uMV17h0.Identifier..": "..
self.Name..": entity '"..self.Entity.."' does not exist!")return true end;return false end;Swift:RegisterBehavior(B_Reprisal_ChangePlayer)function Reprisal_SetVisible(...)return
B_Reprisal_SetVisible:new(...)end
B_Reprisal_SetVisible={Name="Reprisal_SetVisible",Description={en="Reprisal: Changes the visibility of an entity. If the entity is a spawner the spawned entities will be affected.",de="Vergeltung: Setzt die Sichtbarkeit einer Entity. Handelt es sich um einen Spawner werden auch die gespawnten Entities beeinflusst."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Custom,en="Visible",de="Sichtbar"}}}
function B_Reprisal_SetVisible:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_SetVisible:AddParameter(E2NZK,WNWWe)if(E2NZK==0)then self.Entity=WNWWe elseif(E2NZK==1)then
self.Visible=API.ToBoolean(WNWWe)end end
function B_Reprisal_SetVisible:CustomFunction(zMzjn3lk)
if not IsExisting(self.Entity)then return end;local Trkkpmd=GetID(self.Entity)
local L=Logic.EntityGetPlayer(Trkkpmd)local GGv=Logic.GetEntityType(Trkkpmd)
local ZIzh4Si=Logic.GetEntityTypeName(GGv)
if

string.find(ZIzh4Si,"^S_")or string.find(ZIzh4Si,"^B_NPC_Bandits")or string.find(ZIzh4Si,"^B_NPC_Barracks")then
local c8D4n81={Logic.GetSpawnedEntities(Trkkpmd)}
for cSjJHx=1,#c8D4n81 do
if Logic.IsLeader(c8D4n81[cSjJHx])==1 then
local fa={Logic.GetSoldiersAttachedToLeader(c8D4n81[cSjJHx])}
for M=2,#fa do Logic.SetVisible(fa[M],self.Visible)end else
Logic.SetVisible(c8D4n81[cSjJHx],self.Visible)end end else
if Logic.IsLeader(Trkkpmd)==1 then
local dIZlrvD={Logic.GetSoldiersAttachedToLeader(Trkkpmd)}for jQgsATKd=2,#dIZlrvD do
Logic.SetVisible(dIZlrvD[jQgsATKd],self.Visible)end else
Logic.SetVisible(Trkkpmd,self.Visible)end end end;function B_Reprisal_SetVisible:GetCustomData(aBbGg)
if aBbGg==1 then return{"true","false"}end end
function B_Reprisal_SetVisible:Debug(D9)
if not
IsExisting(self.Entity)then
error(D9.Identifier..": "..self.Name..
": entity '"..self.Entity.."' does not exist!")return true end;return false end;Swift:RegisterBehavior(B_Reprisal_SetVisible)function Reprisal_SetVulnerability(...)return
B_Reprisal_SetVulnerability:new(...)end
B_Reprisal_SetVulnerability={Name="Reprisal_SetVulnerability",Description={en="Reprisal: Changes the vulnerability of the entity. If the entity is a spawner the spawned entities will be affected.",de="Vergeltung: Macht eine Entity verwundbar oder unverwundbar. Handelt es sich um einen Spawner, sind die gespawnten Entities betroffen."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Custom,en="Vulnerability",de="Verwundbar"}}}
function B_Reprisal_SetVulnerability:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_SetVulnerability:AddParameter(G,gE)if(G==0)then self.Entity=gE elseif(G==1)then
self.Vulnerability=API.ToBoolean(gE)end end
function B_Reprisal_SetVulnerability:CustomFunction(QgC)
if not IsExisting(self.Entity)then return end;local CYoa=GetID(self.Entity)
local K3ipRr=Logic.GetEntityType(CYoa)local F2tY=Logic.GetEntityTypeName(K3ipRr)local rb21L2={CYoa}if
string.find(F2tY,"S_")or string.find(F2tY,"B_NPC_Bandits")or
string.find(F2tY,"B_NPC_Barracks")then
rb21L2={Logic.GetSpawnedEntities(CYoa)}end
local o_v255="MakeInvulnerable"if self.Vulnerability then o_v255="MakeVulnerable"end
for wUVm=1,#rb21L2,1 do
if
Logic.IsLeader(rb21L2[wUVm])==1 then
local VQ={Logic.GetSoldiersAttachedToLeader(rb21L2[wUVm])}for oTYNsnP=2,#VQ,1 do _G[o_v255](VQ[oTYNsnP])end end;_G[o_v255](rb21L2[wUVm])end end;function B_Reprisal_SetVulnerability:GetCustomData(I)
if I==1 then return{"true","false"}end end
function B_Reprisal_SetVulnerability:Debug(L)
if
not IsExisting(self.Entity)then
error(L.Identifier..
": "..self.Name..": entity '"..self.Entity..
"' does not exist!")return true end;return false end
Swift:RegisterBehavior(B_Reprisal_SetVulnerability)
function Reprisal_SetModel(...)return B_Reprisal_SetModel:new(...)end
B_Reprisal_SetModel={Name="Reprisal_SetModel",Description={en="Reprisal: Changes the model of the entity. Be careful, some models crash the game.",de="Vergeltung: Ändert das Model einer Entity. Achtung: Einige Modelle führen zum Absturz."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Custom,en="Model",de="Model"}}}
function B_Reprisal_SetModel:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_SetModel:AddParameter(mR5gwW,DfbW)if(mR5gwW==0)then self.Entity=DfbW elseif(mR5gwW==1)then
self.Model=DfbW end end
function B_Reprisal_SetModel:CustomFunction(sh)
if not IsExisting(self.Entity)then return end;local rrFLbCtj=GetID(self.Entity)
Logic.SetModel(rrFLbCtj,Models[self.Model])end
function B_Reprisal_SetModel:GetCustomData(YcPea0vg)if YcPea0vg==1 then return
ModuleBehaviorCollection.Global:GetPossibleModels()end end
function B_Reprisal_SetModel:Debug(usLpLoaH)
if not IsExisting(self.Entity)then
error(
usLpLoaH.Identifier..": "..
self.Name..": entity '"..self.Entity.."' does not exist!")return true end
if not Models[self.Model]then
error(usLpLoaH.Identifier..
": "..self.Name..": model '"..self.Entity..
"' does not exist!")return true end;return false end;Swift:RegisterBehavior(B_Reprisal_SetModel)function Reward_SetPosition(...)return
B_Reward_SetPosition:new(...)end
B_Reward_SetPosition=Swift:CopyTable(B_Reprisal_SetPosition)B_Reward_SetPosition.Name="Reward_SetPosition"
B_Reward_SetPosition.Description.en="Reward: Places an entity relative to the position of another. The entity can look the target."
B_Reward_SetPosition.Description.de="Lohn: Setzt eine Entity relativ zur Position einer anderen. Die Entity kann zum Ziel ausgerichtet werden."B_Reward_SetPosition.GetReprisalTable=nil
B_Reward_SetPosition.GetRewardTable=function(e7dv,inx0)return
{Reward.Custom,{e7dv,e7dv.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_SetPosition)function Reward_ChangePlayer(...)return
B_Reward_ChangePlayer:new(...)end
B_Reward_ChangePlayer=Swift:CopyTable(B_Reprisal_ChangePlayer)B_Reward_ChangePlayer.Name="Reward_ChangePlayer"
B_Reward_ChangePlayer.Description.en="Reward: Changes the owner of the entity or a battalion."
B_Reward_ChangePlayer.Description.de="Lohn: Ändert den Besitzer einer Entity oder eines Battalions."B_Reward_ChangePlayer.GetReprisalTable=nil
B_Reward_ChangePlayer.GetRewardTable=function(A5k5yt,B7SHDx7h)return
{Reward.Custom,{A5k5yt,A5k5yt.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_ChangePlayer)function Reward_MoveToPosition(...)return
B_Reward_MoveToPosition:new(...)end
B_Reward_MoveToPosition={Name="Reward_MoveToPosition",Description={en="Reward: Moves an entity relative to another entity. If angle is zero the entities will be standing directly face to face.",de="Lohn: Bewegt eine Entity relativ zur Position einer anderen. Wenn Winkel 0 ist, stehen sich die Entities direkt gegen�ber."},Parameter={{ParameterType.ScriptName,en="Settler",de="Siedler"},{ParameterType.ScriptName,en="Destination",de="Ziel"},{ParameterType.Number,en="Distance",de="Entfernung"},{ParameterType.Number,en="Angle",de="Winkel"}}}function B_Reward_MoveToPosition:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_MoveToPosition:AddParameter(EEpoeR,_k)
if(
EEpoeR==0)then self.Entity=_k elseif(EEpoeR==1)then self.Target=_k elseif(EEpoeR==2)then self.Distance=
_k*1 elseif(EEpoeR==3)then self.Angle=_k*1 end end
function B_Reward_MoveToPosition:CustomFunction(Ef)
if not IsExisting(self.Entity)or not
IsExisting(self.Target)then return end;self.Angle=self.Angle or 0;local KfM=GetID(self.Entity)
local Vd=GetID(self.Target)local Oynw=Logic.GetEntityOrientation(Vd)
local QBO,s4ggux,hrVI4meU=Logic.EntityGetPos(Vd)if Logic.IsBuilding(Vd)==1 then
QBO,s4ggux=Logic.GetBuildingApproachPosition(Vd)Oynw=Oynw-90 end
QBO=QBO+self.Distance*math.cos(math.rad(
Oynw+self.Angle))s4ggux=s4ggux+
self.Distance*math.sin(math.rad(Oynw+self.Angle))
Logic.MoveSettler(KfM,QBO,s4ggux)
StartSimpleJobEx(function(xEq6TAF,UIjls)if Logic.IsEntityMoving(xEq6TAF)==false then
LookAt(xEq6TAF,UIjls)return true end end,KfM,Vd)end
function B_Reward_MoveToPosition:Debug(jdLnB0vD)
if tonumber(self.Distance)==nil or
self.Distance<50 then
error(jdLnB0vD.Identifier..": "..
self.Name..": Distance is nil or to short!")return true elseif not IsExisting(self.Entity)or
not IsExisting(self.Target)then
error(jdLnB0vD.Identifier..": "..self.Name..
": Mover entity or target entity does not exist!")return true end;return false end;Swift:RegisterBehavior(B_Reward_MoveToPosition)function Reward_VictoryWithParty()return
B_Reward_VictoryWithParty:new()end
B_Reward_VictoryWithParty={Name="Reward_VictoryWithParty",Description={en="Reward: (Singleplayer) The player wins the game with an animated festival on the market. Continue playing deleates the festival.",de="Lohn: (Einzelspieler) Der Spieler gewinnt das Spiel mit einer animierten Siegesfeier. Bei weiterspielen wird das Fest gelöscht."},Parameter={}}
function B_Reward_VictoryWithParty:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end;function B_Reward_VictoryWithParty:AddParameter(PSlD,nN)end
function B_Reward_VictoryWithParty:CustomFunction(J)if
Framework.IsNetworkGame()then
error(J.Identifier..
": "..self.Name..": Can not be used in multiplayer!")return end
Victory(g_VictoryAndDefeatType.VictoryMissionComplete)local A=J.ReceivingPlayer;local g3Qeqnr=Logic.GetMarketplace(A)
if
IsExisting(g3Qeqnr)then local qHpY64=GetPosition(g3Qeqnr)
Logic.CreateEffect(EGL_Effects.FXFireworks01,qHpY64.X,qHpY64.Y,0)
Logic.CreateEffect(EGL_Effects.FXFireworks02,qHpY64.X,qHpY64.Y,0)local z=self:GenerateParty(A)
QSB.VictoryWithPartyEntities[A]=z
Logic.ExecuteInLuaLocalState(string.format([[
            if IsExisting(%d) then
                CameraAnimation.AllowAbort = false
                CameraAnimation.QueueAnimation(CameraAnimation.SetCameraToEntity, %d)
                CameraAnimation.QueueAnimation(CameraAnimation.StartCameraRotation, 5)
                CameraAnimation.QueueAnimation(CameraAnimation.Stay ,9999)
            end

            GUI_Window.ContinuePlayingClicked_Orig_Reward_VictoryWithParty = GUI_Window.ContinuePlayingClicked
            GUI_Window.ContinuePlayingClicked = function()
                GUI_Window.ContinuePlayingClicked_Orig_Reward_VictoryWithParty()
                
                local PlayerID = GUI.GetPlayerID()
                GUI.SendScriptCommand("B_Reward_VictoryWithParty:ClearParty(" ..PlayerID.. ")")

                CameraAnimation.AllowAbort = true
                CameraAnimation.Abort()
            end
            ]],g3Qeqnr,g3Qeqnr))end end
function B_Reward_VictoryWithParty:ClearParty(qccJ5b)
if QSB.VictoryWithPartyEntities[qccJ5b]then
for ARuba,Wo53nZ in
pairs(QSB.VictoryWithPartyEntities[qccJ5b])do DestroyEntity(Wo53nZ)end;QSB.VictoryWithPartyEntities[qccJ5b]=nil end end
function B_Reward_VictoryWithParty:GenerateParty(XRfQ)local gFPRdEC={}
local lw9gLt3=Logic.GetMarketplace(XRfQ)
if lw9gLt3 ~=nil and lw9gLt3 ~=0 then
local T,I5=Logic.GetEntityPosition(lw9gLt3)
local JmE=Logic.CreateEntity(Entities.D_X_Garland,T,I5,0,XRfQ)table.insert(gFPRdEC,JmE)
for s4=1,10 do
for FFG=1,10 do
local a31jEAS=T-700+ (s4*150)local LS4h=I5-700+ (FFG*150)
local eux092_P=Logic.GetRandom(100)
if eux092_P>70 then local ZA9=API.GetRandomSettlerType()
local hWgmxm=Logic.GetRandom(360)
local UBg54E=Logic.CreateEntityOnUnblockedLand(ZA9,a31jEAS,LS4h,hWgmxm,XRfQ)
Logic.SetTaskList(UBg54E,TaskLists.TL_WORKER_FESTIVAL_APPLAUD_SPEECH)table.insert(gFPRdEC,UBg54E)end end end end;return gFPRdEC end;function B_Reward_VictoryWithParty:Debug(gQGq)return false end
Swift:RegisterBehavior(B_Reward_VictoryWithParty)
function Reward_SetVisible(...)return B_Reward_SetVisible:new(...)end
B_Reward_SetVisible=Swift:CopyTable(B_Reprisal_SetVisible)B_Reward_SetVisible.Name="Reward_SetVisible"
B_Reward_SetVisible.Description.en="Reward: Changes the visibility of an entity. If the entity is a spawner the spawned entities will be affected."
B_Reward_SetVisible.Description.de="Lohn: Setzt die Sichtbarkeit einer Entity. Handelt es sich um einen Spawner werden auch die gespawnten Entities beeinflusst."B_Reward_SetVisible.GetReprisalTable=nil
B_Reward_SetVisible.GetRewardTable=function(OyHc5FEv,Dn1Xi)return
{Reward.Custom,{OyHc5FEv,OyHc5FEv.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_SetVisible)function Reward_SetVulnerability(...)return
B_Reward_SetVulnerability:new(...)end
B_Reward_SetVulnerability=Swift:CopyTable(B_Reprisal_SetVulnerability)B_Reward_SetVulnerability.Name="Reward_SetVulnerability"
B_Reward_SetVulnerability.Description.en="Reward: Changes the vulnerability of the entity. If the entity is a spawner the spawned entities will be affected."
B_Reward_SetVulnerability.Description.de="Lohn: Macht eine Entity verwundbar oder unverwundbar. Handelt es sich um einen Spawner, sind die gespawnten Entities betroffen."B_Reward_SetVulnerability.GetReprisalTable=nil
B_Reward_SetVulnerability.GetRewardTable=function(_gGmBBE,rIX4)return
{Reward.Custom,{_gGmBBE,_gGmBBE.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_SetVulnerability)function Reward_SetModel(...)return
B_Reward_SetModel:new(...)end
B_Reward_SetModel=Swift:CopyTable(B_Reprisal_SetModel)B_Reward_SetModel.Name="Reward_SetModel"
B_Reward_SetModel.Description.en="Reward: Changes the model of the entity. Be careful, some models crash the game."
B_Reward_SetModel.Description.de="Lohn: Ändert das Model einer Entity. Achtung: Einige Modelle führen zum Absturz."B_Reward_SetModel.GetReprisalTable=nil
B_Reward_SetModel.GetRewardTable=function(AI14eFhp,iW2O)return
{Reward.Custom,{AI14eFhp,AI14eFhp.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_SetModel)function Reward_AI_SetEntityControlled(...)return
B_Reward_AI_SetEntityControlled:new(...)end
B_Reward_AI_SetEntityControlled={Name="Reward_AI_SetEntityControlled",Description={en="Reward: Bind or Unbind an entity or a battalion to/from an AI player. The AI player must be activated!",de="Lohn: Die KI kontrolliert die Entity oder der KI die Kontrolle entziehen. Die KI muss aktiv sein!"},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Custom,en="AI control entity",de="KI kontrolliert Entity"}}}
function B_Reward_AI_SetEntityControlled:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_AI_SetEntityControlled:AddParameter(Gdp,nbqmx)if(Gdp==0)then self.Entity=nbqmx elseif(Gdp==1)then
self.Hidden=API.ToBoolean(nbqmx)end end
function B_Reward_AI_SetEntityControlled:CustomFunction(IWQcC)if
not IsExisting(self.Entity)then return end;local cvRh=GetID(self.Entity)
local W9yaJm=Logic.EntityGetPlayer(cvRh)local oJ1ec=Logic.GetEntityType(cvRh)
local L=Logic.GetEntityTypeName(oJ1ec)
if

string.find(L,"S_")or string.find(L,"B_NPC_Bandits")or string.find(L,"B_NPC_Barracks")then local MMNWLk={Logic.GetSpawnedEntities(cvRh)}
for x6Ni=1,#MMNWLk
do if Logic.IsLeader(MMNWLk[x6Ni])==1 then
AICore.HideEntityFromAI(W9yaJm,MMNWLk[x6Ni],
not self.Hidden)end end else
AICore.HideEntityFromAI(W9yaJm,cvRh,not self.Hidden)end end;function B_Reward_AI_SetEntityControlled:GetCustomData(Q2waXkyp)
if Q2waXkyp==1 then return{"false","true"}end end
function B_Reward_AI_SetEntityControlled:Debug(EG72)
if
not IsExisting(self.Entity)then
error(EG72.Identifier..
": "..self.Name..": entity '"..self.Entity..
"' does not exist!")return true end;return false end
Swift:RegisterBehavior(B_Reward_AI_SetEntityControlled)
function Trigger_OnAtLeastXOfYQuestsFailed(...)return
B_Trigger_OnAtLeastXOfYQuestsFailed:new(...)end
B_Trigger_OnAtLeastXOfYQuestsFailed={Name="Trigger_OnAtLeastXOfYQuestsFailed",Description={en="Trigger: if at least X of Y given quests has been finished successfully.",de="Auslöser: wenn X von Y angegebener Quests fehlgeschlagen sind."},Parameter={{ParameterType.Custom,en="Least Amount",de="Mindest Anzahl"},{ParameterType.Custom,en="Quest Amount",de="Quest Anzahl"},{ParameterType.QuestName,en="Quest name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest name 2",de="Questname 2"},{ParameterType.QuestName,en="Quest name 3",de="Questname 3"},{ParameterType.QuestName,en="Quest name 4",de="Questname 4"},{ParameterType.QuestName,en="Quest name 5",de="Questname 5"}}}
function B_Trigger_OnAtLeastXOfYQuestsFailed:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_OnAtLeastXOfYQuestsFailed:AddParameter(mlTMZ,q)
if(mlTMZ==0)then
self.LeastAmount=tonumber(q)elseif(mlTMZ==1)then self.QuestAmount=tonumber(q)elseif(mlTMZ==2)then
self.QuestName1=q elseif(mlTMZ==3)then self.QuestName2=q elseif(mlTMZ==4)then self.QuestName3=q elseif(mlTMZ==5)then
self.QuestName4=q elseif(mlTMZ==6)then self.QuestName5=q end end
function B_Trigger_OnAtLeastXOfYQuestsFailed:CustomFunction()local xb6=0
for yK=1,self.QuestAmount do
local rHLz2GD=GetQuestID(self["QuestName"..yK])if IsValidQuest(rHLz2GD)then
if
(Quests[rHLz2GD].Result==QuestResult.Failure)then xb6=xb6+1;if xb6 >=self.LeastAmount then return true end end end end;return false end
function B_Trigger_OnAtLeastXOfYQuestsFailed:Debug(BlW0RhJA)local Uy=self.LeastAmount
local n=self.QuestAmount
if Uy<=0 or Uy>5 then
error(BlW0RhJA.Identifier..
":"..self.Name..": LeastAmount is wrong")return true elseif n<=0 or n>5 then
error(BlW0RhJA.Identifier..
": "..self.Name..": QuestAmount is wrong")return true elseif Uy>n then
error(BlW0RhJA.Identifier..": "..
self.Name..": LeastAmount is greater than QuestAmount")return true end
for TKu=1,n do
if not IsValidQuest(self["QuestName"..TKu])then
error(
BlW0RhJA.Identifier..": "..self.Name..
": Quest "..self["QuestName"..TKu].." not found")return true end end;return false end
function B_Trigger_OnAtLeastXOfYQuestsFailed:GetCustomData(M6kL)if(M6kL==0)or(M6kL==1)then return
{"1","2","3","4","5"}end end
Swift:RegisterBehavior(B_Trigger_OnAtLeastXOfYQuestsFailed)function Trigger_AmmunitionDepleted(...)
return B_Trigger_AmmunitionDepleted:new(...)end
B_Trigger_AmmunitionDepleted={Name="Trigger_AmmunitionDepleted",Description={en="Trigger: if the ammunition of the entity is depleted.",de="Auslöser: wenn die Munition der Entity aufgebraucht ist."},Parameter={{ParameterType.Scriptname,en="Script name",de="Skriptname"}}}
function B_Trigger_AmmunitionDepleted:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end;function B_Trigger_AmmunitionDepleted:AddParameter(M7o_,dk2X7J7)
if(M7o_==0)then self.Scriptname=dk2X7J7 end end
function B_Trigger_AmmunitionDepleted:CustomFunction()
if
not IsExisting(self.Scriptname)then return false end;local jv=GetID(self.Scriptname)if
Logic.GetAmmunitionAmount(jv)>0 then return false end;return true end
function B_Trigger_AmmunitionDepleted:Debug(MW)
if not IsExisting(self.Scriptname)then
error(
MW.Identifier..": "..
self.Name..": '"..self.Scriptname.."' is destroyed!")return true end;return false end
Swift:RegisterBehavior(B_Trigger_AmmunitionDepleted)function Trigger_OnExactOneQuestIsWon(...)
return B_Trigger_OnExactOneQuestIsWon:new(...)end
B_Trigger_OnExactOneQuestIsWon={Name="Trigger_OnExactOneQuestIsWon",Description={en="Trigger: if one of two given quests has been finished successfully, but NOT both.",de="Auslöser: wenn eine von zwei angegebenen Quests (aber NICHT beide) erfolgreich abgeschlossen wurde."},Parameter={{ParameterType.QuestName,en="Quest Name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest Name 2",de="Questname 2"}}}
function B_Trigger_OnExactOneQuestIsWon:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_OnExactOneQuestIsWon:AddParameter(E2OQ,SnbfLb6)self.QuestTable={}if(E2OQ==0)then
self.Quest1=SnbfLb6 elseif(E2OQ==1)then self.Quest2=SnbfLb6 end end
function B_Trigger_OnExactOneQuestIsWon:CustomFunction(ay)
local W=Quests[GetQuestID(self.Quest1)]local WzM=Quests[GetQuestID(self.Quest2)]
if WzM and W then
local PSx=(W.State==
QuestState.Over and W.Result==QuestResult.Success)
local I=(WzM.State==QuestState.Over and WzM.Result==QuestResult.Success)
if(PSx and not I)or(not PSx and I)then return true end end;return false end
function B_Trigger_OnExactOneQuestIsWon:Debug(wnA)
if self.Quest1 ==self.Quest2 then
error(wnA.Identifier..": "..
self.Name..": Both quests are identical!")return true elseif not IsValidQuest(self.Quest1)then
error(wnA.Identifier..": "..
self.Name..": Quest '"..
self.Quest1 .."' does not exist!")return true elseif not IsValidQuest(self.Quest2)then
error(wnA.Identifier..": "..
self.Name..": Quest '"..
self.Quest2 .."' does not exist!")return true end;return false end
Swift:RegisterBehavior(B_Trigger_OnExactOneQuestIsWon)function Trigger_OnExactOneQuestIsLost(...)
return B_Trigger_OnExactOneQuestIsLost:new(...)end
B_Trigger_OnExactOneQuestIsLost={Name="Trigger_OnExactOneQuestIsLost",Description={en="Trigger: If one of two given quests has been lost, but NOT both.",de="Auslöser: Wenn einer von zwei angegebenen Quests (aber NICHT beide) fehlschlägt."},Parameter={{ParameterType.QuestName,en="Quest Name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest Name 2",de="Questname 2"}}}
function B_Trigger_OnExactOneQuestIsLost:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_OnExactOneQuestIsLost:AddParameter(cW,PHpCof2)self.QuestTable={}if(cW==0)then
self.Quest1=PHpCof2 elseif(cW==1)then self.Quest2=PHpCof2 end end
function B_Trigger_OnExactOneQuestIsLost:CustomFunction(bUPpn4T2)
local sode=Quests[GetQuestID(self.Quest1)]local G9zkKODk=Quests[GetQuestID(self.Quest2)]
if
G9zkKODk and sode then
local MGt=(sode.State==QuestState.Over and sode.Result==QuestResult.Failure)
local ld9GuG4t=(G9zkKODk.State==QuestState.Over and
G9zkKODk.Result==QuestResult.Failure)if
(MGt and not ld9GuG4t)or(not MGt and ld9GuG4t)then return true end end;return false end
function B_Trigger_OnExactOneQuestIsLost:Debug(KpCCA)
if self.Quest1 ==self.Quest2 then
error(KpCCA.Identifier..
": "..self.Name..": Both quests are identical!")return true elseif not IsValidQuest(self.Quest1)then
error(KpCCA.Identifier..": "..
self.Name..": Quest '"..
self.Quest1 .."' does not exist!")return true elseif not IsValidQuest(self.Quest2)then
error(KpCCA.Identifier..": "..
self.Name..": Quest '"..
self.Quest2 .."' does not exist!")return true end;return false end
Swift:RegisterBehavior(B_Trigger_OnExactOneQuestIsLost)